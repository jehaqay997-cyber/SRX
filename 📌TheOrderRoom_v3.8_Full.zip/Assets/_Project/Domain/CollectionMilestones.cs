using System;
using System.Collections.Generic;
namespace TheOrderRoom.Domain
{
    public readonly struct CollectionMilestone
    {
        public readonly string Id;
        public readonly int Required;
        public CollectionMilestone(string id, int required)
        {
            if (string.IsNullOrWhiteSpace(id) || required < 1) throw new ArgumentException("Invalid milestone");
            Id = id; Required = required;
        }
    }
    /// <summary>Pure, deterministic collection milestones. No monetization or clock dependency.</summary>
    public static class CollectionMilestones
    {
        private static readonly CollectionMilestone[] Milestones =
        {
            new CollectionMilestone("gallery.first", 1),
            new CollectionMilestone("gallery.curator", 4),
            new CollectionMilestone("gallery.archivist", 8),
            new CollectionMilestone("gallery.complete", 12)
        };
        public static IReadOnlyList<CollectionMilestone> Definitions => Array.AsReadOnly(Milestones);
        public static string[] Evaluate(IReadOnlyCollection<string> discovered)
        {
            if (discovered == null) throw new ArgumentNullException(nameof(discovered));
            var result = new List<string>();
            foreach (var milestone in Milestones)
                if (discovered.Count >= milestone.Required) result.Add(milestone.Id);
            return result.ToArray();
        }
    }
}
