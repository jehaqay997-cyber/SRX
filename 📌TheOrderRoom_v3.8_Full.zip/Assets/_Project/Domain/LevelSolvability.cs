using System;
using System.Collections.Generic;
using System.Linq;
namespace TheOrderRoom.Domain
{
    /// <summary>Deterministic authoring-time feasibility search with a verifiable assignment witness.</summary>
    public static class LevelSolvability
    {
        public static bool HasSolution(IEnumerable<Item> items, IEnumerable<Compartment> compartments, int nodeLimit = 1000000)
        {
            return TryFindSolution(items, compartments, out _, nodeLimit);
        }
        public static bool TryFindSolution(IEnumerable<Item> items, IEnumerable<Compartment> compartments,
            out IReadOnlyDictionary<string, string> assignment, int nodeLimit = 1000000)
        {
            assignment = null;
            if (items == null) throw new ArgumentNullException(nameof(items));
            if (compartments == null) throw new ArgumentNullException(nameof(compartments));
            if (nodeLimit < 1) throw new ArgumentOutOfRangeException(nameof(nodeLimit));
            // Materialize exactly once: supports single-pass input enumerables.
            var objects = items.ToArray();
            var bins = compartments.ToArray();
            LevelRules.Validate(objects, bins);
            objects = objects.OrderByDescending(x => x.Weight).ThenBy(x => x.Id, StringComparer.Ordinal).ToArray();
            var counts = new int[bins.Length];
            var weights = new long[bins.Length];
            var chosen = new int[objects.Length];
            int explored = 0;
            bool Search(int index)
            {
                if (index == objects.Length) return true;
                if (++explored > nodeLimit) throw new InvalidOperationException("Solver search budget exceeded");
                var item = objects[index];
                for (int j = 0; j < bins.Length; j++)
                {
                    if (!StringComparer.Ordinal.Equals(item.Tag, bins[j].Tag) || counts[j] >= bins[j].Capacity ||
                        weights[j] + item.Weight > bins[j].MaxWeight) continue;
                    chosen[index] = j;
                    counts[j]++; weights[j] += item.Weight;
                    if (Search(index + 1)) return true;
                    counts[j]--; weights[j] -= item.Weight;
                }
                return false;
            }
            if (!Search(0)) return false;
            var result = new Dictionary<string, string>(objects.Length, StringComparer.Ordinal);
            for (int i = 0; i < objects.Length; i++) result.Add(objects[i].Id, bins[chosen[i]].Id);
            assignment = new System.Collections.ObjectModel.ReadOnlyDictionary<string, string>(result);
            return true;
        }
    }
}
