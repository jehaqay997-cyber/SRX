using System;
using System.Collections.Generic;
using System.Linq;
namespace TheOrderRoom.Domain {
 public sealed class Item { public readonly string Id,Tag; public readonly int Weight; public Item(string id,string tag,int weight){if(string.IsNullOrWhiteSpace(id)||string.IsNullOrWhiteSpace(tag)||weight<=0)throw new ArgumentException("Invalid item");Id=id;Tag=tag;Weight=weight;} }
 public sealed class Compartment { public readonly string Id,Tag; public readonly int Capacity,MaxWeight; public Compartment(string id,string tag,int capacity,int maxWeight){if(string.IsNullOrWhiteSpace(id)||string.IsNullOrWhiteSpace(tag)||capacity<=0||maxWeight<=0)throw new ArgumentException("Invalid compartment");Id=id;Tag=tag;Capacity=capacity;MaxWeight=maxWeight;} }
 public sealed class OrderBoard {
  public const string Tray="TRAY";
  private readonly Dictionary<string,Item> items=new Dictionary<string,Item>(StringComparer.Ordinal);
  private readonly Dictionary<string,Compartment> compartments=new Dictionary<string,Compartment>(StringComparer.Ordinal);
  private readonly Dictionary<string,string> locations=new Dictionary<string,string>(StringComparer.Ordinal);
  private readonly Dictionary<long,Proposal> issued=new Dictionary<long,Proposal>();
  private long nextToken;
  private readonly Dictionary<string,string> requiredLocations;
  public int Revision {get;private set;}
  private struct Proposal {public string Item,From,To;public int Revision;}
  public OrderBoard(IEnumerable<Item> itemList,IEnumerable<Compartment> compartmentList) : this(itemList, compartmentList, null) {}
  public OrderBoard(IEnumerable<Item> itemList,IEnumerable<Compartment> compartmentList,IReadOnlyDictionary<string,string> exactTargets){
   if(itemList==null)throw new ArgumentNullException(nameof(itemList));
   if(compartmentList==null)throw new ArgumentNullException(nameof(compartmentList));
   foreach(var c in compartmentList){if(c==null)throw new ArgumentException("Null compartment");if(c.Id==Tray||compartments.ContainsKey(c.Id))throw new ArgumentException("Duplicate/reserved compartment");compartments.Add(c.Id,c);}
   foreach(var item in itemList){if(item==null)throw new ArgumentException("Null item");if(items.ContainsKey(item.Id))throw new ArgumentException("Duplicate item");items.Add(item.Id,item);locations.Add(item.Id,Tray);}
   if(items.Count==0||compartments.Count==0)throw new ArgumentException("Empty board");
   if(items.ContainsKey(Tray))throw new ArgumentException("Reserved item ID");
   if(exactTargets!=null){
    if(exactTargets.Count!=items.Count)throw new ArgumentException("Objective must specify every item");
    requiredLocations=new Dictionary<string,string>(StringComparer.Ordinal);
    foreach(var pair in exactTargets){
     if(!items.TryGetValue(pair.Key,out var objectiveItem) || !compartments.TryGetValue(pair.Value,out var target) ||
        !StringComparer.Ordinal.Equals(objectiveItem.Tag,target.Tag))throw new ArgumentException("Invalid objective target");
     requiredLocations.Add(pair.Key,pair.Value);
    }
    foreach(var bin in compartments.Values){
     var assigned=requiredLocations.Where(x=>x.Value==bin.Id).Select(x=>items[x.Key]).ToArray();
     if(assigned.Length>bin.Capacity || assigned.Sum(x=>(long)x.Weight)>bin.MaxWeight)
      throw new ArgumentException("Objective violates compartment constraints");
    }
   }
  }
  public IReadOnlyDictionary<string,string> Snapshot()=>new Dictionary<string,string>(locations);
  public IEnumerable<Item> Items=>items.Values.ToArray();
  public IEnumerable<Compartment> Compartments=>compartments.Values.ToArray();
  public string Location(string id)=>locations[id];
  public IReadOnlyDictionary<string,string> ExactTargets => requiredLocations == null ? null : new System.Collections.ObjectModel.ReadOnlyDictionary<string,string>(new Dictionary<string,string>(requiredLocations, StringComparer.Ordinal));
  public bool Prepare(string id,string destination,int expectedRevision,out long token,out string error){token=0;issued.Clear();
   if(expectedRevision!=Revision){error="Stale revision";return false;}
   if(!items.ContainsKey(id)){error="Unknown item";return false;}
   if(destination!=Tray&&!compartments.ContainsKey(destination)){error="Unknown destination";return false;}
   if(locations[id]==destination){error="Already placed";return false;}
   if(!CanPlace(id,destination,out error))return false;
   // One outstanding capability; any subsequent Prepare invalidates the previous one.
   if(Revision==int.MaxValue){error="Revision exhausted";return false;}
   if(nextToken==long.MaxValue){error="Transfer token exhausted";return false;}
   token=++nextToken;issued.Add(token,new Proposal{Item=id,From=locations[id],To=destination,Revision=Revision});return true;
  }
  public bool Commit(long token,out string error){
   if(!issued.TryGetValue(token,out var p)){error="Invalid/consumed token";return false;}
   issued.Remove(token);
   if(p.Revision!=Revision||locations[p.Item]!=p.From){error="Stale proposal";return false;}
   if(!CanPlace(p.Item,p.To,out error))return false;
   if(Revision==int.MaxValue){error="Revision exhausted";return false;}
   locations[p.Item]=p.To;Revision++;issued.Clear();error=null;return true;
  }
  public bool Move(string id,string destination,out string error){if(!Prepare(id,destination,Revision,out long token,out error))return false;return Commit(token,out error);}
  private bool CanPlace(string id,string destination,out string error){error=null;if(destination==Tray)return true;
   var item=items[id];var c=compartments[destination];if(item.Tag!=c.Tag){error="Wrong symbol";return false;}
   int count=0;long weight=item.Weight;foreach(var pair in locations){if(pair.Key==id||pair.Value!=destination)continue;count++;weight+=items[pair.Key].Weight;}
   if(count>=c.Capacity){error="Compartment full";return false;}if(weight>c.MaxWeight){error="Weight limit";return false;}return true;
  }
  public bool Solved=>items.Count>0 && (requiredLocations!=null
   ? requiredLocations.All(x=>StringComparer.Ordinal.Equals(locations[x.Key],x.Value))
   : items.Values.All(i=>locations[i.Id]!=Tray&&compartments[locations[i.Id]].Tag==i.Tag));
  public void Reset(){if(Revision==int.MaxValue)throw new InvalidOperationException("Revision exhausted");foreach(var id in items.Keys)locations[id]=Tray;Revision++;issued.Clear();}
  public bool Restore(IDictionary<string,string> saved){if(saved==null||saved.Count!=items.Count||saved.Keys.Any(k=>!items.ContainsKey(k)))return false;
   var copy=new OrderBoard(items.Values,compartments.Values,requiredLocations);foreach(var pair in saved.OrderBy(x=>x.Key,StringComparer.Ordinal)){
    if(pair.Value!=Tray&&!copy.Move(pair.Key,pair.Value,out _))return false;
   }if(Revision==int.MaxValue)return false;foreach(var pair in copy.locations)locations[pair.Key]=pair.Value;Revision++;issued.Clear();return true;
  }
 }
}
