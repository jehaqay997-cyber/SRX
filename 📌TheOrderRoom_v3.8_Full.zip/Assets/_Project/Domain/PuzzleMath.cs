using System;

namespace TheOrderRoom.Domain
{
    /// <summary>Deterministic geometry and motion primitives; no Unity dependencies.</summary>
    public static class PuzzleMath
    {
        public const int QuarterTurns = 4;
        public static int NormalizeQuarterTurn(int turns) => ((turns % QuarterTurns) + QuarterTurns) % QuarterTurns;
        public static double QuarterTurnDegrees(int turns) => 90.0 * NormalizeQuarterTurn(turns);
        // A seal at index i faces the camera after i positive quarter turns.
        public static void SealPositionXZ(int index, double radius, out double x, out double z)
        {
            if (index < 0 || index >= 3) throw new ArgumentOutOfRangeException(nameof(index));
            if (double.IsNaN(radius) || double.IsInfinity(radius) || radius <= 0)
                throw new ArgumentOutOfRangeException(nameof(radius));
            double theta = index * Math.PI / 2.0;
            x = radius * Math.Sin(theta);
            z = -radius * Math.Cos(theta);
        }
        // Cubic Hermite easing, with zero endpoint velocity and bounded displacement.
        public static double SmoothStep(double normalizedTime)
        {
            if (double.IsNaN(normalizedTime) || double.IsInfinity(normalizedTime))
                throw new ArgumentOutOfRangeException(nameof(normalizedTime));
            double t = Math.Max(0, Math.Min(1, normalizedTime));
            return t * t * (3 - 2 * t);
        }
        // Derivative of smoothstep: 6t(1-t); non-negative on [0,1].
        public static double SmoothStepDerivative(double normalizedTime)
        {
            if (double.IsNaN(normalizedTime) || double.IsInfinity(normalizedTime))
                throw new ArgumentOutOfRangeException(nameof(normalizedTime));
            if (normalizedTime <= 0 || normalizedTime >= 1) return 0;
            return 6 * normalizedTime * (1 - normalizedTime);
        }
        // Integral of the derivative over [0,1] equals one (total normalized motion).
        public static double SmoothStepAntiderivative(double t) => 3 * t * t - 2 * t * t * t;
    }
}
