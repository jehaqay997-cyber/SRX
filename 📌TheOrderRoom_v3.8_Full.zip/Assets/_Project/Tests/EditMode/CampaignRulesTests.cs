#if UNITY_INCLUDE_TESTS
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests
{
    public sealed class CampaignRulesTests
    {
        [Test] public void EveryLevelHasAValidBoard()
        {
            for (int i = 0; i < OrderLevels.Count; i++)
            {
                var board = OrderLevels.Create(i);
                Assert.IsNotNull(board);
                Assert.IsFalse(board.Solved);
            }
        }

        [Test] public void GatesOccurAtEndOfEachChapter()
        {
            Assert.AreEqual(12, CampaignRules.LevelCount);
            for (int i = 0; i < CampaignRules.LevelCount; i++)
                Assert.AreEqual((i + 1) % 3 == 0, CampaignRules.IsGate(i));
        }

        [Test] public void LockedLevelCannotBeCompleted()
        {
            Assert.Throws<System.InvalidOperationException>(() => CampaignRules.UnlockAfterCompletion(3, 0));
        }

        [Test] public void UnlockIsIdempotent()
        {
            int unlocked = CampaignRules.UnlockAfterCompletion(0, 0);
            Assert.AreEqual(unlocked, CampaignRules.UnlockAfterCompletion(0, unlocked));
        }

        [Test] public void OnlyOneTransferCapabilityRemainsLive()
        {
            var board = OrderLevels.Create(0);
            string id = null;
            foreach (var item in board.Items) { id = item.Id; break; }
            string target = null;
            foreach (var bin in board.Compartments)
                if (bin.Tag == "SUN") { target = bin.Id; break; }
            Assert.IsTrue(board.Prepare(id, target, 0, out long first, out _));
            Assert.IsTrue(board.Prepare(id, target, 0, out long second, out _));
            Assert.IsFalse(board.Commit(first, out _));
            Assert.IsTrue(board.Commit(second, out _));
        }
    }
}
#endif
