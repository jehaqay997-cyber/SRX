#if UNITY_INCLUDE_TESTS
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests
{
    public sealed class DomainRootCauseTests
    {
        [Test]
        public void SolverWitnessIsValidAndComplete()
        {
            var items = new[] { new Item("A", "SUN", 2), new Item("B", "SUN", 1) };
            var bins = new[] { new Compartment("L", "SUN", 1, 2), new Compartment("R", "SUN", 1, 1) };
            Assert.IsTrue(LevelSolvability.TryFindSolution(items, bins, out var witness));
            Assert.AreEqual("L", witness["A"]);
            Assert.AreEqual("R", witness["B"]);
            var board = new OrderBoard(items, bins, witness);
            Assert.IsTrue(board.Move("A", witness["A"], out _));
            Assert.IsTrue(board.Move("B", witness["B"], out _));
            Assert.IsTrue(board.Solved);
        }
        [Test]
        public void SolverRejectsImpossiblePackingWithoutForgedWitness()
        {
            var items = new[] { new Item("A", "SUN", 2), new Item("B", "SUN", 2), new Item("C", "SUN", 2) };
            var bins = new[] { new Compartment("L", "SUN", 2, 3), new Compartment("R", "SUN", 2, 3) };
            Assert.IsFalse(LevelSolvability.TryFindSolution(items, bins, out var witness));
            Assert.IsNull(witness);
        }
        [Test]
        public void GateLevelsHaveSpecificTargetAndCanBeSolved()
        {
            for (int i = 2; i < OrderLevels.Count; i += 3)
            {
                var board = OrderLevels.Create(i);
                // A witness is available from the exact solver and must be accepted by the board.
                Assert.IsNotNull(board.ExactTargets);
                foreach (var pair in board.ExactTargets) Assert.IsTrue(board.Move(pair.Key, pair.Value, out _));
                Assert.IsTrue(board.Solved, "Gate level " + i);
            }
        }
        [Test]
        public void SolverRejectsInvalidDefinitions()
        {
            Assert.Throws<ArgumentException>(() => LevelSolvability.TryFindSolution(
                new[] { new Item("A", "SUN", 1), new Item("A", "SUN", 1) },
                new[] { new Compartment("L", "SUN", 2, 2) }, out _));
        }
    }
}
#endif
