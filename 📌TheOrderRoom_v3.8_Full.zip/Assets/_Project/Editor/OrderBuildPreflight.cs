#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Editor
{
    public static class OrderBuildPreflight
    {
        [MenuItem("TheOrderRoom/Validate Commercial Prototype")]
        public static void Validate()
        {
            int errors = 0;
            var games = Object.FindObjectsByType<OrderGame>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            var cameras = Object.FindObjectsByType<Camera>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            var systems = Object.FindObjectsByType<EventSystem>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            if (games.Length != 1) { Debug.LogError("TOR-PF-01: Expected one OrderGame in active scene"); errors++; }
            if (cameras.Length == 0) { Debug.LogError("TOR-PF-02: Missing camera"); errors++; }
            if (systems.Length != 1) { Debug.LogError("TOR-PF-03: Expected exactly one EventSystem"); errors++; }
            foreach (var file in new[] {"sun.png", "moon.png", "star.png"})
                if (AssetDatabase.LoadAssetAtPath<Sprite>("Assets/_Project/Art/PNG/" + file) == null)
                { Debug.LogError("TOR-PF-04: Missing imported sprite: " + file); errors++; }
            if (errors == 0) Debug.Log("TheOrderRoom preflight passed static scene checks; this does not prove PlayMode or device success.");
            else Debug.LogError("TheOrderRoom preflight failed: " + errors + " issue(s).");
        }
    }
}
#endif
