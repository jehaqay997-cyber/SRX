#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TheOrderRoom.Editor
{
    public static class OrderSceneValidator
    {
        private const string MainScene = "Assets/_Project/Scenes/Main.unity";
        [MenuItem("TheOrderRoom/Validate Project & Scene")]
        public static void ValidateMenu()
        {
            var problems = new List<string>();
            foreach (string name in new[] { "sun", "moon", "star" })
            {
                string path = "Assets/_Project/Art/PNG/" + name + ".png";
                if (AssetDatabase.LoadAssetAtPath<Sprite>(path) == null)
                    problems.Add("Missing sprite import: " + path);
            }
            if (!File.Exists(MainScene)) problems.Add("Missing Main.unity. Run TheOrderRoom/Create Integrated Scene.");
            else
            {
                var current = SceneManager.GetActiveScene();
                if (current.isDirty) problems.Add("Save modified scenes before validation; scene not opened.");
                else
                {
                    var scene = EditorSceneManager.OpenScene(MainScene, OpenSceneMode.Single);
                    var games = Object.FindObjectsOfType<OrderGame>();
                    if (games.Length != 1) problems.Add("Expected exactly one OrderGame component.");
                    var cameras = Object.FindObjectsOfType<Camera>();
                    if (cameras.Length != 1 || !cameras[0].CompareTag("MainCamera")) problems.Add("Expected one tagged MainCamera.");
                    if (Object.FindObjectOfType<EventSystem>() == null) problems.Add("Missing EventSystem.");
                    if (Object.FindObjectOfType<Canvas>() == null) problems.Add("Missing Canvas.");
                    var destinations = Object.FindObjectsOfType<OrderDestination>();
                    var found = new HashSet<string>();
                    foreach (var destination in destinations)
                    {
                        if (destination.Game == null) problems.Add("Unbound destination: " + destination.name);
                        if (!found.Add(destination.Destination)) problems.Add("Duplicate destination: " + destination.Destination);
                    }
                    foreach (string tag in new[] { "SUN", "MOON", "STAR", "TRAY" })
                        if (!found.Contains(tag)) problems.Add("Missing destination: " + tag);
                    foreach (var input in Object.FindObjectsOfType<OrderPointerInput>())
                        if (input.Game == null) problems.Add("Unbound pointer input.");
                    if (!scene.IsValid()) problems.Add("Scene failed to open.");
                }
            }
            if (problems.Count == 0) Debug.Log("TheOrderRoom: structural validation PASSED (not a runtime test).");
            else Debug.LogError("TheOrderRoom validation FAILED:\n" + string.Join("\n", problems));
        }
    }
}
#endif
