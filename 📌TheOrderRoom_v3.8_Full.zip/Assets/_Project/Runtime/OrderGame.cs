using System;
using System.Collections.Generic;
using System.Linq;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    public sealed class OrderGame : MonoBehaviour
    {
        private OrderBoard board;
        private int level;
        private int unlocked;
        // Last authoritative generation observed by this gameplay session.
        private long sessionGeneration = -1;
        private readonly ArtifactLedger artifactLedger = new ArtifactLedger();
        private readonly ContentAccessPolicy contentAccess = new ContentAccessPolicy(new FreeContentEntitlements());
        private string selected;
        private Text status;
        private Text heading;
        private Text collectionText;
        private Text revealText;
        private float revealUntil;
        private readonly ArtifactInspectionState inspection = new ArtifactInspectionState();
        private ArtifactInspectionView inspectionView;
        private int lastInspectionCommandFrame = -1;
        private bool rewardCommitInProgress;
        private bool transitionInProgress;
        private Text inspectionText;
        private readonly HashSet<string> awardedThisSession = new HashSet<string>(StringComparer.Ordinal);
        private Transform pieces;
        private Camera sceneCamera;
        private OrderDestination[] sceneTargets;
        private readonly Stack<Dictionary<string, string>> history = new Stack<Dictionary<string, string>>();
        private static readonly Color Sun = new Color(.93f, .69f, .28f);
        private static readonly Color Moon = new Color(.52f, .73f, .95f);
        private static readonly Color Star = new Color(.74f, .57f, .93f);
        private readonly Dictionary<string, Material> materials = new Dictionary<string, Material>();
        private readonly Dictionary<string, GameObject> pieceById = new Dictionary<string, GameObject>(StringComparer.Ordinal);

        public void Configure(Text title, Text message, Transform world, Camera camera)
        { heading = title; status = message; pieces = world; sceneCamera = camera; }

        public void ConfigureCollection(Text collection, Text reveal)
        {
            collectionText = collection;
            revealText = reveal;
            UpdateCollectionView();
            if (revealText != null) revealText.gameObject.SetActive(false);
        }
        public void ConfigureInspection(ArtifactInspectionView view, Text instructions)
        {
            inspectionView = view;
            inspectionText = instructions;
            if (inspectionView != null) inspectionView.Hide();
            UpdateInspectionText();
        }
        private void UpdateInspectionText()
        {
            if (inspectionText == null) return;
            inspectionText.text = !inspection.IsActive ? "" : inspection.IsRevealed
                ? "SECRET REVEALED - CLAIM THE ARTIFACT"
                : "SCAN THREE SEALS - " + inspection.SealsFound + "/3  |  ROTATE TO FIND MORE";
        }
        public void InspectArtifact()
        {
            if (board == null || !board.Solved) { SetStatus("Solve the puzzle to inspect its artifact"); return; }
            var id = ArtifactPresentation.ForLevel(level);
            if (artifactLedger.Contains(id)) { SetStatus("Artifact already in collection"); return; }
            if (!inspection.IsActive)
            {
                inspection.Begin(id);
                if (inspectionView != null) inspectionView.Show(level);
            }
            UpdateInspectionText();
        }
        public void TurnArtifactLeft() => TurnArtifact(-1);
        public void TurnArtifactRight() => TurnArtifact(1);
        private void TurnArtifact(int direction)
        {
            if (lastInspectionCommandFrame == Time.frameCount) return;
            if (!inspection.IsActive || inspection.IsRevealed || inspectionView == null) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (!inspection.Turn(direction)) return;
            inspectionView.RotateQuarter(direction);
            UpdateInspectionText();
        }
        public void ScanArtifact()
        {
            if (lastInspectionCommandFrame == Time.frameCount) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (!inspection.IsActive || inspectionView == null || !inspectionView.IsSealVisible(inspection.Orientation))
            { SetStatus("Seal is hidden or blocked; rotate the artifact"); return; }
            if (!inspection.Scan()) { SetStatus("No new seal visible from this angle"); return; }
            inspectionView.HighlightSeal(inspection.Orientation);
            UpdateInspectionText();
        }
        public void ClaimArtifact()
        {
            if (lastInspectionCommandFrame == Time.frameCount) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (rewardCommitInProgress || transitionInProgress || board == null || !board.Solved || !inspection.IsRevealed)
            { SetStatus("Inspect and reveal the artifact first"); return; }
            string id = ArtifactPresentation.ForLevel(level);
            if (!string.Equals(inspection.ArtifactId, id, StringComparison.Ordinal))
            { SetStatus("Artifact inspection does not match this level"); return; }
            // The claim state must be valid before durable commit; no fallible state transition follows save.
            if (!inspection.IsActive || inspection.SealsFound != 3 || artifactLedger.Contains(id))
            { SetStatus("Reward already claimed or inspection incomplete"); return; }
            // Stage the entire reward transaction before changing in-memory state.
            // If storage fails, inspection remains claimable and no progress is granted.
            int nextUnlocked = CampaignRules.UnlockAfterCompletion(level, unlocked);
            SaveDocument staged = CreateSaveDocument(nextUnlocked);
            if (!staged.discoveredArtifacts.Contains(id)) staged.discoveredArtifacts.Add(id);
            rewardCommitInProgress = true;
            try
            {
                if (!SaveCurrentSession(staged, out string error))
                { SetStatus("Could not save reward; retry CLAIM"); Debug.LogWarning("Reward save failed: " + error); return; }
            }
            finally { rewardCommitInProgress = false; }
            // No fallible I/O occurs after the durable save succeeds.
            if (!inspection.TryClaim(id))
            {
                // A successful journal write is authoritative; force a safe reload rather than
                // continuing with an inconsistent in-memory reward state.
                Debug.LogError("Reward saved but local inspection state diverged; reload scene to recover");
                enabled = false;
                return;
            }
            artifactLedger.Discover(id);
            unlocked = nextUnlocked;
            if (inspectionView != null) inspectionView.Hide();
            RevealArtifact(id);
            UpdateCollectionView(); UpdateInspectionText();
            SetStatus("Artifact collected - next room unlocked");
        }
        private void Update()
        {
            if (revealText != null && revealText.gameObject.activeSelf && Time.unscaledTime >= revealUntil)
                revealText.gameObject.SetActive(false);
        }
        private void UpdateCollectionView()
        {
            if (collectionText == null) return;
            var found = artifactLedger.Snapshot();
            collectionText.text = "COLLECTION  " + found.Length + "/" + OrderLevels.Count +
                (found.Length == 0 ? "\nSolve a room to recover its artifact" :
                 "\n" + string.Join("  |  ", found.Select(ArtifactPresentation.DisplayName)));
        }
        private void RevealArtifact(string id)
        {
            if (revealText == null) return;
            revealText.text = "DISCOVERED: " + ArtifactPresentation.DisplayName(id);
            revealText.gameObject.SetActive(true);
            revealUntil = Time.unscaledTime + 4f;
        }
        private void Start()
        {
            sceneTargets = FindObjectsByType<OrderDestination>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            if (OrderSaveStore.TryLoad(out SaveDocument saved, out string reason))
            {
                // Validate every component in isolation before publishing any restored state.
                var stagedLedger = new ArtifactLedger();
                var positions = new Dictionary<string, string>(StringComparer.Ordinal);
                bool valid = stagedLedger.TryRestore(saved.discoveredArtifacts ?? new List<string>());
                if (valid)
                    foreach (var entry in saved.locations)
                        if (entry == null || string.IsNullOrEmpty(entry.itemId) ||
                            !positions.TryAddCompat(entry.itemId, entry.destination)) { valid = false; break; }
                OrderBoard stagedBoard = null;
                if (valid)
                {
                    try
                    {
                        stagedBoard = OrderLevels.Create(saved.level);
                        valid = stagedBoard.Restore(positions);
                    }
                    catch (Exception e)
                    {
                        valid = false;
                        Debug.LogWarning("TheOrderRoom: restore validation failed: " + e.GetType().Name);
                    }
                }
                if (valid)
                {
                    // Commit is memory-only after validation: no partially restored rewards.
                    // Publish the already validated board directly. LoadLevel would create a
                    // second board and refresh the scene before the restored board is installed.
                    artifactLedger.TryRestore(stagedLedger.Snapshot());
                    sessionGeneration = saved.generation;
                    unlocked = saved.unlockedLevel;
                    CloseInspection();
                    level = saved.level;
                    board = stagedBoard;
                    selected = null;
                    history.Clear();
                    Refresh();
                    UpdateLevelHeader();
                    UpdateCollectionView();
                    SetStatus("Progress restored");
                }
                else
                {
                    unlocked = 0; LoadLevel(0);
                    SetStatus("Saved session rejected; starting without imported rewards");
                }
            }
            else { unlocked = 0; LoadLevel(0); if (reason != "No saved game") SetStatus("Save not loaded: " + reason); }
        }

        public void Select(string id)
        {
            if (inspection.IsActive || transitionInProgress || rewardCommitInProgress ||
                board == null || !contentAccess.CanOpen(ContentCatalog.BasePack) ||
                !board.Items.Any(x => x.Id == id)) return;
            selected = id;
            SetStatus("Selected " + id + " — choose a target");
        }
        // Build the next board in isolation. Publish only after the journal accepts it.
        private bool TryCommitBoard(OrderBoard candidate, out string error)
        {
            var staged = CreateSaveDocument(unlocked, candidate);
            return SaveCurrentSession(staged, out error);
        }
        public void Place(string destination)
        {
            if (inspection.IsActive || transitionInProgress || rewardCommitInProgress ||
                board == null || string.IsNullOrEmpty(selected) || !contentAccess.CanOpen(ContentCatalog.BasePack))
            { SetStatus("Finish the current interaction or select an item"); return; }
            var before = board.Snapshot().ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            var candidate = OrderLevels.Create(level);
            if (!candidate.Restore(before)) { SetStatus("Move staging rejected"); return; }
            if (!candidate.Move(selected, destination, out string moveError))
            { SetStatus("Move rejected: " + moveError); return; }
            if (!TryCommitBoard(candidate, out string saveError))
            { SetStatus("Move not committed: storage unavailable"); Debug.LogWarning(saveError); return; }
            board = candidate;
            if (history.Count >= 64) history.Clear();
            history.Push(before);
            selected = null;
            Refresh();
            if (board.Solved)
            {
                SetStatus("Solved! INSPECT, rotate and SCAN three seals, then CLAIM.");
                InspectArtifact();
            }
            else SetStatus("Item placed");
        }
        public void ResetBoard()
        {
            if (inspection.IsActive || transitionInProgress || rewardCommitInProgress || board == null ||
                !contentAccess.CanOpen(ContentCatalog.BasePack)) return;
            var candidate = OrderLevels.Create(level);
            if (!TryCommitBoard(candidate, out string error))
            { SetStatus("Reset not committed: storage unavailable"); Debug.LogWarning(error); return; }
            board = candidate; CloseInspection(); history.Clear(); selected = null;
            Refresh(); SetStatus("Board reset");
        }
        public void Undo()
        {
            if (inspection.IsActive || transitionInProgress || rewardCommitInProgress || board == null ||
                !contentAccess.CanOpen(ContentCatalog.BasePack) || history.Count == 0)
            { SetStatus("Nothing to undo"); return; }
            var candidate = OrderLevels.Create(level);
            if (!candidate.Restore(history.Peek())) { SetStatus("Undo rejected"); return; }
            if (!TryCommitBoard(candidate, out string error))
            { SetStatus("Undo not committed: storage unavailable"); Debug.LogWarning(error); return; }
            board = candidate; history.Pop(); CloseInspection(); selected = null;
            Refresh(); SetStatus("Move undone");
        }
        public void NextLevel()
        {
            if (transitionInProgress || rewardCommitInProgress || board == null || !contentAccess.CanOpen(ContentCatalog.BasePack) || !board.Solved || !artifactLedger.Contains(ArtifactPresentation.ForLevel(level)) || level + 1 >= OrderLevels.Count || level + 1 > unlocked)
            { SetStatus("Finish this level first"); return; }
            int target = level + 1;
            var staged = new SaveDocument { level = target, unlockedLevel = unlocked,
                discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
            var nextBoard = OrderLevels.Create(target);
            foreach (var pair in nextBoard.Snapshot())
                staged.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
            transitionInProgress = true;
            try
            {
                if (!SaveCurrentSession(staged, out string error))
                { SetStatus("Could not save next room; retry"); Debug.LogWarning("Level transition save failed: " + error); return; }
                CloseInspection();
                level = target;
                board = nextBoard;
                selected = null;
                history.Clear();
                Refresh();
                UpdateLevelHeader();
            }
            finally { transitionInProgress = false; }
        }
        // Public level navigation is a durable transition, not an in-memory reset.
        public void LoadLevel(int index)
        {
            if (transitionInProgress || rewardCommitInProgress || inspection.IsActive ||
                index < 0 || index >= OrderLevels.Count || index > unlocked ||
                !contentAccess.CanOpen(ContentCatalog.BasePack)) return;
            if (board != null && index == level) return;
            var candidate = OrderLevels.Create(index);
            if (board != null)
            {
                var staged = new SaveDocument { level = index, unlockedLevel = unlocked,
                    discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
                foreach (var pair in candidate.Snapshot())
                    staged.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
                transitionInProgress = true;
                try
                {
                    if (!SaveCurrentSession(staged, out string error))
                    { SetStatus("Level not changed: save failed"); Debug.LogWarning(error); return; }
                }
                finally { transitionInProgress = false; }
            }
            CloseInspection(); level = index; board = candidate; selected = null; history.Clear(); Refresh();
            UpdateLevelHeader();
        }
        private void UpdateLevelHeader()
        {
            if (heading != null) heading.text = CampaignNarrative.Title(level) + "  /  " + (level + 1);
            SetStatus(level % CampaignRules.LevelsPerChapter == 2
                ? "GATE RULE: For each symbol, place lower-numbered items in A and higher-numbered items in B."
                : CampaignNarrative.Hook(level));
        }
        private void CloseInspection()
        {
            inspection.Cancel();
            if (inspectionView != null) inspectionView.Hide();
            UpdateInspectionText();
        }
        private SaveDocument CreateSaveDocument(int targetUnlocked, OrderBoard sourceBoard = null)
        {
            var data = new SaveDocument { level = level, unlockedLevel = targetUnlocked,
                discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
            foreach (var pair in (sourceBoard ?? board).Snapshot())
                data.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
            return data;
        }
        private bool SaveCurrentSession(SaveDocument document, out string reason)
        {
            bool saved = OrderSaveStore.TrySaveIfCurrent(document, sessionGeneration,
                out long committedGeneration, out reason);
            if (saved)
            {
                sessionGeneration = committedGeneration;
                return true;
            }
            if (reason != null && (reason.StartsWith("Stale save session", StringComparison.Ordinal) ||
                reason.StartsWith("Commit status unknown", StringComparison.Ordinal) ||
                reason.StartsWith("Save history changed", StringComparison.Ordinal)))
            {
                Debug.LogError("TheOrderRoom: session invalidated; reload scene before further writes. " + reason);
                enabled = false;
            }
            return false;
        }

        private void Persist()
        {
            if (board == null) return;
            if (!SaveCurrentSession(CreateSaveDocument(unlocked), out string error))
                Debug.LogWarning("TheOrderRoom save: " + error);
        }
        private void SetStatus(string message) { if (status != null) status.text = message; }
        private void Refresh()
        {
            if (board == null) return;
            if (sceneTargets != null)
            {
                var validDestinations = new HashSet<string>(board.Compartments.Select(x => x.Id), StringComparer.Ordinal);
                validDestinations.Add(OrderBoard.Tray);
                foreach (var target in sceneTargets)
                    if (target != null) target.gameObject.SetActive(validDestinations.Contains(target.Destination));
            }
            if (pieces == null) return;
            var currentIds = new HashSet<string>(board.Items.Select(x => x.Id), StringComparer.Ordinal);
            foreach (var stale in pieceById.Keys.Where(x => !currentIds.Contains(x)).ToArray())
            {
                if (pieceById[stale] != null) Destroy(pieceById[stale]);
                pieceById.Remove(stale);
            }
            int index = 0;
            var slots = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var item in board.Items)
            {
                string dest = board.Location(item.Id);
                slots.TryGetValue(dest, out int slot);
                slots[dest] = slot + 1;
                Vector3 pos = dest == OrderBoard.Tray
                    ? new Vector3(-4.2f + (index % 5) * 1.9f, .5f, -2.1f + (index / 5) * .85f)
                    : new Vector3(TargetX(dest) + ((slot % 3) - 1) * .65f, .5f, TargetZ(dest) + (slot / 3) * .6f);
                if (!pieceById.TryGetValue(item.Id, out var go) || go == null)
                {
                    go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    go.name = item.Id; go.transform.SetParent(pieces, false);
                    go.transform.localScale = new Vector3(.65f, .65f, .65f);
                    go.GetComponent<Renderer>().sharedMaterial = MaterialFor(item.Tag);
                    var click = go.AddComponent<OrderClick>(); click.Game = this; click.ItemId = item.Id;
                    pieceById[item.Id] = go;
                }
                go.transform.localPosition = pos; index++;
            }
        }
        private static float TargetX(string destination)
        {
            if (destination.StartsWith("SUN", StringComparison.Ordinal)) return -3.4f;
            if (destination.StartsWith("MOON", StringComparison.Ordinal)) return 0f;
            return 3.4f;
        }
        private static float TargetZ(string destination)
        {
            return destination.EndsWith("_A", StringComparison.Ordinal) ? .5f :
                   destination.EndsWith("_B", StringComparison.Ordinal) ? 2.0f : 1.1f;
        }
        private Material MaterialFor(string tag)
        {
            if (materials.TryGetValue(tag, out var cached)) return cached;
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard") ?? Shader.Find("Sprites/Default");
            if (shader == null) throw new InvalidOperationException("No supported shader found.");
            var material = new Material(shader) { color = tag == "SUN" ? Sun : tag == "MOON" ? Moon : Star };
            materials[tag] = material; return material;
        }
        private void OnDestroy()
        {
            foreach (var pair in materials) if (pair.Value != null) Destroy(pair.Value);
            materials.Clear(); pieceById.Clear();
        }
        // Screen-space UI raycast avoids pointer-ID mismatches between Input System and EventSystem.
        // UI consumes the tap before any world Physics.Raycast is attempted.
        private static readonly List<RaycastResult> UiRaycastHits = new List<RaycastResult>(16);
        private static bool IsScreenPointOverUi(Vector2 screenPoint)
        {
            var eventSystem = EventSystem.current;
            if (eventSystem == null) return false;
            var data = new PointerEventData(eventSystem) { position = screenPoint };
            UiRaycastHits.Clear();
            try
            {
                eventSystem.RaycastAll(data, UiRaycastHits);
                return UiRaycastHits.Count > 0;
            }
            finally { UiRaycastHits.Clear(); }
        }
        public void HandleWorldTap(Vector2 screenPoint, int pointerId = -1)
        {
            if (!isActiveAndEnabled || inspection.IsActive || transitionInProgress || rewardCommitInProgress || sceneCamera == null || !contentAccess.CanOpen(ContentCatalog.BasePack) ||
                IsScreenPointOverUi(screenPoint)) return;
            const int inspectionLayer = 30;
            int worldMask = sceneCamera.cullingMask & ~(1 << inspectionLayer);
            if (!Physics.Raycast(sceneCamera.ScreenPointToRay(screenPoint), out var hit, 100f,
                worldMask, QueryTriggerInteraction.Ignore)) return;
            var item = hit.collider.GetComponentInParent<OrderClick>();
            if (item != null) { Select(item.ItemId); return; }
            var target = hit.collider.GetComponentInParent<OrderDestination>();
            if (target != null) Place(target.Destination);
        }
    }
    internal static class DictionaryExtensions
    {
        public static bool TryAddCompat(this Dictionary<string, string> map, string key, string value)
        { if (map.ContainsKey(key)) return false; map.Add(key, value); return true; }
    }
    public sealed class OrderClick : MonoBehaviour { public OrderGame Game; public string ItemId; }
    public sealed class OrderDestination : MonoBehaviour { public OrderGame Game; public string Destination; }
    public sealed class OrderPointerInput : MonoBehaviour
    {
        public OrderGame Game;
        private int suppressMouseUntilFrame = -1;
        private int lastDispatchFrame = -1;
        private bool touchGestureConsumed;
        private void Update()
        {
            if (Game == null || lastDispatchFrame == Time.frameCount) return;
#if ENABLE_INPUT_SYSTEM
            var touchscreen = UnityEngine.InputSystem.Touchscreen.current;
            if (touchscreen != null)
            {
                bool touchPresent = false;
                int activeCount = 0;
                foreach (var touch in touchscreen.touches)
                    if (touch.press.isPressed || touch.press.wasPressedThisFrame) activeCount++;
                touchPresent = activeCount > 0;
                if (touchPresent)
                {
                    suppressMouseUntilFrame = Time.frameCount + 2;
                    // Ignore multitouch completely; never transfer ownership mid-gesture.
                    if (activeCount != 1) touchGestureConsumed = true;
                    if (!touchGestureConsumed && activeCount == 1)
                        foreach (var touch in touchscreen.touches)
                            if (touch.press.wasPressedThisFrame)
                            {
                                touchGestureConsumed = true;
                                lastDispatchFrame = Time.frameCount;
                                Game.HandleWorldTap(touch.position.ReadValue(), touch.touchId.ReadValue());
                                return;
                            }
                    return;
                }
                touchGestureConsumed = false;
            }
            if (Time.frameCount <= suppressMouseUntilFrame) return;
            var mouse = UnityEngine.InputSystem.Mouse.current;
            if (mouse != null && mouse.leftButton.wasPressedThisFrame)
            {
                lastDispatchFrame = Time.frameCount;
                Game.HandleWorldTap(mouse.position.ReadValue());
            }
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.touchCount > 0)
            {
                suppressMouseUntilFrame = Time.frameCount + 2;
                if (Input.touchCount != 1) touchGestureConsumed = true;
                if (!touchGestureConsumed && Input.touchCount == 1)
                {
                    var touch = Input.GetTouch(0);
                    if (touch.phase == TouchPhase.Began)
                    {
                        touchGestureConsumed = true;
                        lastDispatchFrame = Time.frameCount;
                        Game.HandleWorldTap(touch.position, touch.fingerId);
                    }
                }
            }
            else if (Time.frameCount > suppressMouseUntilFrame && Input.GetMouseButtonDown(0))
            {
                lastDispatchFrame = Time.frameCount;
                Game.HandleWorldTap(Input.mousePosition);
            }
            if (Input.touchCount == 0) touchGestureConsumed = false;
#endif
        }
    }
}
