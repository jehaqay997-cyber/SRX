using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    [Serializable] public sealed class SaveEntry { public string itemId; public string destination; }
    [Serializable] public sealed class SaveDocument
    {
        public int schemaVersion = 1;
        // Monotonically increasing save generation; absent in legacy v1 saves (defaults to zero).
        public long generation;
        public int level;
        public int unlockedLevel;
        public List<SaveEntry> locations = new List<SaveEntry>();
        public List<string> discoveredArtifacts = new List<string>();
    }
    [Serializable] internal sealed class SaveEnvelope { public string payload; public string checksum; }

    public static class OrderSaveStore
    {
        private static readonly object SaveGate = new object();
        private const string FileName = "the_order_room_v1.json";
        private const long MaxSaveBytes = 1024 * 1024;
        private static string PathName => Path.Combine(Application.persistentDataPath, FileName);
        private static string BackupName => PathName + ".bak";
        private static string WriterLockName => PathName + ".writer.lock";
        private static string PreviousName => PathName + ".previous";
        // New writes are immutable generations. Legacy files are read-only migration inputs.
        private const int RetainedGenerations = 8;
        // Invalid journal entries are preserved, but writes fail closed once forensic
        // evidence exceeds a bounded quota. A maintenance tool must review them.
        private const int MaxInvalidGenerations = 32;
        private static string GenerationPrefix => PathName + ".g";
        private static string GenerationPath(long generation) => GenerationPrefix + generation.ToString("D20", CultureInfo.InvariantCulture) + ".json";
        private static string[] GenerationFiles()
        {
            string directory = Application.persistentDataPath;
            if (!Directory.Exists(directory)) return Array.Empty<string>();
            var candidates = Directory.GetFiles(directory, FileName + ".g*.json", SearchOption.TopDirectoryOnly);
            var valid = new List<string>();
            foreach (string path in candidates)
            {
                string name = Path.GetFileName(path);
                string prefix = FileName + ".g";
                if (!name.StartsWith(prefix, StringComparison.Ordinal) || !name.EndsWith(".json", StringComparison.Ordinal)) continue;
                string digits = name.Substring(prefix.Length, name.Length - prefix.Length - 5);
                if (digits.Length == 20 && long.TryParse(digits, NumberStyles.None, CultureInfo.InvariantCulture, out long number) &&
                    number >= 0 && string.Equals(path, GenerationPath(number), StringComparison.Ordinal)) valid.Add(path);
            }
            return valid.ToArray();
        }
        private static IEnumerable<string> AllSaveFiles()
        {
            yield return PathName;
            yield return BackupName;
            yield return PreviousName;
            foreach (string file in GenerationFiles()) yield return file;
        }

        private static bool ValidArtifacts(List<string> ids)
        {
            // Null represents an older v1 save, before artifact journaling was introduced.
            if (ids == null) return true;
            if (ids.Count > 1024) return false;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var id in ids)
                if (string.IsNullOrWhiteSpace(id) || id.Length > 128 || !seen.Add(id)) return false;
            foreach (var id in ids)
            {
                bool known = false;
                for (int level = 0; level < OrderLevels.Count; level++)
                    if (string.Equals(id, ArtifactPresentation.ForLevel(level), StringComparison.Ordinal))
                    { known = true; break; }
                if (!known) return false;
            }
            return true;
        }

        private static bool ValidCampaignProgress(SaveDocument document)
        {
            if (document == null || document.discoveredArtifacts == null) return true;
            foreach (string id in document.discoveredArtifacts)
            {
                int artifactLevel = -1;
                for (int i = 0; i < OrderLevels.Count; i++)
                    if (string.Equals(ArtifactPresentation.ForLevel(i), id, StringComparison.Ordinal))
                    { artifactLevel = i; break; }
                if (artifactLevel < 0 || artifactLevel > document.unlockedLevel) return false;
            }
            return true;
        }

        // A checksum authenticates bytes against accidental corruption, not gameplay validity.
        // Validate the exact board before a save can be selected or committed.
        public static bool ValidBoardSnapshot(SaveDocument document)
        {
            if (document == null || document.locations == null ||
                document.level < 0 || document.level >= OrderLevels.Count) return false;
            try
            {
                var positions = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var entry in document.locations)
                {
                    if (entry == null || string.IsNullOrWhiteSpace(entry.itemId) ||
                        string.IsNullOrWhiteSpace(entry.destination) ||
                        !positions.TryAddCompat(entry.itemId, entry.destination)) return false;
                }
                var candidate = OrderLevels.Create(document.level);
                return candidate.Restore(positions);
            }
            catch (Exception) { return false; }
        }

        private static bool ValidLocations(List<SaveEntry> entries)
        {
            if (entries == null || entries.Count > 256) return false;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var entry in entries)
            {
                if (entry == null || string.IsNullOrWhiteSpace(entry.itemId) ||
                    entry.itemId.Length > 128 || string.IsNullOrWhiteSpace(entry.destination) ||
                    entry.destination.Length > 128 || !seen.Add(entry.itemId)) return false;
            }
            return true;
        }

        public static bool TryLoad(out SaveDocument data, out string reason)
        {
            lock (SaveGate)
            {
                try { return TryLoadCore(out data, out reason); }
                catch (Exception e) { data = null; reason = "Save enumeration failed: " + e.GetType().Name; return false; }
            }
        }

        private static bool TryLoadCore(out SaveDocument data, out string reason)
        {
            data = null;
            IEnumerable<string> paths = AllSaveFiles();
            SaveDocument newest = null;
            bool newestIsJournal = false;
            string errors = "";
            foreach (string path in paths)
            {
                if (TryRead(path, out SaveDocument candidate, out string error))
                {
                    bool isJournal = IsJournalPath(path);
                    // Immutable committed journal entries outrank mutable legacy migration files.
                    // Still scan every candidate: a future schema must block recovery.
                    if (ShouldSelectCandidate(newest != null, newestIsJournal,
                        newest == null ? -1 : newest.generation, isJournal, candidate.generation))
                    {
                        newest = candidate;
                        newestIsJournal = isJournal;
                    }
                }
                else
                {
                    // A future-version file takes precedence over all recovery candidates.
                    if (error == "Unsupported save version")
                    {
                        reason = error;
                        return false;
                    }
                    if (error != "Missing file")
                        if (errors.Length < 2048)
                            errors += Path.GetFileName(path) + ": " + error + "; ";
                }
            }
            if (newest != null) { data = newest; reason = null; return true; }
            reason = errors.Length == 0 ? "No saved game" : errors;
            return false;
        }

        // A legacy root/backup is a migration input, never authoritative over a
        // validated immutable journal. This prevents stale or copied legacy files
        // from replacing the last committed journal state.
        internal static bool ShouldSelectCandidate(bool hasCurrent, bool currentJournal,
            long currentGeneration, bool candidateJournal, long candidateGeneration)
        {
            if (!hasCurrent) return true;
            if (candidateJournal != currentJournal) return candidateJournal;
            return candidateGeneration > currentGeneration;
        }

        private static bool IsJournalPath(string path)
        {
            string name = Path.GetFileName(path);
            string prefix = FileName + ".g";
            return name.StartsWith(prefix, StringComparison.Ordinal) &&
                   name.EndsWith(".json", StringComparison.Ordinal) &&
                   name.Length == prefix.Length + 20 + 5;
        }

        private static bool TryRead(string path, out SaveDocument data, out string reason)
        {
            data = null;
            if (!File.Exists(path)) { reason = "Missing file"; return false; }
            try
            {
                if (new FileInfo(path).Length > MaxSaveBytes) { reason = "Save exceeds size limit"; return false; }
                string json = File.ReadAllText(path, Encoding.UTF8);
                var envelope = JsonUtility.FromJson<SaveEnvelope>(json);
                if (envelope == null || string.IsNullOrEmpty(envelope.payload) || string.IsNullOrEmpty(envelope.checksum) ||
                    !FixedTimeEquals(envelope.checksum, Hash(envelope.payload)))
                { reason = "Checksum mismatch or invalid envelope"; return false; }
                var parsed = JsonUtility.FromJson<SaveDocument>(envelope.payload);
                if (parsed == null) { reason = "Invalid payload"; return false; }
                if (parsed.schemaVersion > 1) { reason = "Unsupported save version"; return false; }
                // The filename and payload must agree; otherwise a renamed or corrupted journal entry
                // could win recovery selection using a forged generation number.
                string name = Path.GetFileName(path);
                if (name.StartsWith(FileName + ".g", StringComparison.Ordinal) &&
                    name.EndsWith(".json", StringComparison.Ordinal) &&
                    !string.Equals(path, GenerationPath(parsed.generation), StringComparison.Ordinal))
                { reason = "Journal generation mismatch"; return false; }
                if (parsed.schemaVersion != 1 || parsed.generation < 0 || !ValidLocations(parsed.locations) || parsed.level < 0 || parsed.level >= OrderLevels.Count || parsed.unlockedLevel < parsed.level || parsed.unlockedLevel >= OrderLevels.Count || parsed.locations == null || parsed.locations.Count > 256 || !ValidArtifacts(parsed.discoveredArtifacts) || !ValidCampaignProgress(parsed) || !ValidBoardSnapshot(parsed))
                { reason = "Invalid save data"; return false; }
                data = parsed; reason = null; return true;
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is ArgumentException || e is NotSupportedException)
            { reason = e.GetType().Name; return false; }
            catch (Exception) { reason = "Invalid save JSON"; return false; }
        }

        public static bool TrySave(SaveDocument data, out string reason)
        {
            lock (SaveGate)
            {
                // Cross-process exclusion: FileShare.None is released by the OS even if
                // the process crashes. The lock FILE remains, but is not itself a lock.
                // All writers must use this repository; malicious writers are out of scope.
                try
                {
                    Directory.CreateDirectory(Application.persistentDataPath);
                    using (var writerLock = new FileStream(WriterLockName, FileMode.OpenOrCreate,
                        FileAccess.ReadWrite, FileShare.None))
                    {
                        return TrySaveCore(data, out reason);
                    }
                }
                catch (IOException) { reason = "Save writer busy or storage unavailable"; return false; }
                catch (UnauthorizedAccessException) { reason = "Save writer access denied"; return false; }
                catch (Exception e) { reason = "Save inspection failed: " + e.GetType().Name; return false; }
            }
        }

        // Optimistic concurrency: the caller must present the last committed generation
        // observed by this gameplay session. The check and commit share the writer lock.
        // -1 means a genuinely empty store, not an unreadable/corrupt store.
        public static bool TrySaveIfCurrent(SaveDocument data, long expectedGeneration,
            out long committedGeneration, out string reason)
        {
            committedGeneration = -1;
            if (expectedGeneration < -1)
            { reason = "Invalid expected generation"; return false; }
            lock (SaveGate)
            {
                try
                {
                    Directory.CreateDirectory(Application.persistentDataPath);
                    using (var writerLock = new FileStream(WriterLockName, FileMode.OpenOrCreate,
                        FileAccess.ReadWrite, FileShare.None))
                    {
                        if (TryLoadCore(out SaveDocument current, out string loadReason))
                        {
                            if (current.generation != expectedGeneration)
                            { reason = "Stale save session; reload required"; return false; }
                        }
                        else if (HasAnySaveFile())
                        {
                            reason = "Existing save cannot be verified: " +
                                (loadReason == "Unsupported save version" ? loadReason : "recovery required");
                            return false;
                        }
                        else if (expectedGeneration != -1)
                        { reason = "Save history changed; reload required"; return false; }

                        if (!TrySaveCore(data, out reason)) return false;
                        // Read the authoritative committed record while still holding the lock.
                        if (!TryLoadCore(out SaveDocument committed, out string verifyReason))
                        {
                            reason = "Commit status unknown; reload required: " + verifyReason;
                            return false;
                        }
                        committedGeneration = committed.generation;
                        return true;
                    }
                }
                catch (IOException) { reason = "Save writer busy or storage unavailable"; return false; }
                catch (UnauthorizedAccessException) { reason = "Save writer access denied"; return false; }
                catch (Exception e) { reason = "Save transaction failed: " + e.GetType().Name; return false; }
            }
        }

        private static bool TrySaveCore(SaveDocument data, out string reason)
        {
            reason = null;
            if (data == null || data.schemaVersion != 1 || data.generation < 0 ||
                !ValidLocations(data.locations) || data.level < 0 || data.level >= OrderLevels.Count ||
                data.unlockedLevel < data.level || data.unlockedLevel >= OrderLevels.Count ||
                !ValidArtifacts(data.discoveredArtifacts) || !ValidCampaignProgress(data) || !ValidBoardSnapshot(data))
            { reason = "Invalid save data"; return false; }

            IEnumerable<string> paths = AllSaveFiles();
            long maximumGeneration = -1;
            foreach (string path in paths)
            {
                if (!File.Exists(path)) continue;
                if (TryRead(path, out SaveDocument existing, out string readError))
                {
                    if (existing.generation > maximumGeneration) maximumGeneration = existing.generation;
                }
                else
                {
                    // Preserve unreadable files, but allow a new generation if another valid
                    // generation exists. Unknown future schemas are always a hard stop.
                    if (readError == "Unsupported save version")
                    { reason = "Unsupported save version"; return false; }
                    if (readError == "IOException" || readError == "UnauthorizedAccessException")
                    { reason = "Cannot inspect existing save: " + readError; return false; }
                }
            }
            // Never silently consume unlimited storage when invalid entries accumulate.
            // Preserve evidence; require explicit maintenance instead of deleting it.
            int invalidGenerations = 0;
            foreach (string journalPath in GenerationFiles())
            {
                if (!TryRead(journalPath, out _, out string journalError))
                {
                    if (journalError == "Unsupported save version")
                    { reason = "Unsupported save version"; return false; }
                    invalidGenerations++;
                }
            }
            if (!WithinInvalidGenerationBudget(invalidGenerations))
            { reason = "Invalid save journal quota exceeded; manual recovery required"; return false; }
            if (maximumGeneration < 0 && HasAnySaveFile())
            { reason = "No valid recovery generation; refusing to overwrite unknown data"; return false; }
            // The next generation must be greater than BOTH the newest validated
            // payload and every allocated journal filename, including corrupt ones.
            // This preserves append-only semantics without overwriting evidence.
            long highestAllocated = HighestAllocatedGeneration();
            if (maximumGeneration == long.MaxValue || highestAllocated == long.MaxValue)
            { reason = "Save generation exhausted"; return false; }
            long nextGeneration = NextGeneration(maximumGeneration, highestAllocated);

            // Serialize a private copy: never mutate the caller's document before durable commit.
            var staged = JsonUtility.FromJson<SaveDocument>(JsonUtility.ToJson(data));
            staged.generation = nextGeneration;
            // A fresh filename is the commit record. Never overwrite an existing generation.
            // A crash before File.Move leaves only an ignored temporary file.
            string destination = GenerationPath(staged.generation);
            string temporary = PathName + ".pending-" + Guid.NewGuid().ToString("N");
            try
            {
                string payload = JsonUtility.ToJson(staged);
                string json = JsonUtility.ToJson(new SaveEnvelope { payload = payload, checksum = Hash(payload) });
                if (Encoding.UTF8.GetByteCount(json) > MaxSaveBytes)
                { reason = "Save exceeds size limit"; return false; }
                Directory.CreateDirectory(Application.persistentDataPath);
                if (File.Exists(destination)) { reason = "Generation already exists"; return false; }
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                { writer.Write(json); writer.Flush(); stream.Flush(true); }
                if (!TryRead(temporary, out SaveDocument verified, out string temporaryError) ||
                    verified.generation != staged.generation)
                { reason = "Temporary save validation failed: " + temporaryError; return false; }
                // File.Move on the same directory is the single visibility transition.
                // Do not claim power-loss durability without device/filesystem tests.
                File.Move(temporary, destination);
                // A successful rename is the commit point. Verify the committed
                // entry before reporting success; never delete or overwrite it on
                // a verification failure.
                if (!TryRead(destination, out SaveDocument committed, out string committedError) ||
                    committed.generation != staged.generation)
                {
                    reason = "Committed journal verification failed: " + committedError;
                    return false;
                }
                // The commit point has passed. Cleanup must never change a successful
                // transaction into a reported failure (which would invite duplicate retries).
                try { PruneOldGenerations(); }
                catch (Exception cleanupError)
                { Debug.LogWarning("Save committed; journal cleanup deferred: " + cleanupError.GetType().Name); }
                return true;
            }
            catch (Exception e) { reason = e.GetType().Name; return false; }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        // Never reuse a journal filename, even if its contents are unreadable.
        // Otherwise an invalid higher generation can make every future save fail
        // with "Generation already exists" despite valid older recovery copies.
        internal static long NextGeneration(long highestValid, long highestAllocated)
        {
            long highest = Math.Max(highestValid, highestAllocated);
            if (highest == long.MaxValue) throw new OverflowException("Save generation exhausted");
            return highest + 1;
        }

        private static long HighestAllocatedGeneration()
        {
            long highest = -1;
            foreach (string path in GenerationFiles())
            {
                string name = Path.GetFileName(path);
                string prefix = FileName + ".g";
                string digits = name.Substring(prefix.Length, 20);
                if (long.TryParse(digits, NumberStyles.None, CultureInfo.InvariantCulture, out long value)
                    && value > highest) highest = value;
            }
            return highest;
        }

        private static bool HasAnySaveFile()
        {
            foreach (string path in AllSaveFiles()) if (File.Exists(path)) return true;
            return false;
        }

        // Retention is counted over VERIFIED generations, not all filenames.
        // Invalid entries remain untouched, and two newer valid recovery points
        // must remain after any deletion.
        internal static bool MayPruneGeneration(bool candidateValid, int verifiedNewer)
            => candidateValid && verifiedNewer >= 2;

        internal static bool WithinInvalidGenerationBudget(int invalidCount)
            => invalidCount >= 0 && invalidCount <= MaxInvalidGenerations;

        internal static int RemovableValidGenerationCount(int validCount)
            => Math.Max(0, validCount - RetainedGenerations);

        private static void PruneOldGenerations()
        {
            // Read and classify before deleting anything. A corrupt generation
            // never consumes a slot in the verified retention budget.
            var files = new List<string>(GenerationFiles());
            files.Sort(StringComparer.Ordinal);
            var verified = new List<string>();
            foreach (string path in files)
                if (TryRead(path, out _, out _)) verified.Add(path);

            int removable = RemovableValidGenerationCount(verified.Count);
            for (int i = 0; i < removable; i++)
            {
                if (!MayPruneGeneration(true, verified.Count - i - 1)) break;
                try { File.Delete(verified[i]); }
                catch (IOException) { break; }
                catch (UnauthorizedAccessException) { break; }
            }
        }

        private static string Hash(string value)
        {
            using (var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(value));
                return Convert.ToBase64String(bytes);
            }
        }
        private static bool FixedTimeEquals(string a, string b)
        {
            byte[] left, right;
            try { left = Convert.FromBase64String(a); right = Convert.FromBase64String(b); }
            catch (FormatException) { return false; }
            if (left.Length != right.Length) return false;
            int diff = 0;
            for (int i = 0; i < left.Length; i++) diff |= left[i] ^ right[i];
            return diff == 0;
        }
    }
}
