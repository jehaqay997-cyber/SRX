#!/usr/bin/env python3
"""Deterministic Unity source-governance gate. Does not compile or profile the game."""
from pathlib import Path
import json
import hashlib
import re
import sys
import zipfile
root = Path(__file__).resolve().parents[1]
project = root / "Assets" / "_Project"
errors = []
assemblies = {}
for path in project.rglob("*.asmdef"):
    try:
        info = json.loads(path.read_text(encoding="utf-8"))
        name = info["name"]
        if name in assemblies:
            errors.append("Duplicate assembly name: " + name)
        assemblies[name] = (path, info)
    except (OSError, json.JSONDecodeError, KeyError) as exc:
        errors.append(f"Invalid assembly definition {path}: {exc}")
for name, (path, info) in assemblies.items():
    for dependency in info.get("references", []):
        if dependency.startswith("TheOrderRoom.") and dependency not in assemblies:
            errors.append(f"Unresolved internal assembly {dependency} in {path}")
    if name in ("TheOrderRoom.Domain", "TheOrderRoom.AppCore"):
        if info.get("noEngineReferences") is not True:
            errors.append("Pure assembly has engine references: " + name)
        for file in path.parent.rglob("*.cs"):
            text = file.read_text(encoding="utf-8")
            if re.search(r"^\s*using\s+Unity(?:Engine|Editor)\s*;", text, re.M):
                errors.append("Unity dependency in pure assembly: " + str(file))
meta_ids = {}
for path in (root / "Assets").rglob("*.meta"):
    match = re.search(r"^guid:\s*([0-9a-fA-F]{32})\s*$", path.read_text(encoding="utf-8", errors="replace"), re.M)
    if not match:
        errors.append("Missing or invalid GUID: " + str(path))
    elif match.group(1).lower() in meta_ids:
        errors.append("Duplicate GUID: " + str(path) + " / " + str(meta_ids[match.group(1).lower()]))
    else:
        meta_ids[match.group(1).lower()] = path
for path in (root / "Assets").rglob("*.cs"):
    if not Path(str(path) + ".meta").exists():
        errors.append("Missing source .meta: " + str(path))
# Detect stale references to explicitly owned internal assembly APIs.
if "TheOrderRoom.Infrastructure" not in assemblies:
    errors.append("Missing persistence infrastructure assembly")
report = {"gate": "source_governance", "passed": not errors,
          "asmdefs": len(assemblies), "guids": len(meta_ids),
          "csharp": len(list(project.rglob("*.cs"))), "errors": errors,
          "unity_compiled": False, "nunit_executed": False,
          "android_measured": False}
(root / "Verification" / "GOVERNANCE_v4.22.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
sys.exit(0 if not errors else 1)
