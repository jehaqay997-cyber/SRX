#!/usr/bin/env python3
"""Checks responsive layout contracts and independently tests layout row geometry."""
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'Assets/_Project/Runtime/OrderScreenLayout.cs'
TESTS = ROOT / 'Assets/_Project/Tests/EditMode/ResponsiveLayoutSafetyTests.cs'


def calculate_slot_width(screen_width, screen_height, safe_width, portrait, count, desired):
    reference_width, reference_height = (720., 1280.) if portrait else (1280., 720.)
    scale = min(screen_width / reference_width, screen_height / reference_height)
    available = safe_width / scale
    return min(desired, available / count * .86), available


def verify():
    source = SOURCE.read_text(encoding='utf-8')
    tests = TESTS.read_text(encoding='utf-8')
    checks = {
        'clipped_safe_area': 'Rect.MinMaxRect(xMin, yMin, xMax, yMax)' in source,
        'scaler_mode_saved': 'originalScaleMode = scaler.uiScaleMode;' in source,
        'scaler_mode_restored': 'scaler.uiScaleMode = originalScaleMode;' in source,
        'match_setting_saved': 'originalMatchWidthOrHeight = scaler.matchWidthOrHeight;' in source,
        'match_setting_restored': 'scaler.matchWidthOrHeight = originalMatchWidthOrHeight;' in source,
        'slot_based_action_row': 'PlaceInSlots(actions[i]' in source,
        'landscape_control_heights': 'portrait ? 58 : 44' in source and 'portrait ? 50 : 36' in source,
        'landscape_status_lane': 'portrait ? .245f : .26f' in source,
        'slot_based_inspection_row': 'PlaceInSlots(inspection[i]' in source,
        'bounded_width': 'availableLayoutWidth / slots * .86f' in source,
        'editor_regression_tests': 'DisableRestoresCompleteCanvasScalerConfiguration' in tests and 'ActionSlotWidthIsBoundedByAvailableLayoutWidth' in tests,
    }
    # The control bar has four stacked lanes below the camera viewport.
    # All intervals must remain disjoint at the reference virtual height.
    lanes = {
        'landscape': [(0.055, 44), (0.125, 44), (0.192, 36), (0.26, 45)],
        'portrait': [(0.045, 58), (0.115, 58), (0.19, 50), (0.245, 85)],
    }
    for label, (reference_height, camera_bottom) in {'landscape': (720, .30), 'portrait': (1280, .28)}.items():
        ranges = sorted([(y * reference_height - h / 2, y * reference_height + h / 2) for y, h in lanes[label]])
        checks['nonoverlapping_bottom_lanes_' + label] = all(ranges[i][1] <= ranges[i + 1][0] for i in range(len(ranges) - 1))
        checks['lanes_inside_camera_boundary_' + label] = ranges[0][0] >= 0 and ranges[-1][1] <= reference_height * camera_bottom
    scenarios = [
        (1280, 720, 1280, False),
        (2560, 1440, 2560, False),
        (2520, 1080, 2400, False),
        (1920, 1080, 1740, False),
        (720, 1280, 680, True),
        (1080, 1920, 920, True),
        (640, 360, 600, False),
    ]
    cases = []
    for w, h, safe, portrait in scenarios:
        widths = []
        for count, desired in ((4, 180), (5, 180 if not portrait else 130)):
            button, available = calculate_slot_width(w, h, safe, portrait, count, desired)
            gap = available / count - button
            passed = math.isfinite(button) and button > 0 and gap >= -1e-8
            cases.append({'resolution': f'{w}x{h}', 'safe_width_px': safe, 'slots': count,
                          'button_width_canvas_units': round(button, 3), 'gap_canvas_units': round(gap, 3),
                          'pass': passed})
            widths.append(passed)
        checks[f'geometry_{w}x{h}_{safe}'] = all(widths)
    return {'status': 'STATIC_PASS_ONLY' if all(checks.values()) else 'FAIL',
            'checks': checks, 'geometry_cases': cases,
            'unity_compilation_verified': False, 'unity_tests_executed': False}


def main():
    report = verify()
    (ROOT / 'Verification/RESPONSIVE_LAYOUT_v4.31.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'checks_passed': sum(report['checks'].values()),
                      'checks_total': len(report['checks']), 'geometry_cases': len(report['geometry_cases'])}))
    return 0 if report['status'] == 'STATIC_PASS_ONLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
