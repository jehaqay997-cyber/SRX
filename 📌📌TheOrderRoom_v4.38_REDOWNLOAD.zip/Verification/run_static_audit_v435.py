#!/usr/bin/env python3
"""Reproducible offline regression gate. Does not run Unity or claim build success."""
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = [
    [sys.executable, "Verification/governance_gate.py"],
    [sys.executable, "Verification/governance_v423.py"],
    [sys.executable, "Verification/architecture_gate_v426.py"],
    [sys.executable, "Verification/camera_contract_gate_v427.py"],
    [sys.executable, "Verification/integration_gate_v428.py"],
    [sys.executable, "Verification/lifecycle_gate_v429.py"],
    [sys.executable, "Verification/screen_layout_gate_v430.py"],
    [sys.executable, "Verification/responsive_layout_gate_v431.py"],
    [sys.executable, "Verification/gesture_integrity_gate_v432.py"],
    [sys.executable, "Verification/restore_integrity_gate_v433.py"],
    [sys.executable, "Verification/history_pacing_gate_v434.py"],
    [sys.executable, "Verification/release_source_gate_v435.py"],
    [sys.executable, "-m", "unittest", "discover", "-s", "Verification", "-p", "test_*.py", "-v"],
]


def main() -> int:
    runs = []
    for args in COMMANDS:
        process = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=180)
        result = {
            "command": args[1:],
            "exit_code": process.returncode,
            "stdout_tail": process.stdout[-2400:],
            "stderr_tail": process.stderr[-2400:],
        }
        runs.append(result)
        print(("PASS" if process.returncode == 0 else "FAIL") + " " + " ".join(args[1:]))
    status = "STATIC_PASS_ONLY" if all(entry["exit_code"] == 0 for entry in runs) else "FAIL"
    report = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "runs": runs,
        "unity_compilation_verified": False,
        "editmode_tests_executed": False,
        "playmode_tests_executed": False,
        "android_device_verified": False,
    }
    out = ROOT / "Verification" / "AUDIT_EVIDENCE_v4.35.json"
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return 0 if status == "STATIC_PASS_ONLY" else 1


if __name__ == "__main__":
    sys.exit(main())
