#!/usr/bin/env python3
"""Fail-closed source provenance and Unity dependency governance.

This is an offline *static* gate, not a Unity compiler or release certificate.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "Assets"
PROJECT = ASSETS / "_Project"
GUID = re.compile(r"(?m)^guid: ([0-9a-f]{32})\s*$")
VERSION = re.compile(r"(?m)^m_EditorVersion:\s*(\S+)\s*$")

EXPECTED_DEPENDENCIES = {
    "TheOrderRoom.Domain": set(),
    "TheOrderRoom.AppCore": {"TheOrderRoom.Domain"},
    "TheOrderRoom.Infrastructure": {"TheOrderRoom.Domain", "TheOrderRoom.AppCore"},
    "TheOrderRoom.Runtime": {"TheOrderRoom.Domain", "UnityEngine.UI", "Unity.InputSystem"},
    "TheOrderRoom.Editor": {"TheOrderRoom.Domain", "TheOrderRoom.Runtime", "UnityEngine.UI", "Unity.InputSystem"},
    "TheOrderRoom.Tests.EditMode": {
        "TheOrderRoom.Domain", "TheOrderRoom.Runtime", "TheOrderRoom.AppCore",
        "TheOrderRoom.Infrastructure", "UnityEngine.TestRunner", "UnityEditor.TestRunner",
        "UnityEngine.UI", "Unity.InputSystem",
    },
}
PURE = {"TheOrderRoom.Domain", "TheOrderRoom.AppCore", "TheOrderRoom.Infrastructure"}


def check_manifest(manifest: dict) -> list[str]:
    problems = []
    dependencies = manifest.get("dependencies")
    if not isinstance(dependencies, dict) or not dependencies:
        return ["Package manifest has no dependency map"]
    for name, version in dependencies.items():
        if not isinstance(name, str) or not isinstance(version, str) or not version:
            problems.append("Invalid package dependency entry")
            continue
        if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?", version):
            problems.append(f"Unpinned or external package version: {name} = {version}")
    return problems


def check_assembly_graph(definitions: dict[str, dict]) -> list[str]:
    problems = []
    if set(definitions) != set(EXPECTED_DEPENDENCIES):
        problems.append("Assembly inventory drift: " + repr(sorted(set(definitions) ^ set(EXPECTED_DEPENDENCIES))))
    for name, expected in EXPECTED_DEPENDENCIES.items():
        definition = definitions.get(name)
        if definition is None:
            continue
        references = definition.get("references")
        if not isinstance(references, list) or set(references) != expected or len(references) != len(expected):
            problems.append("Assembly dependency drift: " + name)
        if definition.get("allowUnsafeCode", False):
            problems.append("Unsafe C# enabled: " + name)
        if name in PURE and not definition.get("noEngineReferences", False):
            problems.append("Pure assembly has engine references: " + name)
        if name in PURE and any(str(dep).startswith("Unity") for dep in references or []):
            problems.append("Unity dependency inside pure assembly: " + name)
    for name in definitions:
        if name not in EXPECTED_DEPENDENCIES:
            problems.append("Unreviewed assembly: " + name)
    for name in definitions:
        visited = set()
        def visit(node: str, active: set[str]) -> None:
            if node in active:
                problems.append("Assembly dependency cycle: " + name + " -> " + node)
                return
            if node in visited or node not in definitions:
                return
            visited.add(node)
            for ref in definitions[node].get("references", []):
                if isinstance(ref, str) and ref in definitions:
                    visit(ref, active | {node})
        visit(name, set())
    return sorted(set(problems))


def check_runner(script: str) -> list[str]:
    problems = []
    if "-accept-apiupdate" in script:
        problems.append("Verification runner may rewrite source using API updater")
    for required in (
        "Get-SourceFingerprint", "Assert-SourceUnchanged", "source_integrity",
        "Get-FileHash", "-Algorithm SHA256", "BuildAndValidateBatch",
        "-runTests", "-testResults", "THEORDERROOM_MAIN_SCENE_VALIDATED",
    ):
        if required not in script:
            problems.append("Verification runner missing contract: " + required)
    return problems


def check_scene_lifecycle(source: str) -> list[str]:
    required = (
        'The EventSystem must be active and enabled.',
        'No active and enabled Canvas is available for input.',
        'The frame and energy governor must be active and enabled.',
        'The audio feedback provider must be active and enabled.',
        'The pointer source must be active and enabled.',
        'Expected exactly one OrderGame.',
        'Expected one pointer source bound to this game.',
    )
    return ["Scene lifecycle validation missing: " + value for value in required if value not in source]


def audit(root: Path) -> dict:
    problems: list[str] = []
    assets = root / "Assets"
    project = assets / "_Project"
    metas = sorted(assets.rglob("*.meta"))
    seen_guids: dict[str, str] = {}
    for p in metas:
        relative = p.relative_to(root).as_posix()
        match = GUID.search(p.read_text(encoding="utf-8-sig", errors="replace"))
        if not match:
            problems.append("Missing or invalid Unity GUID: " + relative)
            continue
        guid = match.group(1)
        if guid in seen_guids:
            problems.append("Duplicate Unity GUID: " + relative + " and " + seen_guids[guid])
        else:
            seen_guids[guid] = relative
        resource = p.with_name(p.name[:-5])
        if not resource.exists():
            problems.append("Orphaned Unity meta file: " + relative)
    missing_meta = []
    for p in assets.rglob("*"):
        if p.name.endswith(".meta"):
            continue
        # Folders and files in Unity's Assets require matching .meta, except the root.
        meta = p.with_name(p.name + ".meta")
        if not meta.exists():
            missing_meta.append(p.relative_to(root).as_posix())
    problems.extend("Missing Unity meta: " + path for path in missing_meta)
    definitions = {}
    asm_paths = {}
    for p in project.rglob("*.asmdef"):
        try:
            data = json.loads(p.read_text(encoding="utf-8-sig"))
            name = data["name"]
            if name in definitions:
                problems.append("Duplicate assembly definition: " + name)
            definitions[name] = data
            asm_paths[name] = p
        except (ValueError, KeyError) as exc:
            problems.append("Invalid assembly definition: " + str(p) + ": " + str(exc))
    problems.extend(check_assembly_graph(definitions))
    source_count = 0
    for p in project.rglob("*.cs"):
        source_count += 1
        owners = [name for name, asm in asm_paths.items() if asm.parent in p.parents]
        if len(owners) != 1:
            # Tests can live under a nested asmdef: choose the deepest owner.
            if not owners:
                problems.append("Source outside assembly: " + p.relative_to(root).as_posix())
                continue
            owners.sort(key=lambda name: len(asm_paths[name].parts), reverse=True)
            if len(owners) > 1 and len(asm_paths[owners[0]].parts) == len(asm_paths[owners[1]].parts):
                problems.append("Ambiguous assembly ownership: " + p.relative_to(root).as_posix())
        owner = max(owners, key=lambda name: len(asm_paths[name].parts))
        if owner in PURE:
            content = p.read_text(encoding="utf-8-sig")
            if re.search(r"\b(?:using\s+Unity(?:Engine|Editor)\b|UnityEngine\.|UnityEditor\.)", content):
                problems.append("Unity API referenced from pure assembly: " + p.relative_to(root).as_posix())
    try:
        version_text = (root / "ProjectSettings" / "ProjectVersion.txt").read_text(encoding="utf-8-sig")
        version_match = VERSION.search(version_text)
        pinned_version = version_match.group(1) if version_match else None
        if not pinned_version:
            problems.append("Missing Unity editor version")
        manifest = json.loads((root / "Packages" / "manifest.json").read_text(encoding="utf-8"))
        problems.extend(check_manifest(manifest))
        runner = (root / "Verification" / "Run-UnityVerification.ps1").read_text(encoding="utf-8-sig")
        problems.extend(check_runner(runner))
        scene_validator = (project / "Editor" / "OrderSceneValidator.cs").read_text(encoding="utf-8-sig")
        problems.extend(check_scene_lifecycle(scene_validator))
    except (OSError, ValueError) as exc:
        pinned_version = None
        problems.append("Cannot validate project toolchain: " + str(exc))
    return {
        "status": "STATIC_PASS_ONLY" if not problems else "FAIL",
        "editor_version": pinned_version,
        "assembly_count": len(definitions),
        "csharp_files": source_count,
        "unity_guid_count": len(seen_guids),
        "missing_meta_count": len(missing_meta),
        "issues": sorted(set(problems)),
        "unity_compilation_verified": False,
        "editmode_tests_executed": False,
        "android_verified": False,
    }


if __name__ == "__main__":
    report = audit(ROOT)
    (ROOT / "Verification" / "RELEASE_SOURCE_REPORT_v4.35.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    sys.exit(0 if not report["issues"] else 1)
