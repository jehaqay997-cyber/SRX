#!/usr/bin/env python3
import tempfile
import unittest
from pathlib import Path
from integration_gate_v428 import CHECKS, RUNTIME, evaluate

class IntegrationGateTests(unittest.TestCase):
    def test_source_passes(self):
        self.assertEqual(evaluate()['issues'], [])

    def test_missing_revision_guard_is_caught(self):
        self.assert_mutation_caught('OrderGame.cs','return CanUseWorld(point) && ReferenceEquals(gestureBoard, board) && board.Revision == gestureRevision;', 'return CanUseWorld(point) && ReferenceEquals(gestureBoard, board) && gestureRevision == gestureRevision;','gesture_revision_guard')

    def test_unbounded_save_buffer_is_caught(self):
        self.assert_mutation_caught('OrderSaveStore.cs',
            'int capacity = checked((int)expectedLength + 1);',
            'int capacity = checked((int)MaxSaveBytes + 1);','dynamic_allocation')

    def test_broken_performance_owner_is_caught(self):
        self.assert_mutation_caught('OrderPerformanceGovernor.cs',
            'if (activeOwner != null && activeOwner != this)',
            'if (false)','duplicate_governor_disabled')

    def assert_mutation_caught(self,filename,old,new,expected):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            for name,_ in CHECKS.values():
                source=RUNTIME/name
                (base/name).write_bytes(source.read_bytes())
            text=(base/filename).read_text(encoding='utf-8')
            self.assertIn(old,text)
            (base/filename).write_text(text.replace(old,new,1),encoding='utf-8')
            self.assertIn(expected,evaluate(base)['issues'])

if __name__=='__main__': unittest.main(verbosity=2)
