#!/usr/bin/env python3
import shutil
import tempfile
import unittest
from pathlib import Path
from lifecycle_gate_v429 import audit, RUNTIME

class LifecycleGateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for name in ("OrderPointerInput.cs", "OrderGame.cs", "OrderScreenLayout.cs"):
            shutil.copy2(RUNTIME/name, self.root/name)

    def tearDown(self):
        self.temporary.cleanup()

    def replace(self, filename, old, new):
        path = self.root/filename
        content = path.read_text(encoding="utf-8")
        self.assertIn(old, content)
        path.write_text(content.replace(old, new, 1), encoding="utf-8")

    def test_intact_contracts_pass(self):
        self.assertEqual([], audit(self.root)["failures"])

    def test_missing_suspend_guard_is_rejected(self):
        self.replace("OrderPointerInput.cs",
                     "CancelGesture();\n            // A finger held while the app loses focus must not become a new gesture\n            // on resume. Resume only after all active contacts have been released.\n            blockUntilTouchesEnd = true;",
                     "CancelGesture();\n            // A finger held while the app loses focus must not become a new gesture\n            // on resume. Resume only after all active contacts have been released.\n            blockUntilTouchesEnd = false;")
        self.assertIn("touch_block_set_before_resume", audit(self.root)["failures"])

    def test_drag_without_item_is_rejected(self):
        self.replace("OrderGame.cs", "if (gestureItem == null) return;", "if (gestureItem != null) return;")
        self.assertIn("empty_world_drag_prevented", audit(self.root)["failures"])

    def test_missing_scaler_restore_is_rejected(self):
        self.replace("OrderScreenLayout.cs",
                     "scaler.referenceResolution = originalReferenceResolution;",
                     "scaler.referenceResolution = new UnityEngine.Vector2(1, 1);")
        self.assertIn("layout_restores_scaler", audit(self.root)["failures"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
