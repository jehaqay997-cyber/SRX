#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "Assets/_Project/Runtime"
EDITOR = ROOT / "Assets/_Project/Editor"

CHECKS = {
    "synchronous projection update": (RUNTIME / "ArtifactInspectionView.cs", "if (isActiveAndEnabled) UpdateCameraViewport();"),
    "fresh projection for visibility": (RUNTIME / "ArtifactInspectionView.cs", "UpdateCameraViewport();\n            Renderer seal"),
    "main camera is linked to game": (EDITOR / "OrderSceneValidator.cs", "OrderGame must reference the active main camera."),
    "camera and layout share identity": (EDITOR / "OrderSceneValidator.cs", "Responsive layout must use the same active camera as OrderGame."),
    "inspection layer isolation": (EDITOR / "OrderSceneValidator.cs", "Main camera must exclude the inspection-only layer."),
    "camera owns listener": (EDITOR / "OrderSceneValidator.cs", "The main camera must own the scene's AudioListener."),
    "camera contract tests": (ROOT / "Assets/_Project/Tests/EditMode/InspectionCameraContractTests.cs", "ZoomUpdatesProjectionSynchronouslyAndRejectsUnknownValues"),
}

def main():
    failed = []
    for label, (path, content) in CHECKS.items():
        if not path.is_file() or content not in path.read_text(encoding="utf-8"):
            failed.append(label)
    for label in failed:
        print("FAIL:", label)
    if failed:
        return 1
    print("PASS: camera source contract (7 checks)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
