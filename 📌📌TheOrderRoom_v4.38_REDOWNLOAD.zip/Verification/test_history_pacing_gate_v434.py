#!/usr/bin/env python3
"""Independent model property tests and structural negative controls."""
import importlib.util
from collections import deque
from pathlib import Path
import random
import unittest

ROOT=Path(__file__).resolve().parents[1]
MODULE=ROOT/'Verification/history_pacing_gate_v434.py'
spec=importlib.util.spec_from_file_location('history_pacing_gate_v434',MODULE)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class RingModel:
    def __init__(self,cap):
        assert cap>0
        self.a=[None]*cap
        self.n=0
        self.first=0
    def push(self,v):
        if self.n<len(self.a):
            self.a[(self.first+self.n)%len(self.a)]=v
            self.n+=1
        else:
            self.a[self.first]=v
            self.first=(self.first+1)%len(self.a)
    def pop(self):
        if self.n==0: raise IndexError
        i=(self.first+self.n-1)%len(self.a)
        v=self.a[i]
        self.a[i]=None
        self.n-=1
        if not self.n: self.first=0
        return v
    def peek(self):
        if not self.n: raise IndexError
        return self.a[(self.first+self.n-1)%len(self.a)]
    def clear(self):
        self.a[:]=[None]*len(self.a)
        self.first=self.n=0

class HistoryTest(unittest.TestCase):
    def test_gate_contract_pass(self):
        self.assertEqual([],mod.run())
    def test_boundary_behavior(self):
        for capacity in (1,2,3,64,65):
            ring=RingModel(capacity)
            for i in range(200):ring.push(i)
            self.assertEqual(min(200,capacity),ring.n)
            self.assertEqual([ring.pop() for _ in range(ring.n)],list(reversed(range(200-capacity,200))))
    def test_randomized_fifo_eviction_and_lifo(self):
        rng=random.Random(431434)
        for capacity in (1,2,5,64):
            ring=RingModel(capacity)
            ref=deque(maxlen=capacity)
            for i in range(10000):
                op=rng.randrange(4)
                if op==0:
                    ring.clear();ref.clear()
                elif op==1 and ref:
                    self.assertEqual(ref.pop(),ring.pop())
                else:
                    ring.push(i);ref.append(i)
                self.assertEqual(len(ref),ring.n)
                if ref:self.assertEqual(ref[-1],ring.peek())
    def test_failed_gate_detects_deleted_owner_guard(self):
        source=mod.GOVERNOR.read_text()
        self.assertIn('if (!ownsSettings || !mobileFrameControl) return;',source)
        self.assertEqual([],mod.run())
        try:
            mod.GOVERNOR.write_text(source.replace('if (!ownsSettings || !mobileFrameControl) return;','if (!ownsSettings) return;',1))
            self.assertTrue(any('desktop_adaptation_disabled' in x for x in mod.run()))
        finally:
            mod.GOVERNOR.write_text(source)
    def test_failed_gate_detects_history_reset(self):
        source=mod.GAME.read_text()
        try:
            mod.GAME.write_text(source.replace('history.Push(before);','history.Clear(); history.Push(before);',1))
            # The semantic problem can manifest under any unconditional reset, not only the original conditional form.
            self.assertTrue(any('no_destructive_history_overflow' in x for x in mod.run()))
        finally:
            mod.GAME.write_text(source)

if __name__=='__main__':unittest.main()
