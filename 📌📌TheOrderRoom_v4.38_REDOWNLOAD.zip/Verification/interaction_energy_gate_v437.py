#!/usr/bin/env python3
"""Static guards for input-selection ownership and bounded energy history.

This does not compile or execute Unity C#.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENERGY = ROOT / 'Assets/_Project/Domain/EnergyPuzzle.cs'
GAME = ROOT / 'Assets/_Project/Runtime/OrderGame.cs'
HISTORY = ROOT / 'Assets/_Project/Domain/BoundedHistory.cs'


def inspect(root=ROOT):
    energy = (root / ENERGY.relative_to(ROOT)).read_text(encoding='utf-8')
    game = (root / GAME.relative_to(ROOT)).read_text(encoding='utf-8')
    history = (root / HISTORY.relative_to(ROOT)).read_text(encoding='utf-8')
    problems = []
    if not re.search(r'BoundedHistory<int\[\]>\s+history\s*=\s*new\s+BoundedHistory<int\[\]>\(128\)', energy):
        problems.append('Energy history must use a 128-entry bounded ring.')
    if not re.search(r'history\.Push\(\(int\[\]\)ports\.Clone\(\)\)', energy):
        problems.append('Rotate must retain an isolated pre-rotation snapshot.')
    if not re.search(r'Array\.Copy\(history\.Pop\(\),\s*ports,\s*ports\.Length\)', energy):
        problems.append('Undo must restore the newest snapshot.')
    if 'history.RemoveAt(0)' in energy or 'history.Add(' in energy:
        problems.append('Legacy shifting energy history is forbidden.')
    if not re.search(r'public bool Reset\(\)[\s\S]*?history\.Clear\(\)', energy):
        problems.append('Energy Reset must clear history.')
    match = re.search(r'private bool TrySelectItem\(string id\)\s*\{([\s\S]*?)\n\s*\}', game)
    if not match:
        problems.append('Selection contract is missing.')
    else:
        body = match.group(1)
        clear = body.find('selected = null;')
        validation = body.find('if (!isActiveAndEnabled')
        assignment = body.find('selected = id;')
        if min(clear, validation, assignment) < 0 or not (clear < validation < assignment):
            problems.append('New selection must invalidate stale selection before validation.')
    if not all(key in history for key in ('public void Push(', 'public T Peek(', 'public T Pop(', 'public void Clear(')):
        problems.append('Shared bounded history contract is missing.')
    return problems


def main():
    issues = inspect()
    report = {'status': 'STATIC_PASS_ONLY' if not issues else 'FAIL',
              'checks': 7, 'issues': issues, 'unity_compiled': False,
              'nunit_executed': False}
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == '__main__':
    sys.exit(main())
