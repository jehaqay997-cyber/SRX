#!/usr/bin/env python3
"""Source freeze simulation and mutation tests; never claims Unity execution."""
from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("final_integrity", HERE / "final_integrity_gate_v436.py")
final_integrity = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(final_integrity)


class FinalIntegrityGateTests(unittest.TestCase):
    def setUp(self):
        self.root = HERE.parent
        self.runner = (HERE / "Run-UnityVerification.ps1").read_text(encoding="utf-8")

    def test_current_source_passes_governance(self):
        result = final_integrity.audit(self.root)
        self.assertEqual([], result["issues"])
        self.assertFalse(result["unity_compilation_verified"])

    def test_source_partition_contains_binary_content(self):
        source = final_integrity.fingerprint(self.root)
        self.assertIn("Assets/_Project/Art/PNG/sun.png", source)
        self.assertIn("Assets/_Project/Art/PNG/puzzle_assets.json", source)
        self.assertIn("ProjectSettings/ProjectSettings.asset", source)

    def test_runner_missing_generated_stage_fails(self):
        broken = self.runner.replace("Assert-SourceUnchanged $generatedBaseline", "Write-Host 'Nothing checked'")
        self.assertTrue(final_integrity.verify_runner(broken))

    def test_runner_missing_player_settings_fails(self):
        broken = self.runner.replace("ProjectSettings\\ProjectSettings.asset", "ProjectSettings\\not-real.asset")
        self.assertTrue(final_integrity.verify_runner(broken))

    def test_runner_missing_content_directory_fails(self):
        broken = self.runner.replace("Art\\Materials", "Art\\UnmanagedOutput")
        self.assertTrue(final_integrity.verify_runner(broken))

    def test_source_change_and_deletion_are_detectable(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = root / "Assets" / "_Project" / "Art" / "PNG"
            data.mkdir(parents=True)
            picture = data / "sun.png"
            picture.write_bytes(b"one")
            baseline = final_integrity.fingerprint(root)
            picture.write_bytes(b"two")
            self.assertNotEqual(baseline, final_integrity.fingerprint(root))
            picture.unlink()
            self.assertNotEqual(baseline, final_integrity.fingerprint(root))

    def test_generated_bootstrap_outputs_are_excluded_from_authored_source(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "Assets" / "_Project"
            project.mkdir(parents=True)
            original = final_integrity.fingerprint(root)
            scene = project / "Scenes" / "Main.unity"
            scene.parent.mkdir()
            scene.write_bytes(b"new-scene")
            material = project / "Art" / "Materials" / "Table.mat"
            material.parent.mkdir(parents=True)
            material.write_bytes(b"new-material")
            lock = root / "Packages" / "packages-lock.json"
            lock.parent.mkdir()
            lock.write_text(json.dumps({"dependencies": {}}))
            self.assertEqual(original, final_integrity.fingerprint(root))
            generated = final_integrity.fingerprint(root, generated=True)
            self.assertEqual(3, len(generated))

    def test_generated_mutation_after_bootstrap_is_detectable(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            file = root / "Assets" / "_Project" / "Scenes" / "Main.unity"
            file.parent.mkdir(parents=True)
            file.write_bytes(b"scene-before")
            before = final_integrity.fingerprint(root, generated=True)
            file.write_bytes(b"scene-after")
            self.assertNotEqual(before, final_integrity.fingerprint(root, generated=True))


if __name__ == "__main__":
    unittest.main(verbosity=2)
