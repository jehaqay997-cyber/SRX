#!/usr/bin/env python3
"""Build-independent integrity and integration checks; NOT a C# compiler or runtime benchmark."""
import json
import pathlib
import re
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[1]
project = root / "Assets" / "_Project"
failures = []
required_sources = {
    "Domain/FrameBudgetPolicy.cs": ("class FrameBudgetPolicy", "Choose(", "InitialTarget("),
    "Runtime/OrderPerformanceGovernor.cs": ("class OrderPerformanceGovernor", "OnDisable()", "Application.targetFrameRate"),
    "Runtime/OrderAudioFeedback.cs": ("class OrderAudioFeedback", "PlayOneShot", "OnDestroy()"),
    "Runtime/OrderScreenLayout.cs": ("CaptureCamera()", "RestoreCamera()", "void Configure("),
    "Editor/OrderProjectBootstrap.cs": ("AddComponent<OrderPerformanceGovernor>()", "AddComponent<OrderAudioFeedback>()", "game.ConfigureAudio(audioFeedback)"),
    "Editor/OrderSceneValidator.cs": ("Components<OrderPerformanceGovernor>", "Components<OrderAudioFeedback>", '"audioFeedback"'),
    "Tests/EditMode/FrameBudgetPolicyTests.cs": ("LowBatteryOnlyThrottles", "SlowWindowsRequireHysteresis"),
}
for name, tokens in required_sources.items():
    path = project / name
    if not path.is_file():
        failures.append("missing source: " + name)
        continue
    source = path.read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            failures.append("missing integration token " + token + " in " + name)
    meta = pathlib.Path(str(path) + ".meta")
    if not meta.is_file():
        failures.append("missing Unity meta: " + name)
scene = project / "Scenes" / "Main.unity"
# Scene generation on first import is a supported artifact; no fabricated scene is supplied.
scene_present = scene.exists()
bootstrap = (project / "Editor" / "OrderFirstImportSetup.cs").read_text(encoding="utf-8")
if not scene_present and "InitializeOnFirstImport" not in bootstrap:
    failures.append("No scene or automatic first-import bootstrap")
# Domain assembly cannot use any Unity types.
for source in (project / "Domain").glob("*.cs"):
    if re.search(r"^\s*using\s+Unity(?:Engine|Editor)", source.read_text(), re.M):
        failures.append("Domain Unity dependency: " + source.name)
checks = ["verify_v4_20.py", "audit_candidate.py", "independent_adventure_oracle.py"]
underlying = {}
for name in checks:
    result = subprocess.run([sys.executable, str(root / "Verification" / name)],
                            capture_output=True, text=True)
    underlying[name] = {"returncode": result.returncode, "last_stdout": result.stdout[-1500:]}
    if result.returncode:
        failures.append("earlier checker failed: " + name + " " + result.stderr[-400:])
report = {
    "version": "v4.21", "status": "STATIC_PASS" if not failures else "STATIC_FAIL",
    "required_integrations": len(required_sources),
    "original_scene_in_archive": scene_present,
    "auto_scene_bootstrap_available": "InitializeOnFirstImport" in bootstrap,
    "csharp_count": len(list(project.rglob("*.cs"))),
    "asmdef_count": len(list(project.rglob("*.asmdef"))),
    "underlying": underlying,
    "failures": failures,
    "unity_compiled": False, "nunit_executed": False, "android_tested": False,
    "battery_measured": False, "energy_leak_proven_absent": False,
}
(root / "Verification" / "VERIFICATION_EXECUTED_v4.21.json").write_text(
    json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({key: report[key] for key in ("version", "status", "csharp_count", "asmdef_count", "failures")}, indent=2))
sys.exit(bool(failures))
