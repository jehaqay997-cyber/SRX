#!/usr/bin/env python3
"""Source-contract checks for reversible screen layout; not a Unity runtime test."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'Assets/_Project/Runtime/OrderScreenLayout.cs'
TEST = ROOT / 'Assets/_Project/Tests/EditMode/ScreenLayoutRestorationRegressionTests.cs'


def verify(source: str, regression: str):
    checks = {
        'rect_snapshot_type': 'private struct RectSnapshot' in source,
        'text_snapshot_type': 'private struct TextSnapshot' in source,
        'rect_capture_before_layout': bool(re.search(r'private void Place\(.*?Remember\(rect\);\s*rect.anchorMin', source, re.S)),
        'label_capture_before_change': bool(re.search(r'if \(label != null\)\s*\{\s*Remember\(label\);', source)),
        'label_rect_capture': 'Remember(label.rectTransform);' in source,
        'nested_rule_rect_capture': bool(re.search(r'if \(rules != null\)\s*\{\s*Remember\(rules\);', source)),
        'restore_rectangles': 'foreach (var entry in originalRects)' in source,
        'restore_text_settings': 'foreach (var entry in originalTexts)' in source,
        'restore_on_disable': bool(re.search(r'private void OnDisable\(\)\s*\{\s*RestoreCamera\(\);', source)),
        'regression_test': 'DisablingLayoutRestoresModifiedButtonAndTextRectangles' in regression,
    }
    return {'status': 'STATIC_PASS_ONLY' if all(checks.values()) else 'FAIL',
            'checks': checks, 'unity_compilation_verified': False,
            'unity_tests_executed': False}


def main():
    report = verify(SOURCE.read_text(encoding='utf-8'), TEST.read_text(encoding='utf-8'))
    (ROOT / 'Verification/SCREEN_LAYOUT_v4.30.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'STATIC_PASS_ONLY' else 1


if __name__ == '__main__':
    sys.exit(main())
