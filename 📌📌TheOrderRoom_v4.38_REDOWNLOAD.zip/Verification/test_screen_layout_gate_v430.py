import unittest
from pathlib import Path
from screen_layout_gate_v430 import verify

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'Assets/_Project/Runtime/OrderScreenLayout.cs').read_text(encoding='utf-8')
TEST = (ROOT / 'Assets/_Project/Tests/EditMode/ScreenLayoutRestorationRegressionTests.cs').read_text(encoding='utf-8')


class ScreenLayoutGateTests(unittest.TestCase):
    def test_real_source_passes(self):
        self.assertEqual('STATIC_PASS_ONLY', verify(SOURCE, TEST)['status'])

    def test_missing_rect_capture_is_detected(self):
        changed = SOURCE.replace('Remember(rect);\n            rect.anchorMin', 'rect.anchorMin', 1)
        self.assertEqual('FAIL', verify(changed, TEST)['status'])

    def test_missing_label_restoration_is_detected(self):
        changed = SOURCE.replace('foreach (var entry in originalTexts)', 'foreach (var entry in originalRects)', 1)
        self.assertEqual('FAIL', verify(changed, TEST)['status'])

    def test_missing_nested_rules_capture_is_detected(self):
        changed = SOURCE.replace('Remember(rules);', '', 1)
        self.assertEqual('FAIL', verify(changed, TEST)['status'])


if __name__ == '__main__':
    unittest.main()
