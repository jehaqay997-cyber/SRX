#!/usr/bin/env python3
"""Static integration constraints for v4.34; not a C# compiler or Unity test."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DOMAIN = ROOT / 'Assets/_Project/Domain/BoundedHistory.cs'
GAME = ROOT / 'Assets/_Project/Runtime/OrderGame.cs'
GOVERNOR = ROOT / 'Assets/_Project/Runtime/OrderPerformanceGovernor.cs'
TESTS = ROOT / 'Assets/_Project/Tests/EditMode/BoundedHistoryTests.cs'

def run():
    issues = []
    for path in (DOMAIN, GAME, GOVERNOR, TESTS):
        if not path.is_file() or not (path.with_suffix(path.suffix + '.meta')).is_file():
            issues.append('Missing source or .meta: ' + path.name)
    if issues:
        return issues
    domain, game, governor, tests = (p.read_text(encoding='utf-8') for p in (DOMAIN,GAME,GOVERNOR,TESTS))
    expectations = {
        'fixed_capacity_storage': 'private readonly T[] entries;' in domain,
        'bounded_push': 'if (count < entries.Length)' in domain and 'entries[oldest] = value;' in domain,
        'bounded_pop_resets_reference': 'entries[index] = default(T);' in domain,
        'history_bounded': 'new BoundedHistory<Dictionary<string, string>>(64)' in game and 'history.Push(before);' in game,
        'redo_bounded': 'redoHistory = new BoundedHistory<Dictionary<string, string>>(64)' in game and 'redoHistory.Push(previous);' in game,
        'no_destructive_history_overflow': 'if (history.Count >= 64) history.Clear();' not in game and 'history.Clear(); history.Push(before);' not in game,
        'desktop_vsync': 'QualitySettings.vSyncCount = 1;' in governor,
        'mobile_target': 'Application.targetFrameRate = target;' in governor,
        'desktop_target': 'Application.targetFrameRate = -1;' in governor,
        'desktop_adaptation_disabled': 'if (!ownsSettings || !mobileFrameControl) return;' in governor,
        'restores_global_settings': 'Application.targetFrameRate = previousTarget;' in governor and 'QualitySettings.vSyncCount = previousVsync;' in governor,
        'nunit_boundary': 'BoundaryAtSixtyFourKeepsSixtyFourMostRecentStates' in tests,
        'nunit_wrap': 'WrapAroundPreservesChronologicalOrder' in tests,
    }
    issues.extend('FAILED_CONTRACT:' + name for name, met in expectations.items() if not met)
    return issues

if __name__ == '__main__':
    issues=run()
    print('PASS: history and pacing static contract' if not issues else '\n'.join(issues))
    sys.exit(bool(issues))
