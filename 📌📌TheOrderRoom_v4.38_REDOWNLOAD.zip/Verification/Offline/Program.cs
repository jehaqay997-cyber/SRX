using System;
using System.Linq;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
class Program
{
    static int assertions;
    static void Check(bool condition, string message) { assertions++; if (!condition) throw new Exception(message); }
    static void Main()
    {
        for (int version = 1; version <= 2; version++)
        for (int level = 0; level < 12; level++)
        {
            var definition = CampaignPuzzles.Get(level, version);
            var board = OrderLevels.Create(level, version);
            for (int i = 0; i < definition.Items.Count; i++)
            {
                long revision = board.Revision;
                Check(PuzzleHint.TrySuggest(definition, board, out string item, out string destination), "Missing hint");
                Check(board.Revision == revision, "Hint mutated state");
                Check(board.Prepare(item, destination, revision, out Guid ticket, out _), "Prepare failed");
                Check(board.Commit(ticket, out _), "Commit failed");
                Check(!board.Commit(ticket, out _), "Ticket was reusable");
                foreach (var bin in board.Compartments)
                {
                    Check(board.CountIn(bin.Id) <= bin.Capacity, "Capacity overflow");
                    Check(board.WeightIn(bin.Id) <= bin.MaxWeight, "Weight overflow");
                }
            }
            Check(board.Solved, "Campaign unsolved: " + version + "/" + level);
            Check(board.Rules.OfType<LinkedPairRule>().Any() == (version == 2 && (level == 5 || level == 8 || level == 11)), "Version isolation failed");
        }
        var items = new[] { new Item("key", "X", 1), new Item("dependent", "X", 1) };
        var bins = new[] { new Compartment("A", "X", 2, 2), new Compartment("B", "X", 2, 2) };
        var gate = new OrderBoard(items, bins, null, new PuzzleRule[] { new DestinationKeyRule("dependent", "key", "A") });
        Check(gate.Move("key", "B", out _), "Wrong drawer setup");
        long before = gate.Revision;
        Check(!gate.Move("dependent", "A", out _), "Wrong drawer accepted");
        Check(gate.Revision == before, "Rejected move changed revision");
        Check(gate.Move("key", "A", out _), "Key failed");
        Check(gate.Move("dependent", "B", out _), "Unlock failed");
        Check(!gate.Move("key", OrderBoard.Tray, out _), "Live key removed");
        var linked = new OrderBoard(items, bins, null, new PuzzleRule[] { new LinkedPairRule("key", "dependent") });
        Check(linked.Move("key", "A", out _), "Pair setup");
        Check(!linked.Move("dependent", "B", out _), "Split accepted");
        Check(linked.Move("dependent", "A", out _), "Pair rejected");
        Check(linked.Solved, "Pair not solved");
        Console.WriteLine("PASS: " + assertions + " assertions; 24 campaign/version combinations; exact-key and linked-pair regressions.");
        Console.WriteLine("Unity compilation, NUnit suite, rendering and device execution are not covered by this harness.");
    }
}
