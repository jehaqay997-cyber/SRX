# TheOrderRoom v4.36 — Final Source Governance Review

## Release disposition

**SOURCE GOVERNANCE: STATIC PASS. RUNTIME RELEASE: NOT VERIFIED.**

This deliverable was derived from the full v4.35 source archive. No gameplay or assembly contracts were intentionally changed. Unity, a C# compiler, PowerShell, Android SDK, and a physical Android device were unavailable in the execution environment. Consequently no Unity compilation, NUnit execution, PlayMode test, Android build, or real power/thermal measurement is claimed.

## Confirmed failure path corrected

The v4.35 PowerShell verifier snapshots selected source files before its Unity bootstrap. Bootstrap legitimately creates `Assets/_Project/Scenes/Main.unity`, `Assets/_Project/Art/Materials/*.mat` and their Unity `.meta` files. Unity Package Manager may also create `Packages/packages-lock.json`. The old fingerprint included generated material metadata and an optionally present lockfile; consequently clean first-import verification could fail with a "source changed" report despite expected generated output. At the same time it did **not** hash authored PNG and JSON game content, leaving content changes invisible to source-integrity checks.

v4.36 enforces a two-phase provenance contract:

1. **Before Unity bootstrap:** fingerprint every authored file below `Assets/_Project` except the two explicitly generated subtrees, plus `Packages/manifest.json`, `ProjectSettings/ProjectVersion.txt`, and `ProjectSettings/ProjectSettings.asset`.
2. **After bootstrap:** fingerprint the generated scene, materials, their metadata, and the newly resolved package-lock file.
3. **After NUnit:** compare both snapshots independently. Changes, deletions, and additions are detected within each frozen partition.
4. **On error:** run the authored source comparison in `finally`; compare the generated snapshot if bootstrap completed. Report state remains `FAIL` for any failed stage.

This is deliberately a file-integrity gate, **not** a cryptographic attestation of the Unity runtime, an audit of third-party transitive packages, or a proof that the package manager can resolve packages offline.

## Engineering invariants preserved

- The six pre-existing assembly definitions, their dependencies, and assembly ownership boundaries remain unchanged.
- Domain, AppCore and Infrastructure remain isolated from Unity APIs according to existing static checks.
- `OrderBoard` continues to own game state and revision/Prepare/Commit rules. The intentional ticket invalidation on failed Prepare remains unchanged.
- Undo/Redo remain bounded histories, and save generations remain append-only with validated readback.
- Existing scene, pointer, camera, audio, screen and energy ownership rules are preserved.
- `Unity 2022.3.62f3` remains the pinned actual ProjectVersion; no silent migration was made.

## New and modified files

Modified: `Verification/Run-UnityVerification.ps1`

Added: `Verification/final_integrity_gate_v436.py`, `Verification/test_final_integrity_gate_v436.py`, `Verification/FINAL_SOURCE_REPORT_v4.36.json`, `Verification/FILE_DIFF_v4.36.json`, `Verification/SHA256_MANIFEST_v4.36.json`, and this report.

## Checks executed here

- Python unittest discovery across all nine available Python test modules: **45 tests passed**.
- v4.36 static provenance/assembly audit: **STATIC_PASS_ONLY** (6 assemblies, 100 C# files, 137 GUIDs, 0 issues).
- Existing governance gate: **PASS** with zero errors.
- ZIP CRC and all recorded SHA-256 file hashes: verified after packaging.
- No `pwsh`/`powershell`, `dotnet`, Unity Editor, or Android toolchain available. No execution of Unity or PowerShell code is claimed.

## Necessary release blockers

1. Run `Verification/Run-UnityVerification.ps1` on Windows with the exact Unity Editor version shown in `ProjectSettings/ProjectVersion.txt`. It launches scene bootstrap and the EditMode test runner, rejects missing NUnit XML or failing tests, and checks source/generated file integrity.
2. Execute actual PlayMode interaction, touch, camera, UI and save interruption tests. The available script currently executes EditMode tests only.
3. Compile and deploy a test Android build; profile GC allocations, frame pacing, memory, battery and device temperature.
4. Review and freeze `Packages/packages-lock.json` after a successful first import, then verify dependency resolution under the actual deployment environment.

## Primary documentation

- Unity 2022.3 Editor CLI / Batchmode: https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity Test Framework CLI: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Microsoft `FileStream.Flush(bool)`: https://learn.microsoft.com/en-us/dotnet/api/system.io.filestream.flush
- Microsoft `File.Move`: https://learn.microsoft.com/en-us/dotnet/api/system.io.file.move

**No zero-defect or production-release certification is made without the blocked runtime tests.**
