# Engineering Recovery and Root-Cause Audit — v4.19

Date: 2026-11-16
Base: v4.18 full Unity source candidate. All pre-existing project files retained except intentional modifications listed here and regenerated hash manifest.

## Confirmed from source inspection

P1-001: AdventureSession quarantined a failed/unknown write indefinitely with no authoritative reload operation. Implemented opt-in IAdventureSnapshotReader and TryReload. Successful reload requires a non-null snapshot from authoritative storage. Failures, exceptions, stale revisions, and reentry during Commit keep the session quarantined. This does not invent a persistent adventure adapter: no such adapter was wired in this candidate.

P1-002: OrderBoard.Restore copied arbitrary IDictionary input directly, allowing malformed null keys or duplicate iteration to throw before controlled rejection. Replaced with defensive enumeration into a separate candidate and validation before atomic state replacement. No mutation on known malformed input.

P1-003: Added NUnit tests for conflict recovery, unknown-write reconciliation, unreadable storage, stale store snapshots, reload reentrancy, missing reader, and malformed IDictionary. They are source-level tests and have NOT been executed under NUnit in this environment.

P1-004: Added Unity .meta files for every new test script, preserving pre-existing GUIDs. Regenerated file SHA-256 inventory.

## Further known risks and prerequisites

P0-001: The Unity Editor and .NET SDK are absent in the execution environment, so C# compilation, NUnit execution, Unity PlayMode, rendering, Android builds, and device profiling remain unverified. Do not release.

P0-002: The stored project targets Unity 2022.3.62f3, whereas newer discussions cite Unity 6.3.28f1. Target-version migration is not proven; no blind package upgrade has been applied.

P1-005: AdventureSession presently depends on IAdventureStore (no production persistence implementation found). A real atomic store adapter and recovery tests are required before enabling adventure progression in the shipped runtime.

P1-006: The save SHA-256 checksum detects accidental file corruption, not malicious tampering. Save authentication cannot be claimed without secure key provision and threat modeling. A signed local save with a client-bundled secret is not tamper-proof.

P1-007: Proof of no softlock covers only the current 20-state adventure model. It does not establish completeness for 3D scenes, click visibility, asynchronous animations, or future chapter content.

P2-001: Existing source architecture still couples multiple game services to Unity-specific Runtime classes; Clean Architecture is a migration objective, not a verified property of the package.

## Test matrix

STATIC: Executed offline; see Verification/REMEDIATION_EXECUTION_v4.19.json.
PYTHON ORACLE: Executed independent model only; not equivalent to executing C#.
NUNIT: Not executed.
UNITY COMPILATION: Not executed.
ANDROID: Not executed.

## Next release gate

1. Restore and compile on the exact installed Unity Editor version with package lock and all tests.
2. Implement and test real adventure snapshot adapter with atomic compare-and-swap and authoritative reload.
3. Execute storage fault injection, fuzzed JSON parsing, UI pointer capture, and mobile profiling.
4. Attach Unity compilation/TestRunner logs, build hash, and device evidence before upgrading verification flags.
