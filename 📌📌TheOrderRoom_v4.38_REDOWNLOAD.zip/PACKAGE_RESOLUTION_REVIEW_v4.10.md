# Unity startup and package resolution review v4.10

Target editor: Unity 2022.3.62f3.

## Manifest correction

The earlier package manifest declared `com.unity.modules.textrendering` at version `1.0.0`. The Unity 2022.3 built-in package catalog does not list this package identifier. Unity's API documentation identifies `TextMesh`, `Font`, and related text APIs as part of `UnityEngine.TextRenderingModule`, which is an Editor-provided engine assembly rather than a Package Manager dependency.

The invalid dependency was removed from `Packages/manifest.json`. The current manifest retains ten exact package versions. Unity will resolve the supported package set and generate `Packages/packages-lock.json` when Package Manager successfully opens the project. Do not manually restore the removed entry.

## Two different startup conditions

1. **Package resolution error:** addressed in this candidate by removing the invalid manifest identifier. On the user's machine, Unity must still resolve the manifest. If it fails again, preserve the first Package Manager error and `%LOCALAPPDATA%\Unity\Editor\upm.log`.
2. **Project already open:** a stale Unity Editor process or project lock can prevent a second launch. Close the existing Editor normally first. If it is unresponsive, use Task Manager to end only the Unity Editor process for this project, then launch once from Hub. Do not end Unity Hub or delete project source files.

`Failed to load Mono` is a third, separate failure: it happens before C# compilation and can indicate an Editor/runtime installation problem. This manifest change cannot repair a damaged Editor installation. Capture `%LOCALAPPDATA%\Unity\Editor\Editor.log` if that message remains.

## Verification boundary

The updated JSON parses and the portable scanner confirms the invalid dependency is absent. Actual Unity Package Manager resolution and Editor startup have not been executed in this environment. Therefore package resolution, Unity compilation, and Play Mode remain unverified until the project is opened successfully on the target machine.

## Official Unity references

- Unity 2022.3 built-in package catalog: https://docs.unity3d.com/2022.3/Documentation/Manual/pack-build.html
- Unity 2022.3 TextRenderingModule API: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/UnityEngine.TextRenderingModule.html
- Unity 2022.3 Editor logs: https://docs.unity3d.com/2022.3/Documentation/Manual/LogFiles.html
