# TheOrderRoom v4.16 — Consolidated Review Candidate

**Review package, not a verified playable release.**

This package preserves the complete available v4.15 source archive and supplements it with the November 16 product blueprint, reproducible static audit tooling, and a provenance report. No existing game source, `.meta` GUID or package manifest was deliberately changed. The historical project targets **Unity 2022.3.62f3**. Prior discussion also named **Unity 6.3.28f1**; this package is **not** silently migrated or claimed compatible with Unity 6.3.

## What is actually present

- OrderBoard and puzzle/domain systems; Undo/Redo, hints, linked puzzle rules and campaign content.
- Unity runtime for puzzles, inspection/focus, energy circuit and UI/input.
- Save journal/recovery code and numerous NUnit EditMode source tests.
- An independent pure-C# AdventureChapter and AppCore AdventureSession added in v4.15.
- Editor bootstrap and scene validation scripts; Main scene is generated on initial Unity import, not pre-included.
- Prior portable test-result XML and validation summaries: historical evidence, **not current Unity run evidence**.

## What is not established

- Unity compilation, fresh EditMode/PlayMode results, physical Android test or release quality.
- Integrated adventure navigation in Unity, durable adventure store adapter, knowledge graph, hidden-object authoring pipeline, comprehensive softlock solver, production accessibility/telemetry system.
- Compatibility with Unity 6.3.28f1 or any untested editor version.

## How to inspect

1. Run `python3 Verification/audit_candidate.py` from this project root.
2. Read `Verification/CONSOLIDATION_REPORT.json` and `Design/PRODUCT_BLUEPRINT_2026-11-16.md`.
3. Extract this zip to a local **non-synced** folder; inspect `Assets`, `Packages` and `ProjectSettings`.
4. Open in Unity 2022.3.62f3 only if that is your installed verified editor. Capture compilation diagnostics; run EditMode Test Runner and inspect generated Main scene.
5. Before any Unity 6.3 migration, snapshot source and `.meta` GUIDs, verify package support, and execute a separate migration branch.

Do not overwrite existing project files or saves with this candidate before backup and testing.
