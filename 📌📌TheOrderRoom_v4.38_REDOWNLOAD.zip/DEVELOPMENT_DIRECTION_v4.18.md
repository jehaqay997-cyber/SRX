# TheOrderRoom v4.18 — Development and Verification Gate

## Status
The v4.17 codebase is preserved as the authoritative starting point. This package adds six explicit NUnit regression tests for the adventure boundary and an independent Python finite-state oracle. Neither Unity nor .NET was available in this execution environment; no Unity compilation or execution is claimed.

## P0: Build verification
1. Open the project in the editor version in `ProjectSettings/ProjectVersion.txt` (2022.3.62f3). Do not change major editor versions without a documented migration and verified package compatibility.
2. Resolve packages and run Editor compilation; archive `Editor.log` and compiler diagnostics.
3. Run all EditMode tests using Unity Test Runner or `-batchmode -runTests -testPlatform EditMode`; archive actual results XML.
4. Run portable C# projects with a compatible installed .NET SDK. Capture command, SDK version, exit code and full test logs.
5. Run `python Verification/independent_adventure_oracle.py` and compare finite-state counts against `AdventureSolvabilityVerifier.Verify()` measured in executed C#.

## P1: Semantic integrity
- Current chapter oracle counts are scoped to a finite (location, facts) representation. Inventory is derived from facts and there is no general WorldGraph, dialogue knowledge graph or multi-ending proof yet.
- Prove the real runtime can reach each terminal state and disallow unintended state mutations for rejected commands.
- Verify save/load round trips, future schema rejection, corrupt-save isolation and crash recovery before integrating new adventure mechanics.

## P2: Playable vertical slice
- Connect existing adventure state to fixed-camera three-dimensional scene navigation, tap affordances, inventory, journal and progressive hints.
- Target an initial three-location five-puzzle slice; measure completion and user experience on a real Android device.
- Preserve `PuzzleBoard` ownership of order-puzzle state; do not merge adventure world state into `PuzzleBoard`.

## Blocking criteria
M0 remains OPEN while compilation, NUnit suite and actual device checks remain unverified. Do not label this package release-ready.
