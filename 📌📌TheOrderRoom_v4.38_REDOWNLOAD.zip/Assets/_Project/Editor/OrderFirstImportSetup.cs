#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>Creates a scene only in a fresh project, after script compilation.</summary>
    [InitializeOnLoad]
    public static class OrderFirstImportSetup
    {
        private const string ScenePath = OrderSceneValidator.MainScene;
        private const string OptOutMarker = "Assets/_Project/Scenes/.skip-auto-bootstrap";
        static OrderFirstImportSetup()
        {
            EditorApplication.delayCall += TryInitialize;
        }
        private static void TryInitialize()
        {
            if (File.Exists(ScenePath) || File.Exists(OptOutMarker) || Application.isBatchMode ||
                EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += TryInitialize;
                return;
            }
            // Scene creation is additive; modified user scenes remain untouched.
            try { OrderProjectBootstrap.InitializeOnFirstImport(); }
            catch (System.Exception e)
            {
                Debug.LogError("TheOrderRoom scene bootstrap failed; use TheOrderRoom/Create Integrated Scene manually. " + e);
            }
        }
    }
}
#endif
