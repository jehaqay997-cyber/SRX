using System;
using System.Collections.Generic;
using System.Linq;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    public sealed class OrderGame : MonoBehaviour
    {
        private OrderBoard board;
        private int level;
        private EnergyPuzzle energyPuzzle;
        private EnergyPuzzlePanel energyPanel;
        private readonly OpticalFocus opticalFocus = new OpticalFocus();
        private int contentVersion = OrderLevels.CurrentContentVersion;
        private int unlocked;
        // Last authoritative generation observed by this gameplay session.
        private long sessionGeneration = -1;
        private bool saveSessionBlocked;
        private readonly ArtifactLedger artifactLedger = new ArtifactLedger();
        private readonly ContentAccessPolicy contentAccess = new ContentAccessPolicy(new FreeContentEntitlements());
        private string selected;
        private OrderBoard gestureBoard;
        private OrderClick gestureItem;
        private long gestureRevision;
        private Vector2 gestureStart;
        private Vector3 gestureOriginalPosition;
        private Vector3 gestureOffset;
        private bool gesturePending;
        private bool gestureDragging;
        private bool gestureExceededTapThreshold;
        [SerializeField] private Text status;
        [SerializeField] private Text heading;
        [SerializeField] private Text collectionText;
        [SerializeField] private Text revealText;
        private float revealUntil;
        private readonly ArtifactInspectionState inspection = new ArtifactInspectionState();
        [SerializeField] private ArtifactInspectionView inspectionView;
        private int lastInspectionCommandFrame = -1;
        private bool rewardCommitInProgress;
        private bool transitionInProgress;
        [SerializeField] private Text inspectionText;
        private readonly HashSet<string> awardedThisSession = new HashSet<string>(StringComparer.Ordinal);
        [SerializeField] private Transform pieces;
        [SerializeField] private Camera sceneCamera;
        [SerializeField] private OrderAudioFeedback audioFeedback;
        public void ConfigureAudio(OrderAudioFeedback feedback) => audioFeedback = feedback;
        private OrderDestination[] sceneTargets;
        [SerializeField] private Text rulesText;
        [SerializeField] private GameObject rulesPanel;
        private readonly BoundedHistory<Dictionary<string, string>> history = new BoundedHistory<Dictionary<string, string>>(64);
        private readonly BoundedHistory<Dictionary<string, string>> redoHistory = new BoundedHistory<Dictionary<string, string>>(64);
        private static readonly Color Sun = new Color(.93f, .69f, .28f);
        private static readonly Color Moon = new Color(.52f, .73f, .95f);
        private static readonly Color Star = new Color(.74f, .57f, .93f);
        private readonly Dictionary<string, Material> materials = new Dictionary<string, Material>();
        private readonly Dictionary<string, GameObject> pieceById = new Dictionary<string, GameObject>(StringComparer.Ordinal);

        public void Configure(Text title, Text message, Transform world, Camera camera)
        { heading = title; status = message; pieces = world; sceneCamera = camera; }

        public void ConfigureRules(Text text, GameObject panel)
        {
            rulesText = text; rulesPanel = panel;
            if (rulesPanel != null) rulesPanel.SetActive(false);
        }
        public void ShowRules()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || rulesPanel == null || rulesText == null) return;
            bool show = !rulesPanel.activeSelf;
            if (show)
            {
                if (contentVersion == 0)
                    rulesText.text = "LEGACY CAMPAIGN\nMatch symbols. At gates, lower numbers fill A and higher numbers fill B.";
                else
                {
                    var definition = CampaignPuzzles.Get(level, contentVersion);
                    rulesText.text = definition.Title + "\n" + definition.Brief +
                        "\n\nPlace every item. Match symbols; obey drawer count and weight limits.\n" +
                        string.Join("\n", definition.Rules.Select(x => x.Description));
                }
            }
            rulesPanel.SetActive(show);
        }
        public void Hint()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || board == null) return;
            if (rulesPanel != null) rulesPanel.SetActive(false);
            if (contentVersion == 0) { SetStatus("Match symbols. Gate drawers use ascending A/B item numbers."); return; }
            if (PuzzleHint.TrySuggest(CampaignPuzzles.Get(level, contentVersion), board, out string id, out string target))
                SetStatus("Try moving " + id + " to " + target + ".");
            else SetStatus(board.Solved ? "Puzzle complete. Inspect the artifact." : "Review the rules before the next move.");
        }
        public void ConfigureCollection(Text collection, Text reveal)
        {
            collectionText = collection;
            revealText = reveal;
            UpdateCollectionView();
            if (revealText != null) revealText.gameObject.SetActive(false);
        }
        public void ConfigureInspection(ArtifactInspectionView view, Text instructions)
        {
            inspectionView = view;
            inspectionText = instructions;
            if (inspectionView != null) inspectionView.Hide();
            UpdateInspectionText();
        }
        private void UpdateInspectionText()
        {
            if (inspectionText == null) return;
            inspectionText.text = !inspection.IsActive ? "" : inspection.IsRevealed
                ? "SEALS REVEALED - CLAIM TO RESTORE POWER"
                : "SCAN THREE SEALS - " + inspection.SealsFound + "/3 | FOCUS " + opticalFocus.Magnification + "% | TARGET " + OpticalFocus.Required(inspection.Orientation) + "%";
        }
        public void InspectArtifact()
        {
            if (!isActiveAndEnabled || saveSessionBlocked) return;
            if (board == null || !board.Solved) { SetStatus("Solve the puzzle to inspect its artifact"); return; }
            var id = ArtifactPresentation.ForLevel(level);
            if (artifactLedger.Contains(id)) { SetStatus("Artifact already in collection"); return; }
            if (!inspection.IsActive)
            {
                if (rulesPanel != null) rulesPanel.SetActive(false);
                inspection.Begin(id);
                energyPuzzle = new EnergyPuzzle(level);
                opticalFocus.Reset();
                try { inspectionView.Show(level); }
                catch (Exception error)
                {
                    inspection.Cancel(); saveSessionBlocked = true; enabled = false;
                    Debug.LogError("Artifact view construction failed: " + error);
                    SetStatus("Artifact view unavailable; restart required");
                    return;
                }
            }
            UpdateInspectionText();
        }
        public void TurnArtifactLeft() => TurnArtifact(-1);
        public void TurnArtifactRight() => TurnArtifact(1);
        private void TurnArtifact(int direction)
        {
            if (!isActiveAndEnabled || saveSessionBlocked) return;
            if (lastInspectionCommandFrame == Time.frameCount) return;
            if (!inspection.IsActive || inspection.IsRevealed || inspectionView == null) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (!inspection.Turn(direction)) return;
            inspectionView.RotateQuarter(direction);
            UpdateInspectionText();
        }
        public void FocusIn() => AdjustFocus(1);
        public void FocusOut() => AdjustFocus(-1);
        private void AdjustFocus(int direction)
        {
            if (!isActiveAndEnabled || saveSessionBlocked || !inspection.IsActive || inspectionView == null ||
                (energyPanel != null && energyPanel.IsOpen)) return;
            if (opticalFocus.Adjust(direction)) inspectionView.SetMagnification(opticalFocus.Magnification);
            UpdateInspectionText();
        }
        public void ScanArtifact()
        {
            if (!isActiveAndEnabled || saveSessionBlocked) return;
            if (rulesPanel != null && rulesPanel.activeSelf) { SetStatus("Close RULES before scanning the artifact."); return; }
            if (lastInspectionCommandFrame == Time.frameCount) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (!inspection.IsActive || inspectionView == null || !inspectionView.IsSealVisible(inspection.Orientation))
            { SetStatus("Seal is hidden or blocked; rotate the artifact"); return; }
            if (!opticalFocus.IsFocused(inspection.Orientation))
            { SetStatus("Adjust FOCUS to " + OpticalFocus.Required(inspection.Orientation) + "% before scanning"); return; }
            if (!inspection.Scan()) { SetStatus("No new seal visible from this angle"); return; }
            inspectionView.HighlightSeal(inspection.Orientation);
            UpdateInspectionText();
        }
        public void ClaimArtifact()
        {
            if (!isActiveAndEnabled || saveSessionBlocked) return;
            if (lastInspectionCommandFrame == Time.frameCount) return;
            lastInspectionCommandFrame = Time.frameCount;
            if (saveSessionBlocked || rewardCommitInProgress || transitionInProgress || board == null || !board.Solved || !inspection.IsRevealed)
            { SetStatus("Inspect and reveal the artifact first"); return; }
            if (energyPuzzle == null || !energyPuzzle.IsSolved)
            {
                if (energyPuzzle == null) energyPuzzle = new EnergyPuzzle(level);
                if (energyPanel == null)
                {
                    var panel = new GameObject("Energy Puzzle", typeof(RectTransform));
                    panel.transform.SetParent(inspectionText.transform.parent, false);
                    energyPanel = panel.AddComponent<EnergyPuzzlePanel>();
                }
                energyPanel.transform.SetAsLastSibling(); energyPanel.Show(energyPuzzle);
                SetStatus("Restore power before claiming the artifact"); return;
            }
            string id = ArtifactPresentation.ForLevel(level);
            if (!string.Equals(inspection.ArtifactId, id, StringComparison.Ordinal))
            { SetStatus("Artifact inspection does not match this level"); return; }
            // The claim state must be valid before durable commit; no fallible state transition follows save.
            if (!inspection.IsActive || inspection.SealsFound != 3 || artifactLedger.Contains(id))
            { SetStatus("Reward already claimed or inspection incomplete"); return; }
            // Stage the entire reward transaction before changing in-memory state.
            // If storage fails, inspection remains claimable and no progress is granted.
            int nextUnlocked = CampaignRules.UnlockAfterCompletion(level, unlocked);
            SaveDocument staged = CreateSaveDocument(nextUnlocked);
            if (!staged.discoveredArtifacts.Contains(id)) staged.discoveredArtifacts.Add(id);
            rewardCommitInProgress = true;
            try
            {
                if (!SaveCurrentSession(staged, out string error))
                { SetStatus("Could not save reward; retry CLAIM"); Debug.LogWarning("Reward save failed: " + error); return; }
            }
            finally { rewardCommitInProgress = false; }
            // No fallible I/O occurs after the durable save succeeds.
            if (!inspection.TryClaim(id))
            {
                // A successful journal write is authoritative; force a safe reload rather than
                // continuing with an inconsistent in-memory reward state.
                Debug.LogError("Reward saved but local inspection state diverged; reload scene to recover");
                enabled = false;
                return;
            }
            if (energyPanel != null) energyPanel.Close();
            artifactLedger.Discover(id);
            unlocked = nextUnlocked;
            if (inspectionView != null) inspectionView.Hide();
            RevealArtifact(id);
            if (audioFeedback != null) audioFeedback.PlayDiscovery();
            UpdateCollectionView(); UpdateInspectionText();
            SetStatus(level + 1 == OrderLevels.Count ? "Archive restored. Collection complete." : "Artifact collected - next room unlocked");
        }
        private void Update()
        {
            if (revealText != null && revealText.gameObject.activeSelf && Time.unscaledTime >= revealUntil)
                revealText.gameObject.SetActive(false);
        }
        private void UpdateCollectionView()
        {
            if (collectionText == null) return;
            var found = artifactLedger.Snapshot();
            collectionText.text = "COLLECTION  " + found.Length + "/" + OrderLevels.Count +
                (found.Length == 0 ? "\nSolve a room to recover its artifact" :
                 "\n" + string.Join("  |  ", found.Select(ArtifactPresentation.DisplayName)));
        }
        private void RevealArtifact(string id)
        {
            if (revealText == null) return;
            revealText.text = "DISCOVERED: " + ArtifactPresentation.DisplayName(id) +
                (contentVersion == 0 ? "" : "\n" + CampaignPuzzles.Get(level, contentVersion).Revelation);
            revealText.gameObject.SetActive(true);
            revealUntil = Time.unscaledTime + 10f;
        }
        private void Start()
        {
            if (heading == null || status == null || pieces == null || sceneCamera == null ||
                collectionText == null || revealText == null || inspectionView == null || inspectionText == null ||
                rulesText == null || rulesPanel == null)
            {
                saveSessionBlocked = true;
                enabled = false;
                Debug.LogError("TheOrderRoom: scene references are incomplete; regenerate and validate Main scene.");
                return;
            }
            sceneTargets = FindObjectsByType<OrderDestination>(FindObjectsInactive.Include, FindObjectsSortMode.None)
                .Where(target => target.Game == this).ToArray();
            if (OrderSaveStore.TryLoad(out SaveDocument saved, out string reason))
            {
                // Validate every component in isolation before publishing any restored state.
                var stagedLedger = new ArtifactLedger();
                var positions = new Dictionary<string, string>(StringComparer.Ordinal);
                bool valid = stagedLedger.TryRestore(saved.discoveredArtifacts ?? new List<string>());
                if (valid)
                    foreach (var entry in saved.locations)
                        if (entry == null || string.IsNullOrEmpty(entry.itemId) ||
                            !positions.TryAddCompat(entry.itemId, entry.destination)) { valid = false; break; }
                OrderBoard stagedBoard = null;
                if (valid)
                {
                    try
                    {
                        stagedBoard = OrderLevels.Create(saved.level, saved.contentVersion);
                        valid = stagedBoard.Restore(positions);
                    }
                    catch (Exception e)
                    {
                        valid = false;
                        Debug.LogWarning("TheOrderRoom: restore validation failed: " + e.GetType().Name);
                    }
                }
                if (valid)
                {
                    // Commit is memory-only after validation: no partially restored rewards.
                    // Publish the already validated board directly. LoadLevel would create a
                    // second board and refresh the scene before the restored board is installed.
                    artifactLedger.TryRestore(stagedLedger.Snapshot());
                    sessionGeneration = saved.generation;
                    unlocked = saved.unlockedLevel;
                    CloseInspection();
                    contentVersion = saved.contentVersion;
                    level = saved.level;
                    board = stagedBoard;
                    selected = null;
                    history.Clear(); redoHistory.Clear();
                    Refresh();
                    UpdateLevelHeader();
                    UpdateCollectionView();
                    SetStatus("Progress restored");
                }
                else
                {
                    // The storage layer accepted an envelope, but runtime staging rejected
                    // its contents. Never replace this session with a fresh writable board:
                    // a retry could otherwise overwrite recoverable authoritative progress.
                    saveSessionBlocked = true;
                    selected = null;
                    board = null;
                    Debug.LogError("TheOrderRoom: verified save failed runtime staging; existing data was preserved.");
                    SetStatus("Saved session requires recovery; restart after inspecting the save.");
                }
            }
            else
            {
                unlocked = 0;
                LoadLevel(0);
                if (reason != "No saved game")
                {
                    saveSessionBlocked = true;
                    SetStatus("Save recovery required: " + reason);
                }
            }
        }

        public void Select(string id)
        {
            TrySelectItem(id);
        }

        private bool TrySelectItem(string id)
        {
            // A rejected new selection must not leave an earlier selection armed.
            selected = null;
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || transitionInProgress || rewardCommitInProgress ||
                board == null || !contentAccess.CanOpen(ContentCatalog.BasePack) ||
                !board.TryGetItem(id, out Item item)) return false;
            selected = id;
            SetStatus("Selected " + id + " | W: " + item.Weight + " | choose a target");
            return true;
        }
        // Build the next board in isolation. Publish only after the journal accepts it.
        private bool TryCommitBoard(OrderBoard candidate, out string error)
        {
            var staged = CreateSaveDocument(unlocked, candidate);
            return SaveCurrentSession(staged, out error);
        }
        public void Place(string destination)
        {
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || transitionInProgress || rewardCommitInProgress ||
                board == null || string.IsNullOrEmpty(selected) || !contentAccess.CanOpen(ContentCatalog.BasePack))
            { SetStatus("Finish the current interaction or select an item"); return; }
            var before = board.Snapshot().ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            var candidate = OrderLevels.Create(level, contentVersion);
            if (!candidate.Restore(before)) { SetStatus("Move staging rejected"); return; }
            if (!candidate.Move(selected, destination, out string moveError))
            { if (audioFeedback != null) audioFeedback.PlayWarning(); SetStatus("Move rejected: " + moveError); return; }
            if (!TryCommitBoard(candidate, out string saveError))
            { SetStatus("Move not committed: storage unavailable"); Debug.LogWarning(saveError); return; }
            board = candidate;
            if (audioFeedback != null) audioFeedback.PlaySuccess();
            history.Push(before);
            redoHistory.Clear();
            selected = null;
            Refresh();
            if (board.Solved)
            {
                SetStatus("Solved! INSPECT, rotate and SCAN three seals, then CLAIM.");
                InspectArtifact();
            }
            else SetStatus("Item placed");
        }
        public void ResetBoard()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || transitionInProgress || rewardCommitInProgress || board == null ||
                !contentAccess.CanOpen(ContentCatalog.BasePack)) return;
            var candidate = OrderLevels.Create(level, contentVersion);
            if (!TryCommitBoard(candidate, out string error))
            { SetStatus("Reset not committed: storage unavailable"); Debug.LogWarning(error); return; }
            board = candidate; CloseInspection(); history.Clear(); redoHistory.Clear(); selected = null;
            Refresh(); SetStatus("Board reset");
        }
        public void Undo()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || transitionInProgress || rewardCommitInProgress || board == null ||
                !contentAccess.CanOpen(ContentCatalog.BasePack) || history.Count == 0)
            { SetStatus("Nothing to undo"); return; }
            var candidate = OrderLevels.Create(level, contentVersion);
            if (!candidate.Restore(history.Peek())) { SetStatus("Undo rejected"); return; }
            if (!TryCommitBoard(candidate, out string error))
            { SetStatus("Undo not committed: storage unavailable"); Debug.LogWarning(error); return; }
            var previous = board.Snapshot().ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            board = candidate; history.Pop(); redoHistory.Push(previous); CloseInspection(); selected = null;
            Refresh(); SetStatus("Move undone");
        }
        public void Redo()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || inspection.IsActive || transitionInProgress || rewardCommitInProgress || board == null ||
                !contentAccess.CanOpen(ContentCatalog.BasePack) || redoHistory.Count == 0)
            { SetStatus("Nothing to redo"); return; }
            var candidate = OrderLevels.Create(level, contentVersion);
            if (!candidate.Restore(redoHistory.Peek())) { SetStatus("Redo rejected"); return; }
            if (!TryCommitBoard(candidate, out string error))
            { SetStatus("Redo not committed: storage unavailable"); Debug.LogWarning(error); return; }
            var previous = board.Snapshot().ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            board = candidate;
            redoHistory.Pop();
            history.Push(previous);
            CloseInspection(); selected = null;
            Refresh(); SetStatus("Move redone");
        }
        public void NextLevel()
        {
            if (!isActiveAndEnabled || saveSessionBlocked || transitionInProgress || rewardCommitInProgress || board == null || !contentAccess.CanOpen(ContentCatalog.BasePack) || !board.Solved || !artifactLedger.Contains(ArtifactPresentation.ForLevel(level)) || level + 1 >= OrderLevels.Count || level + 1 > unlocked)
            { SetStatus("Finish this level first"); return; }
            int target = level + 1;
            var staged = new SaveDocument { schemaVersion = contentVersion == 0 ? 1 : 2, contentVersion = contentVersion, level = target, unlockedLevel = unlocked,
                discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
            var nextBoard = OrderLevels.Create(target, contentVersion);
            foreach (var pair in nextBoard.Snapshot())
                staged.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
            transitionInProgress = true;
            try
            {
                if (!SaveCurrentSession(staged, out string error))
                { SetStatus("Could not save next room; retry"); Debug.LogWarning("Level transition save failed: " + error); return; }
                CloseInspection();
                level = target;
                board = nextBoard;
                selected = null;
                history.Clear(); redoHistory.Clear();
                Refresh();
                UpdateLevelHeader();
            }
            finally { transitionInProgress = false; }
        }
        // Public level navigation is a durable transition, not an in-memory reset.
        public void LoadLevel(int index)
        {
            if (!isActiveAndEnabled || saveSessionBlocked || transitionInProgress || rewardCommitInProgress || inspection.IsActive ||
                index < 0 || index >= OrderLevels.Count || index > unlocked ||
                !contentAccess.CanOpen(ContentCatalog.BasePack)) return;
            if (board != null && index == level) return;
            var candidate = OrderLevels.Create(index, contentVersion);
            if (board != null)
            {
                var staged = new SaveDocument { schemaVersion = contentVersion == 0 ? 1 : 2, contentVersion = contentVersion, level = index, unlockedLevel = unlocked,
                    discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
                foreach (var pair in candidate.Snapshot())
                    staged.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
                transitionInProgress = true;
                try
                {
                    if (!SaveCurrentSession(staged, out string error))
                    { SetStatus("Level not changed: save failed"); Debug.LogWarning(error); return; }
                }
                finally { transitionInProgress = false; }
            }
            CloseInspection(); level = index; board = candidate; selected = null; history.Clear(); redoHistory.Clear(); Refresh();
            UpdateLevelHeader();
        }
        private void UpdateLevelHeader()
        {
            if (heading != null) heading.text = (contentVersion == 0 ? CampaignNarrative.Title(level) : CampaignPuzzles.Get(level, contentVersion).Title) + "  /  " + (level + 1);
            SetStatus(contentVersion != 0 ? CampaignPuzzles.Get(level, contentVersion).Brief : level % CampaignRules.LevelsPerChapter == 2
                ? "GATE RULE: For each symbol, place lower-numbered items in A and higher-numbered items in B."
                : CampaignNarrative.Hook(level));
        }
        private void CloseInspection()
        {
            if (rulesPanel != null) rulesPanel.SetActive(false);
            inspection.Cancel();
            opticalFocus.Reset(); energyPuzzle = null;
            if (energyPanel != null) energyPanel.Close();
            if (inspectionView != null) inspectionView.Hide();
            UpdateInspectionText();
        }
        private SaveDocument CreateSaveDocument(int targetUnlocked, OrderBoard sourceBoard = null)
        {
            var data = new SaveDocument { schemaVersion = contentVersion == 0 ? 1 : 2, contentVersion = contentVersion, level = level, unlockedLevel = targetUnlocked,
                discoveredArtifacts = new List<string>(artifactLedger.Snapshot()) };
            foreach (var pair in (sourceBoard ?? board).Snapshot())
                data.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
            return data;
        }
        private bool SaveCurrentSession(SaveDocument document, out string reason)
        {
            if (saveSessionBlocked)
            {
                reason = "Save session is blocked; restart required";
                return false;
            }

            bool saved = OrderSaveStore.TrySaveIfCurrent(document, sessionGeneration,
                out long committedGeneration, out reason);
            if (saved)
            {
                sessionGeneration = committedGeneration;
                return true;
            }

            if (reason != null &&
                (reason.StartsWith("Existing save cannot be verified", StringComparison.Ordinal) ||
                 reason.StartsWith("Cannot inspect existing save", StringComparison.Ordinal) ||
                 reason.StartsWith("Stale save session", StringComparison.Ordinal) ||
                 reason.StartsWith("Commit status unknown", StringComparison.Ordinal) ||
                 reason.StartsWith("Save history changed", StringComparison.Ordinal) ||
                 reason.StartsWith("Committed journal verification failed", StringComparison.Ordinal)))
            {
                saveSessionBlocked = true;
                ReconcileAuthoritativeSave();
            }
            return false;
        }

        private void ReconcileAuthoritativeSave()
        {
            // Fail closed: read the authoritative journal without issuing another write.
            // All future writes remain blocked until a fresh gameplay session is started.
            try
            {
                if (!OrderSaveStore.TryLoad(out SaveDocument saved, out string loadReason))
                {
                    Debug.LogError("TheOrderRoom: authoritative save unavailable: " + loadReason);
                    SetStatus("Storage recovery required; restart the game");
                    return;
                }

                var stagedLedger = new ArtifactLedger();
                if (!stagedLedger.TryRestore(saved.discoveredArtifacts ?? new List<string>()) ||
                    saved.locations == null)
                {
                    Debug.LogError("TheOrderRoom: authoritative reward data rejected");
                    SetStatus("Storage recovery required; restart the game");
                    return;
                }

                var positions = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (SaveEntry entry in saved.locations)
                {
                    if (entry == null || string.IsNullOrEmpty(entry.itemId) ||
                        !positions.TryAddCompat(entry.itemId, entry.destination))
                    {
                        Debug.LogError("TheOrderRoom: authoritative board data rejected");
                        SetStatus("Storage recovery required; restart the game");
                        return;
                    }
                }

                OrderBoard stagedBoard = OrderLevels.Create(saved.level, saved.contentVersion);
                if (!stagedBoard.Restore(positions))
                {
                    Debug.LogError("TheOrderRoom: authoritative board restore rejected");
                    SetStatus("Storage recovery required; restart the game");
                    return;
                }

                // Publish only a fully validated snapshot. Never retry an uncertain commit.
                if (!artifactLedger.TryRestore(stagedLedger.Snapshot()))
                {
                    Debug.LogError("TheOrderRoom: authoritative ledger restore rejected");
                    SetStatus("Storage recovery required; restart the game");
                    return;
                }
                sessionGeneration = saved.generation;
                unlocked = saved.unlockedLevel;
                contentVersion = saved.contentVersion;
                level = saved.level;
                board = stagedBoard;
                selected = null;
                history.Clear();
                redoHistory.Clear();
                CloseInspection();
                Refresh();
                UpdateLevelHeader();
                UpdateCollectionView();
                SetStatus("Progress recovered; restart to resume saving");
            }
            catch (Exception error)
            {
                Debug.LogError("TheOrderRoom: recovery failed: " + error.GetType().Name);
                SetStatus("Storage recovery required; restart the game");
            }
        }

        private void Persist()
        {
            if (board == null) return;
            if (!SaveCurrentSession(CreateSaveDocument(unlocked), out string error))
                Debug.LogWarning("TheOrderRoom save: " + error);
        }
        private void SetStatus(string message)
        {
            if (status != null) status.text = saveSessionBlocked
                ? "Session blocked; restart or recover storage. " + message : message;
        }
        private void Refresh()
        {
            try { RefreshVisuals(); }
            catch (Exception error)
            {
                saveSessionBlocked = true;
                enabled = false;
                Debug.LogError("TheOrderRoom: committed board retained; visual synchronization failed: " + error);
                SetStatus("Scene synchronization failed; restart required");
            }
        }
        private void RefreshVisuals()
        {
            if (board == null) return;
            if (sceneTargets != null)
            {
                var validDestinations = new HashSet<string>(board.Compartments.Select(x => x.Id), StringComparer.Ordinal);
                validDestinations.Add(OrderBoard.Tray);
                foreach (var target in sceneTargets)
                    if (target != null)
                    {
                        bool active = validDestinations.Contains(target.Destination);
                        target.gameObject.SetActive(active);
                        if (active && target.Label != null && target.Destination != OrderBoard.Tray)
                        {
                            var bin = board.Compartments.First(x => x.Id == target.Destination);
                            var quota = board.Rules.OfType<WeightQuotaRule>().FirstOrDefault(x => x.BinId == bin.Id);
                            target.Label.text = bin.Id + "\n" + board.CountIn(bin.Id) + "/" + bin.Capacity +
                                " | W:" + board.WeightIn(bin.Id) + (quota == null ? " <= " + bin.MaxWeight : "/" + quota.RequiredWeight);
                        }
                    }
            }
            if (pieces == null) throw new InvalidOperationException("Puzzle piece root was lost.");
            var currentIds = new HashSet<string>(board.Items.Select(x => x.Id), StringComparer.Ordinal);
            foreach (var stale in pieceById.Keys.Where(x => !currentIds.Contains(x)).ToArray())
            {
                if (pieceById[stale] != null) Destroy(pieceById[stale]);
                pieceById.Remove(stale);
            }
            int trayIndex = 0;
            var slots = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var item in board.Items)
            {
                string dest = board.Location(item.Id);
                slots.TryGetValue(dest, out int slot);
                slots[dest] = slot + 1;
                Vector3 pos = dest == OrderBoard.Tray
                    ? new Vector3(-2.7f + (trayIndex % 6) * 1.08f, .5f, -2.5f + (trayIndex / 6) * .8f)
                    : new Vector3(TargetX(dest) + ((slot % 3) - 1) * .65f, .5f, TargetZ(dest) + (slot / 3) * .6f);
                if (!pieceById.TryGetValue(item.Id, out var go) || go == null)
                {
                    go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    go.name = item.Id; go.transform.SetParent(pieces, false);
                    go.transform.localScale = new Vector3(.65f, .65f, .65f);
                    go.GetComponent<Renderer>().sharedMaterial = MaterialFor(item.Tag);
                    var click = go.AddComponent<OrderClick>(); click.Game = this; click.ItemId = item.Id;
                    var labelObject = new GameObject("Item Identity", typeof(TextMesh));
                    labelObject.transform.SetParent(go.transform, false);
                    labelObject.transform.localPosition = new Vector3(0f, .52f, 0f);
                    labelObject.transform.localRotation = Quaternion.Euler(55f, 0f, 0f);
                    var label = labelObject.GetComponent<TextMesh>();
                    label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                    label.GetComponent<MeshRenderer>().sharedMaterial = label.font.material;
                    label.text = item.Id + "\nW:" + item.Weight;
                    label.fontSize = 28;
                    label.characterSize = .075f;
                    label.anchor = TextAnchor.MiddleCenter;
                    label.color = Color.white;
                    pieceById[item.Id] = go;
                }
                go.transform.localPosition = pos;
                if (dest == OrderBoard.Tray) trayIndex++;
            }
        }
        private static float TargetX(string destination)
        {
            if (destination.StartsWith("SUN", StringComparison.Ordinal)) return -3.4f;
            if (destination.StartsWith("MOON", StringComparison.Ordinal)) return 0f;
            return 3.4f;
        }
        private static float TargetZ(string destination)
        {
            return destination.EndsWith("_A", StringComparison.Ordinal) ? .5f :
                   destination.EndsWith("_B", StringComparison.Ordinal) ? 2.0f : 1.1f;
        }
        private Material MaterialFor(string tag)
        {
            if (materials.TryGetValue(tag, out var cached)) return cached;
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard") ?? Shader.Find("Sprites/Default");
            if (shader == null) throw new InvalidOperationException("No supported shader found.");
            var material = new Material(shader) { color = tag == "SUN" ? Sun : tag == "MOON" ? Moon : Star };
            materials[tag] = material; return material;
        }
        private void OnDestroy()
        {
            foreach (var pair in materials) if (pair.Value != null) Destroy(pair.Value);
            materials.Clear(); pieceById.Clear();
        }
        // Screen-space UI raycast avoids pointer-ID mismatches between Input System and EventSystem.
        // UI consumes the tap before any world Physics.Raycast is attempted.
        private static readonly List<RaycastResult> UiRaycastHits = new List<RaycastResult>(16);
        private static bool IsScreenPointOverUi(Vector2 screenPoint)
        {
            var eventSystem = EventSystem.current;
            if (eventSystem == null || !eventSystem.isActiveAndEnabled) return true;
            var data = new PointerEventData(eventSystem) { position = screenPoint };
            UiRaycastHits.Clear();
            try
            {
                eventSystem.RaycastAll(data, UiRaycastHits);
                return UiRaycastHits.Count > 0;
            }
            finally { UiRaycastHits.Clear(); }
        }
        private bool CanUseWorld(Vector2 point)
        {
            return !float.IsNaN(point.x) && !float.IsNaN(point.y) &&
                !float.IsInfinity(point.x) && !float.IsInfinity(point.y) &&
                Screen.safeArea.Contains(point) && isActiveAndEnabled && !saveSessionBlocked &&
                !inspection.IsActive && !transitionInProgress && !rewardCommitInProgress &&
                board != null && sceneCamera != null && sceneCamera.pixelRect.Contains(point) && (rulesPanel == null || !rulesPanel.activeSelf) &&
                contentAccess.CanOpen(ContentCatalog.BasePack);
        }

        private bool TryWorldHit(Vector2 point, out RaycastHit hit)
        {
            int mask = sceneCamera.cullingMask & ~ArtifactInspectionView.InspectionMask;
            return Physics.Raycast(sceneCamera.ScreenPointToRay(point), out hit, 100f,
                mask, QueryTriggerInteraction.Ignore);
        }

        public void HandleWorldTap(Vector2 screenPoint, int pointerId = -1)
        {
            if (!CanUseWorld(screenPoint) || IsScreenPointOverUi(screenPoint) ||
                !TryWorldHit(screenPoint, out var hit)) return;
            var item = hit.collider.GetComponentInParent<OrderClick>();
            if (item != null)
            {
                if (item.Game == this) Select(item.ItemId);
                return;
            }
            var target = hit.collider.GetComponentInParent<OrderDestination>();
            if (target != null && target.Game == this) Place(target.Destination);
        }

        public void BeginWorldGesture(Vector2 point)
        {
            CancelWorldGesture();
            if (!CanUseWorld(point) || IsScreenPointOverUi(point)) return;
            gesturePending = true;
            gestureExceededTapThreshold = false;
            gestureBoard = board;
            gestureRevision = board.Revision;
            gestureStart = point;

            if (!TryWorldHit(point, out var hit)) return;
            var item = hit.collider.GetComponentInParent<OrderClick>();
            if (item == null || item.Game != this) return;

            gestureOriginalPosition = item.transform.position;
            if (!TryProjectDragPoint(point, out var projected)) return;
            gestureOffset = gestureOriginalPosition - projected;
            gestureItem = item;
        }

        internal static bool IsTapWithinThreshold(Vector2 start, Vector2 end, float dpi)
        {
            if (float.IsNaN(start.x) || float.IsNaN(start.y) ||
                float.IsNaN(end.x) || float.IsNaN(end.y) ||
                float.IsInfinity(start.x) || float.IsInfinity(start.y) ||
                float.IsInfinity(end.x) || float.IsInfinity(end.y)) return false;
            float threshold = Mathf.Clamp(dpi * 0.06f, 10f, 32f);
            return (end - start).sqrMagnitude < threshold * threshold;
        }

        public void UpdateWorldGesture(Vector2 point)
        {
            if (!gesturePending) return;
            if (!IsCurrentGesture(point)) { CancelWorldGesture(); return; }

            if (!IsTapWithinThreshold(gestureStart, point, Screen.dpi))
                gestureExceededTapThreshold = true;
            if (!gestureDragging && !gestureExceededTapThreshold)
                return;
            // Only an acquired item can transition a world gesture into dragging.
            // Otherwise a finger moving over an empty surface must remain a tap.
            if (gestureItem == null) return;
            gestureDragging = true;
            if (TryProjectDragPoint(point, out var projected))
                gestureItem.transform.position = projected + gestureOffset + Vector3.up * 0.35f;
        }

        public void EndWorldGesture(Vector2 point)
        {
            UpdateWorldGesture(point);
            if (!gesturePending) return;

            bool dragged = gestureDragging;
            bool tap = !dragged && !gestureExceededTapThreshold &&
                IsTapWithinThreshold(gestureStart, point, Screen.dpi);
            // A tap belongs to the initial contact, not the release position.
            // Movement beyond the tap threshold without acquiring an item is a canceled gesture.
            Vector2 tapPosition = gestureStart;
            // A release over UI cannot also activate an underlying world control.
            bool overUi = IsScreenPointOverUi(point);
            string itemId = gestureItem == null ? null : gestureItem.ItemId;
            var destination = dragged && itemId != null && !overUi ? ResolveDropTarget(point) : null;
            CancelWorldGesture();

            if (overUi) return;
            if (!dragged) { if (tap) HandleWorldTap(tapPosition); return; }
            if (destination == null) return;
            // Never move a previously selected item when acquiring the dragged item fails.
            if (!TrySelectItem(itemId)) return;
            Place(destination.Destination);
        }

        public void CancelWorldGesture()
        {
            if (gestureDragging && gestureItem != null && ReferenceEquals(gestureBoard, board) &&
                board.Revision == gestureRevision)
                gestureItem.transform.position = gestureOriginalPosition;
            gesturePending = false;
            gestureDragging = false;
            gestureExceededTapThreshold = false;
            gestureItem = null;
            gestureBoard = null;
        }

        private bool IsCurrentGesture(Vector2 point)
        {
            return CanUseWorld(point) && ReferenceEquals(gestureBoard, board) && board.Revision == gestureRevision;
        }

        private bool TryProjectDragPoint(Vector2 point, out Vector3 projected)
        {
            var plane = new Plane(Vector3.up, gestureOriginalPosition);
            var ray = sceneCamera.ScreenPointToRay(point);
            if (plane.Raycast(ray, out float distance))
            {
                projected = ray.GetPoint(distance);
                return true;
            }
            projected = default;
            return false;
        }

        private OrderDestination ResolveDropTarget(Vector2 point)
        {
            var ray = sceneCamera.ScreenPointToRay(point);
            OrderDestination closest = null;
            float maxDistance = 100f;
            if (sceneTargets == null) return null;
            foreach (var target in sceneTargets)
            {
                if (target == null || !target.gameObject.activeInHierarchy ||
                    (sceneCamera.cullingMask & (1 << target.gameObject.layer)) == 0)
                    continue;
                var collider = target.GetComponent<Collider>();
                if (collider == null || !collider.enabled || collider.isTrigger ||
                    !collider.Raycast(ray, out var hit, maxDistance))
                    continue;
                closest = target;
                maxDistance = hit.distance;
            }
            return closest;
        }

        private void OnDisable() => CancelWorldGesture();
    }
}
