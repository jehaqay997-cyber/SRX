using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class InspectionCameraContractTests
    {
        [Test]
        public void ZoomUpdatesProjectionSynchronouslyAndRejectsUnknownValues()
        {
            var root = new GameObject("InspectionCameraContractFixture");
            try
            {
                var view = root.AddComponent<ArtifactInspectionView>();
                view.Show(0);
                var camera = root.GetComponentInChildren<Camera>(true);
                Assert.IsNotNull(camera);
                Assert.IsTrue(camera.enabled);
                Assert.That(camera.fieldOfView, Is.EqualTo(38f).Within(0.001f));
                view.SetMagnification(150);
                Assert.That(camera.fieldOfView, Is.EqualTo(38f * 100f / 150f).Within(0.001f));
                view.SetMagnification(-1);
                Assert.That(camera.fieldOfView, Is.EqualTo(38f * 100f / 150f).Within(0.001f));
                view.SetMagnification(125);
                Assert.That(camera.fieldOfView, Is.EqualTo(38f * 100f / 125f).Within(0.001f));
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void ReopeningResetsZoomAndMaintainsInspectionIsolation()
        {
            var root = new GameObject("InspectionCameraIsolationFixture");
            try
            {
                var view = root.AddComponent<ArtifactInspectionView>();
                view.Show(0);
                view.SetMagnification(150);
                view.Hide();
                view.Show(0);
                var camera = root.GetComponentInChildren<Camera>(true);
                Assert.IsNotNull(camera);
                Assert.IsTrue(camera.enabled);
                Assert.That(camera.fieldOfView, Is.EqualTo(38f).Within(0.001f));
                Assert.AreEqual(ArtifactInspectionView.InspectionMask, camera.cullingMask);
                Assert.IsNull(camera.GetComponent<AudioListener>());
                Assert.IsTrue(camera.rect.width > 0f && camera.rect.width <= 1f);
                Assert.IsTrue(camera.rect.height > 0f && camera.rect.height <= 1f);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }
    }
}
