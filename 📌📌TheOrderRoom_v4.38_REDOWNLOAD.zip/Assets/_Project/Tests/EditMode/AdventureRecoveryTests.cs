using System;
using NUnit.Framework;
using TheOrderRoom.AppCore;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureRecoveryTests
    {
        private sealed class Store : IAdventureStore, IAdventureSnapshotReader
        {
            public AdventureSnapshot Persisted = AdventureChapter.NewGame();
            public bool Reject;
            public bool FailRead;
            public bool ThrowOnRead;
            public bool CommitDespiteUnknown;
            public Action DuringCommit;

            public AdventureCommitResult Commit(long expectedRevision, AdventureSnapshot candidate)
            {
                DuringCommit?.Invoke();
                if (Reject || Persisted.Revision != expectedRevision)
                    return AdventureCommitResult.Rejected;
                Persisted = candidate;
                return CommitDespiteUnknown ? AdventureCommitResult.Unknown : AdventureCommitResult.Committed;
            }

            public bool TryRead(out AdventureSnapshot snapshot)
            {
                if (ThrowOnRead) throw new InvalidOperationException("Simulated read failure.");
                snapshot = FailRead ? null : Persisted;
                return !FailRead;
            }
        }

        private sealed class WriteOnlyStore : IAdventureStore
        {
            public AdventureCommitResult Commit(long expectedRevision, AdventureSnapshot candidate)
                => AdventureCommitResult.Unknown;
        }

        [Test]
        public void ConflictCanRecoverOnlyFromAuthoritativeStore()
        {
            var store = new Store();
            var first = new AdventureSession(store.Persisted, store);
            var stale = new AdventureSession(store.Persisted, store);
            Assert.IsTrue(first.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsFalse(stale.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsTrue(stale.ReloadRequired);
            Assert.IsTrue(stale.TryReload(out string error), error);
            Assert.IsFalse(stale.ReloadRequired);
            Assert.AreEqual(1L, stale.Snapshot.Revision);
            Assert.IsTrue(stale.Act(AdventureAction.OpenArchive, 1, out error), error);
            Assert.AreEqual(2L, store.Persisted.Revision);
        }

        [Test]
        public void FailedReadNeverReleasesQuarantine()
        {
            var store = new Store { Reject = true };
            var session = new AdventureSession(store.Persisted, store);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
            store.FailRead = true;
            Assert.IsFalse(session.TryReload(out _));
            Assert.IsTrue(session.ReloadRequired);
            store.FailRead = false;
            store.ThrowOnRead = true;
            Assert.IsFalse(session.TryReload(out _));
            Assert.IsTrue(session.ReloadRequired);
            Assert.AreEqual(0L, session.Snapshot.Revision);
        }

        [Test]
        public void UnknownCommitCanBeReconciledWithoutRepeatingMutation()
        {
            var store = new Store { CommitDespiteUnknown = true };
            var session = new AdventureSession(store.Persisted, store);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsTrue(session.ReloadRequired);
            Assert.AreEqual(0L, session.Snapshot.Revision);
            Assert.AreEqual(1L, store.Persisted.Revision);
            store.CommitDespiteUnknown = false;
            Assert.IsTrue(session.TryReload(out string error), error);
            Assert.AreEqual(1L, session.Snapshot.Revision);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 1, out _));
            Assert.IsTrue(session.Act(AdventureAction.OpenArchive, 1, out error), error);
        }

        [Test]
        public void OlderStorageReadCannotRewindSession()
        {
            var store = new Store();
            var session = new AdventureSession(store.Persisted, store);
            Assert.IsTrue(session.Act(AdventureAction.TakeKey, 0, out _));
            store.Persisted = AdventureChapter.NewGame();
            Assert.IsFalse(session.TryReload(out _));
            Assert.AreEqual(1L, session.Snapshot.Revision);
        }

        [Test]
        public void ReloadDuringCommitIsBlocked()
        {
            var store = new Store();
            var session = new AdventureSession(store.Persisted, store);
            bool didReload = true;
            store.DuringCommit = () => didReload = session.TryReload(out _);
            Assert.IsTrue(session.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsFalse(didReload);
        }

        [Test]
        public void StoreWithoutReaderCannotPretendToRecover()
        {
            var session = new AdventureSession(AdventureChapter.NewGame(), new WriteOnlyStore());
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsFalse(session.TryReload(out _));
            Assert.IsTrue(session.ReloadRequired);
        }
    }
}
