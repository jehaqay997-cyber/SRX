using System;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.AppCore;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureChapterTests
    {
        private sealed class Store : IAdventureStore
        {
            public AdventureSnapshot Persisted = AdventureChapter.NewGame();
            public AdventureCommitResult Next = AdventureCommitResult.Committed;
            public bool Throw;
            public Action DuringCommit;
            public AdventureCommitResult Commit(long expectedRevision, AdventureSnapshot candidate)
            {
                DuringCommit?.Invoke();
                if (Throw) throw new InvalidOperationException("Injected storage failure");
                if (Next != AdventureCommitResult.Committed) return Next;
                if (Persisted.Revision != expectedRevision) return AdventureCommitResult.Rejected;
                Persisted = candidate; return AdventureCommitResult.Committed;
            }
        }
        private static void Act(AdventureSession session, AdventureAction action)
        { Assert.IsTrue(session.Act(action, session.Snapshot.Revision, out string error), error); }
        private static void Travel(AdventureSession session, AdventureLocation location)
        { Assert.IsTrue(session.Travel(location, session.Snapshot.Revision, out string error), error); }
        [Test]
        public void CompleteChapterConsumesToolsAndSurvivesSessionReconstruction()
        {
            var store = new Store(); var session = new AdventureSession(store.Persisted, store);
            Act(session, AdventureAction.TakeKey);
            CollectionAssert.AreEqual(new[] { "brass-key" }, session.Snapshot.Inventory());
            Act(session, AdventureAction.OpenArchive);
            Assert.IsEmpty(session.Snapshot.Inventory());
            Travel(session, AdventureLocation.Archive);
            Act(session, AdventureAction.TakeLens); Act(session, AdventureAction.TakeMount);
            session = new AdventureSession(store.Persisted, store);
            Act(session, AdventureAction.AssembleLens);
            CollectionAssert.AreEqual(new[] { "mounted-lens" }, session.Snapshot.Inventory());
            Travel(session, AdventureLocation.Courtyard); Travel(session, AdventureLocation.Observatory);
            Act(session, AdventureAction.InstallLens);
            Assert.IsEmpty(session.Snapshot.Inventory());
            Assert.IsTrue(store.Persisted.Has(AdventureFacts.LensInstalled));
        }
        [Test]
        public void WrongLocationMissingToolsDuplicatesAndStaleCommandsAreRejected()
        {
            var store = new Store(); var session = new AdventureSession(store.Persisted, store);
            Assert.IsFalse(session.Travel(AdventureLocation.Archive, 0, out _));
            Assert.IsFalse(session.Act(AdventureAction.TakeLens, 0, out _));
            Assert.IsFalse(session.Act(AdventureAction.AssembleLens, 0, out _));
            Act(session, AdventureAction.TakeKey);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 1, out _));
            Assert.IsFalse(session.Act(AdventureAction.OpenArchive, 0, out _));
            Assert.AreEqual(1, session.Snapshot.Revision);
        }
        [TestCase(AdventureCommitResult.Rejected)] [TestCase(AdventureCommitResult.Unknown)]
        public void FailedCommitDoesNotPublishCandidateAndRequiresReload(AdventureCommitResult result)
        {
            var store = new Store { Next = result }; var session = new AdventureSession(store.Persisted, store);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
            Assert.AreEqual(0, session.Snapshot.Revision); Assert.IsTrue(session.ReloadRequired);
            store.Next = AdventureCommitResult.Committed;
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
        }
        [Test]
        public void StorageExceptionBlocksFurtherCommands()
        {
            var store = new Store { Throw = true }; var session = new AdventureSession(store.Persisted, store);
            Assert.IsFalse(session.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsTrue(session.ReloadRequired); Assert.IsEmpty(session.Snapshot.Inventory());
        }
        [Test]
        public void ReentrantStoreCannotExecuteNestedCommand()
        {
            var store = new Store(); var session = new AdventureSession(store.Persisted, store);
            bool nested = true;
            store.DuringCommit = () => nested = session.Act(AdventureAction.TakeKey, 0, out _);
            Act(session, AdventureAction.TakeKey); Assert.IsFalse(nested);
            Assert.AreEqual(1, session.Snapshot.Revision);
        }
        [Test]
        public void TwoSessionsCannotOverwriteEachOthersProgress()
        {
            var store = new Store(); var first = new AdventureSession(store.Persisted, store);
            var stale = new AdventureSession(store.Persisted, store);
            Act(first, AdventureAction.TakeKey);
            Assert.IsFalse(stale.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsTrue(stale.ReloadRequired); Assert.AreEqual(1, store.Persisted.Revision);
        }
        [Test]
        public void RestorationRejectsFutureVersionsAndImpossibleFacts()
        {
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(2, 0, AdventureLocation.Courtyard, AdventureFacts.None));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, 0, AdventureLocation.Courtyard, AdventureFacts.LensInstalled));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, 0, AdventureLocation.Archive, AdventureFacts.None));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, -1, AdventureLocation.Courtyard, AdventureFacts.None));
        }
        [Test]
        public void ExhaustedRevisionDoesNotWrap()
        {
            var snapshot = new AdventureSnapshot(1, long.MaxValue, AdventureLocation.Courtyard, AdventureFacts.None);
            Assert.IsFalse(AdventureChapter.TryAct(snapshot, AdventureAction.TakeKey, long.MaxValue, out _, out _));
        }
    }
}
