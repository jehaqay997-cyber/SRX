using System;
using System.IO;
using NUnit.Framework;
using TheOrderRoom.AppCore;
using TheOrderRoom.Domain;
using TheOrderRoom.Infrastructure;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureJournalReadSafetyTests
    {
        private string directory;
        private AdventureJournalStore store;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "tor-read-safety-" + Guid.NewGuid().ToString("N"));
            store = new AdventureJournalStore(directory);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        [Test]
        public void ReopenValidRecordRemainsReadable()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot next, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, next));
            Assert.IsTrue(new AdventureJournalStore(directory).TryRead(out AdventureSnapshot persisted));
            Assert.AreEqual(1L, persisted.Revision);
            Assert.AreEqual(AdventureFacts.KeyTaken, persisted.Facts);
        }

        [Test]
        public void TruncatedRecordIsRejectedWithoutDeletingEvidence()
        {
            Assert.IsTrue(store.TryInitialize(out _));
            string record = Path.Combine(directory, "adventure.r00000000000000000000.bin");
            using (var stream = new FileStream(record, FileMode.Open, FileAccess.Write, FileShare.None))
                stream.SetLength(4);
            Assert.IsFalse(store.TryRead(out _));
            Assert.AreEqual(4L, new FileInfo(record).Length);
        }

        [Test]
        public void OversizedRecordIsRejectedWithoutDeletingEvidence()
        {
            Assert.IsTrue(store.TryInitialize(out _));
            string record = Path.Combine(directory, "adventure.r00000000000000000000.bin");
            using (var stream = new FileStream(record, FileMode.Open, FileAccess.Write, FileShare.None))
                stream.SetLength(8 * 1024 * 1024);
            Assert.IsFalse(store.TryRead(out _));
            Assert.AreEqual(8L * 1024 * 1024, new FileInfo(record).Length);
        }

        [Test]
        public void ExcessiveRecordCountFailsClosed()
        {
            Assert.IsTrue(store.TryInitialize(out _));
            for (int index = 1; index <= 10000; index++)
            {
                string path = Path.Combine(directory, "adventure.r" + index.ToString("D20") + ".bin");
                using (File.Create(path)) { }
            }
            Assert.IsFalse(store.TryRead(out _));
            Assert.IsFalse(store.TryInitialize(out _));
        }
    }
}
