using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class WorldGestureTapSafetyTests
    {
        [Test]
        public void ShortMovementIsTap()
        {
            Assert.IsTrue(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(5f, 5f), 0f));
        }

        [Test]
        public void ReleaseAtOrBeyondThresholdIsNotTap()
        {
            Assert.IsFalse(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(10f, 0f), 0f));
            Assert.IsFalse(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(100f, 0f), 200f));
        }

        [Test]
        public void ThresholdUsesBoundedDpi()
        {
            Assert.IsTrue(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(20f, 0f), 1000f));
            Assert.IsFalse(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(32f, 0f), 1000f));
        }

        [Test]
        public void ExactOriginAndEndMatchIsTap()
        {
            Assert.IsTrue(OrderGame.IsTapWithinThreshold(new Vector2(80f, 50f), new Vector2(80f, 50f), 180f));
        }

        [Test]
        public void NonFiniteScreenCoordinatesAreRejected()
        {
            Assert.IsFalse(OrderGame.IsTapWithinThreshold(Vector2.zero, new Vector2(float.NaN, 0f), 160f));
            Assert.IsFalse(OrderGame.IsTapWithinThreshold(new Vector2(float.PositiveInfinity, 0f), Vector2.one, 160f));
        }
    }
}
