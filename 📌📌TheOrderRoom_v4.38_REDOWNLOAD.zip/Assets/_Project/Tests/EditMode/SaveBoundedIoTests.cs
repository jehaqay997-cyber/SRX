using System;
using System.IO;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveBoundedIoTests
    {
        private string directory;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "tor-bounded-io-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            OrderSaveStore.TestStorageDirectory = directory;
        }

        [TearDown]
        public void TearDown()
        {
            OrderSaveStore.ResetTestSeams();
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        [Test]
        public void OversizedLegacySaveIsRejectedWithoutModification()
        {
            string path = Path.Combine(directory, "the_order_room_v1.json");
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write))
                stream.SetLength(1024 * 1024 + 1);
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out _));
            Assert.AreEqual(1024 * 1024 + 1, new FileInfo(path).Length);
        }

        [Test]
        public void InvalidUtf8LegacySaveIsRejectedWithoutModification()
        {
            string path = Path.Combine(directory, "the_order_room_v1.json");
            byte[] malformed = { 0xC3, 0x28 };
            File.WriteAllBytes(path, malformed);
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out _));
            CollectionAssert.AreEqual(malformed, File.ReadAllBytes(path));
        }

        [Test]
        public void ExcessiveJournalEntriesFailClosedWithoutDeletingFiles()
        {
            for (int i = 0; i <= 4096; i++)
            {
                string path = Path.Combine(directory, "the_order_room_v1.json.g" + i.ToString("D20") + ".json");
                File.WriteAllText(path, "invalid");
            }
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out string error));
            StringAssert.Contains("InvalidDataException", error);
            Assert.AreEqual(4097, Directory.GetFiles(directory, "*.json").Length);
        }
    }
}
