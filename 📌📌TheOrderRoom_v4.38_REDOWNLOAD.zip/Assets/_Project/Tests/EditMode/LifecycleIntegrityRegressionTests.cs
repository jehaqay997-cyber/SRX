using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class LifecycleIntegrityRegressionTests
    {
        [Test]
        public void LayoutDisableRestoresCameraCanvasAndSafeAreaState()
        {
            var scene = new GameObject("LayoutLifecycleFixture");
            var cameraObject = new GameObject("Camera");
            var canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
            try
            {
                cameraObject.transform.SetParent(scene.transform);
                canvasObject.transform.SetParent(scene.transform);
                var camera = cameraObject.AddComponent<Camera>();
                var rect = canvasObject.GetComponent<RectTransform>();
                var scaler = canvasObject.GetComponent<CanvasScaler>();
                var originalRect = new Rect(0.15f, 0.12f, 0.7f, 0.72f);
                camera.rect = originalRect;
                camera.transform.position = new Vector3(1f, 2f, 3f);
                camera.transform.rotation = Quaternion.Euler(15f, 25f, 0f);
                rect.anchorMin = new Vector2(0.11f, 0.22f);
                rect.anchorMax = new Vector2(0.88f, 0.91f);
                rect.offsetMin = new Vector2(13f, 17f);
                rect.offsetMax = new Vector2(-11f, -19f);
                scaler.referenceResolution = new Vector2(1024f, 768f);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                Vector3 expectedPosition = camera.transform.position;
                Quaternion expectedRotation = camera.transform.rotation;
                Vector2 expectedAnchorMin = rect.anchorMin;
                Vector2 expectedAnchorMax = rect.anchorMax;
                Vector2 expectedOffsetMin = rect.offsetMin;
                Vector2 expectedOffsetMax = rect.offsetMax;
                Vector2 expectedResolution = scaler.referenceResolution;
                var layout = scene.AddComponent<OrderScreenLayout>();
                layout.Configure(camera, rect, scaler);
                camera.rect = new Rect(0f, 0f, 1f, 1f);
                camera.transform.position = Vector3.zero;
                camera.transform.rotation = Quaternion.identity;
                rect.anchorMin = Vector2.zero;
                rect.anchorMax = Vector2.one;
                rect.offsetMin = Vector2.zero;
                rect.offsetMax = Vector2.zero;
                scaler.referenceResolution = new Vector2(720f, 1280f);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
                layout.enabled = false;
                Assert.AreEqual(originalRect, camera.rect);
                Assert.AreEqual(expectedPosition, camera.transform.position);
                Assert.AreEqual(expectedRotation, camera.transform.rotation);
                Assert.AreEqual(expectedAnchorMin, rect.anchorMin);
                Assert.AreEqual(expectedAnchorMax, rect.anchorMax);
                Assert.AreEqual(expectedOffsetMin, rect.offsetMin);
                Assert.AreEqual(expectedOffsetMax, rect.offsetMax);
                Assert.AreEqual(expectedResolution, scaler.referenceResolution);
                Assert.AreEqual(CanvasScaler.ScreenMatchMode.MatchWidthOrHeight, scaler.screenMatchMode);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(scene);
            }
        }

        [Test]
        public void LosingFocusBlocksNewGesturesUntilContactsAreReleased()
        {
            var root = new GameObject("PointerLifecycleFixture");
            try
            {
                var input = root.AddComponent<OrderPointerInput>();
                var pause = typeof(OrderPointerInput).GetMethod(
                    "OnApplicationPause", BindingFlags.NonPublic | BindingFlags.Instance);
                var blocked = typeof(OrderPointerInput).GetField(
                    "blockUntilTouchesEnd", BindingFlags.NonPublic | BindingFlags.Instance);
                Assert.IsNotNull(pause);
                Assert.IsNotNull(blocked);
                pause.Invoke(input, new object[] { true });
                Assert.IsTrue((bool)blocked.GetValue(input));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }
    }
}
