using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class FrameBudgetPolicyTests
    {
        [Test]
        public void InitialTargetsMatchPlatformClass()
        {
            Assert.AreEqual(30, FrameBudgetPolicy.InitialTarget(true));
            Assert.AreEqual(60, FrameBudgetPolicy.InitialTarget(false));
        }

        [Test]
        public void LowBatteryOnlyThrottlesWhenKnownAndDischarging()
        {
            Assert.AreEqual(24, FrameBudgetPolicy.Choose(60, 16, .1, true, 0));
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 16, .1, false, 0));
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 16, -1, true, 0));
        }

        [Test]
        public void SlowWindowsRequireHysteresisAndNeverIncreaseTarget()
        {
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 40, .8, false, 2));
            Assert.AreEqual(30, FrameBudgetPolicy.Choose(60, 40, .8, false, 3));
            Assert.AreEqual(24, FrameBudgetPolicy.Choose(30, 48, .8, false, 3));
            Assert.AreEqual(30, FrameBudgetPolicy.Choose(30, 10, .8, false, 100));
        }

        [Test]
        public void RejectsInvalidMeasurementsAndTargets()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(45, 20, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, double.NaN, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, -1, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, 20, .5, true, -1));
        }
    }
}
