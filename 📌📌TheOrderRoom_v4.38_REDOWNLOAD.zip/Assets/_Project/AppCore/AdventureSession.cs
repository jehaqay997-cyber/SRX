using System;
using TheOrderRoom.Domain;
namespace TheOrderRoom.AppCore
{
    public enum AdventureCommitResult { Committed, Rejected, Unknown }
    public interface IAdventureStore
    {
        // Compare-and-swap: commit the complete snapshot only if its persisted revision matches.
        // Unknown means the write may have reached storage; clients must reload before another command.
        AdventureCommitResult Commit(long expectedRevision, AdventureSnapshot candidate);
    }
    // Reading must come from the same authoritative storage boundary as Commit.
    // A caller-supplied snapshot must never be accepted as a conflict resolution.
    public interface IAdventureSnapshotReader
    {
        bool TryRead(out AdventureSnapshot snapshot);
    }

    public sealed class AdventureSession
    {
        private readonly object gate = new object();
        private readonly IAdventureStore store;
        private AdventureSnapshot state;
        private bool reloadRequired;
        private bool committing;
        private bool reloading;
        public AdventureSnapshot Snapshot { get { lock (gate) return state; } }
        public bool ReloadRequired { get { lock (gate) return reloadRequired; } }
        public AdventureSession(AdventureSnapshot initial, IAdventureStore store)
        { state = initial ?? throw new ArgumentNullException(nameof(initial)); this.store = store ?? throw new ArgumentNullException(nameof(store)); }
        public bool Act(AdventureAction action, long expectedRevision, out string error)
        {
            lock (gate)
            {
                if (!CanExecute(out error)) return false;
                if (!AdventureChapter.TryAct(state, action, expectedRevision, out var candidate, out error)) return false;
                return Commit(candidate, out error);
            }
        }
        public bool Travel(AdventureLocation target, long expectedRevision, out string error)
        {
            lock (gate)
            {
                if (!CanExecute(out error)) return false;
                if (!AdventureChapter.TryTravel(state, target, expectedRevision, out var candidate, out error)) return false;
                return Commit(candidate, out error);
            }
        }
        public bool TryReload(out string error)
        {
            lock (gate)
            {
                if (committing || reloading)
                {
                    error = "Cannot reload while a commit or another reload is active.";
                    return false;
                }
                if (!(store is IAdventureSnapshotReader reader))
                {
                    error = "The store does not support authoritative reload.";
                    return false;
                }
                AdventureSnapshot authoritative;
                reloading = true;
                try
                {
                    if (!reader.TryRead(out authoritative) || authoritative == null)
                    {
                        error = "No verified authoritative adventure state is available.";
                        return false;
                    }
                }
                catch (Exception)
                {
                    error = "Authoritative adventure reload failed.";
                    return false;
                }
                finally { reloading = false; }
                // A stale read must not silently rewind the in-memory session.
                if (authoritative.Revision < state.Revision)
                {
                    error = "Authoritative state is older than the current session.";
                    return false;
                }
                state = authoritative;
                reloadRequired = false;
                error = null;
                return true;
            }
        }

        private bool CanExecute(out string error)
        {
            error = committing ? "A commit is already in progress." : reloading ? "An authoritative reload is in progress." : reloadRequired ? "Reload the authoritative save before continuing." : null;
            return error == null;
        }
        private bool Commit(AdventureSnapshot candidate, out string error)
        {
            error = null; committing = true;
            try
            {
                AdventureCommitResult result = store.Commit(state.Revision, candidate);
                if (result == AdventureCommitResult.Committed) { state = candidate; return true; }
                reloadRequired = true;
                error = result == AdventureCommitResult.Rejected ? "Save conflict; reload required." : "Commit status unknown; reload required.";
                return false;
            }
            catch (Exception)
            {
                reloadRequired = true; error = "Save failed with unknown commit status; reload required."; return false;
            }
            finally { committing = false; }
        }
    }
}
