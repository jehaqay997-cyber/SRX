using System;

namespace TheOrderRoom.Domain
{
    public sealed class EnergyPuzzle
    {
        // Clockwise ports: north=1, east=2, south=4, west=8.
        private static readonly int[] Solution = { 10, 12, 0, 0, 5, 0, 0, 3, 10 };
        private readonly int[] initial = new int[9];
        private readonly int[] ports = new int[9];
        private readonly BoundedHistory<int[]> history = new BoundedHistory<int[]>(128);
        public long Revision { get; private set; }
        public EnergyPuzzle(int seed)
        {
            if (seed < 0) throw new ArgumentOutOfRangeException(nameof(seed));
            for (int i = 0; i < 9; i++)
            {
                int mask = Solution[i];
                int turns = (int)(((long)seed + i * 3L) % 4);
                for (int turn = 0; turn < turns; turn++) mask = RotateMask(mask);
                initial[i] = ports[i] = mask;
            }
            // Every board starts with a disconnected source.
            initial[0] = ports[0] = 5;
        }
        private static int RotateMask(int mask) => ((mask << 1) & 15) | (mask >> 3);
        public int Ports(int index)
        {
            if (index < 0 || index >= 9) throw new ArgumentOutOfRangeException(nameof(index));
            return ports[index];
        }
        public bool Rotate(int index, long expectedRevision)
        {
            if (index < 0 || index >= 9 || expectedRevision != Revision || Revision == long.MaxValue || ports[index] == 0 || IsSolved) return false;
            // Share the constant-time bounded journal with board Undo/Redo.
            history.Push((int[])ports.Clone());
            ports[index] = RotateMask(ports[index]);
            Revision++;
            return true;
        }
        public bool Undo()
        {
            if (history.Count == 0 || Revision == long.MaxValue) return false;
            Array.Copy(history.Pop(), ports, ports.Length);
            Revision++;
            return true;
        }
        public bool Reset()
        {
            if (Revision == long.MaxValue) return false;
            Array.Copy(initial, ports, 9); history.Clear(); Revision++; return true;
        }
        public bool[] Powered()
        {
            var visited = new bool[9];
            if ((ports[0] & 8) == 0) return visited;
            var queue = new int[9]; int read = 0, count = 1; queue[0] = 0; visited[0] = true;
            while (read < count)
            {
                int cell = queue[read++];
                for (int direction = 0; direction < 4; direction++)
                {
                    if ((ports[cell] & (1 << direction)) == 0) continue;
                    int row = cell / 3, col = cell % 3;
                    int next = direction == 0 ? cell - 3 : direction == 1 ? cell + 1 : direction == 2 ? cell + 3 : cell - 1;
                    if ((direction == 0 && row == 0) || (direction == 1 && col == 2) ||
                        (direction == 2 && row == 2) || (direction == 3 && col == 0)) continue;
                    if (!visited[next] && (ports[next] & (1 << ((direction + 2) % 4))) != 0)
                    { visited[next] = true; queue[count++] = next; }
                }
            }
            return visited;
        }
        public bool IsSolved => (ports[8] & 2) != 0 && Powered()[8];
        public int Hint()
        {
            if (IsSolved) return -1;
            // The authored route is a constructive witness, not a shortest-path claim.
            foreach (int cell in new[] { 0, 1, 4, 7, 8 })
                if (ports[cell] != Solution[cell]) return cell;
            return -1;
        }
    }
}
