using System;
namespace TheOrderRoom.Domain
{
    public sealed class OpticalFocus
    {
        public int Magnification { get; private set; } = 100;
        public bool Adjust(int direction)
        {
            if (direction != -1 && direction != 1) return false;
            int candidate = Magnification + direction * 25;
            if (candidate < 100 || candidate > 150) return false;
            Magnification = candidate; return true;
        }
        public static int Required(int orientation)
        {
            if (orientation < 0 || orientation > 3) throw new ArgumentOutOfRangeException(nameof(orientation));
            return orientation == 3 ? 100 : 100 + orientation * 25;
        }
        public bool IsFocused(int orientation) => orientation < 3 && orientation >= 0 && Magnification == Required(orientation);
        public void Reset() => Magnification = 100;
    }
}
