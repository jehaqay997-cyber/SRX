using System;

namespace TheOrderRoom.Domain
{
    /// <summary>Pure decision policy for user-visible refresh rates. All values are in milliseconds.</summary>
    public static class FrameBudgetPolicy
    {
        public const int Low = 24;
        public const int Balanced = 30;
        public const int High = 60;

        public static int InitialTarget(bool mobile) => mobile ? Balanced : High;

        public static int Choose(int current, double meanFrameMilliseconds, double batteryLevel,
            bool batteryDischarging, int consecutiveSlowWindows)
        {
            if (current != Low && current != Balanced && current != High)
                throw new ArgumentOutOfRangeException(nameof(current));
            if (double.IsNaN(meanFrameMilliseconds) || double.IsInfinity(meanFrameMilliseconds) ||
                meanFrameMilliseconds < 0)
                throw new ArgumentOutOfRangeException(nameof(meanFrameMilliseconds));
            if (consecutiveSlowWindows < 0) throw new ArgumentOutOfRangeException(nameof(consecutiveSlowWindows));

            // -1 is the platform's unknown battery reading. It must not be interpreted as empty.
            bool knownBattery = batteryLevel >= 0 && batteryLevel <= 1 &&
                !double.IsNaN(batteryLevel) && !double.IsInfinity(batteryLevel);
            if (batteryDischarging && knownBattery && batteryLevel <= 0.15) return Low;
            if (consecutiveSlowWindows < 3) return current;
            // Require a sustained >25% frame-budget overrun before stepping down.
            if (current == High && meanFrameMilliseconds > 1000.0 / High * 1.25) return Balanced;
            if (current == Balanced && meanFrameMilliseconds > 1000.0 / Balanced * 1.25) return Low;
            // No automatic promotion: a throttled target cannot measure headroom for 60fps.
            return current;
        }
    }
}
