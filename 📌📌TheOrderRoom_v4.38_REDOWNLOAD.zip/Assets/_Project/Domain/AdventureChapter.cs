using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum AdventureLocation { Courtyard, Archive, Observatory }
    public enum AdventureAction { TakeKey, OpenArchive, TakeLens, TakeMount, AssembleLens, InstallLens }
    [Flags]
    public enum AdventureFacts
    {
        None = 0, KeyTaken = 1, ArchiveOpened = 2, LensTaken = 4,
        MountTaken = 8, LensAssembled = 16, LensInstalled = 32
    }
    public sealed class AdventureSnapshot
    {
        public const int CurrentSchema = 1;
        public int Schema { get; }
        public long Revision { get; }
        public AdventureLocation Location { get; }
        public AdventureFacts Facts { get; }
        public AdventureSnapshot(int schema, long revision, AdventureLocation location, AdventureFacts facts)
        {
            if (schema != CurrentSchema) throw new ArgumentException("Unsupported adventure schema.");
            if (revision < 0 || !Enum.IsDefined(typeof(AdventureLocation), location) || ((int)facts & ~63) != 0)
                throw new ArgumentException("Invalid adventure state.");
            bool Has(AdventureFacts flag) => (facts & flag) == flag;
            if ((Has(AdventureFacts.ArchiveOpened) && !Has(AdventureFacts.KeyTaken)) ||
                ((Has(AdventureFacts.LensTaken) || Has(AdventureFacts.MountTaken)) && !Has(AdventureFacts.ArchiveOpened)) ||
                (Has(AdventureFacts.LensAssembled) && !Has(AdventureFacts.LensTaken | AdventureFacts.MountTaken)) ||
                (Has(AdventureFacts.LensInstalled) && !Has(AdventureFacts.LensAssembled)) ||
                (location != AdventureLocation.Courtyard && !Has(AdventureFacts.ArchiveOpened)))
                throw new ArgumentException("Adventure prerequisites are inconsistent.");
            Schema = schema; Revision = revision; Location = location; Facts = facts;
        }
        public bool Has(AdventureFacts fact) => (Facts & fact) == fact;
        public IReadOnlyList<string> Inventory()
        {
            var ids = new List<string>();
            if (Has(AdventureFacts.KeyTaken) && !Has(AdventureFacts.ArchiveOpened)) ids.Add("brass-key");
            if (Has(AdventureFacts.LensTaken) && !Has(AdventureFacts.LensAssembled)) ids.Add("lens");
            if (Has(AdventureFacts.MountTaken) && !Has(AdventureFacts.LensAssembled)) ids.Add("lens-mount");
            if (Has(AdventureFacts.LensAssembled) && !Has(AdventureFacts.LensInstalled)) ids.Add("mounted-lens");
            return ids.AsReadOnly();
        }
        public string Objective => !Has(AdventureFacts.KeyTaken) ? "Find the courtyard key." :
            !Has(AdventureFacts.ArchiveOpened) ? "Unlock the archive." :
            !Has(AdventureFacts.LensTaken | AdventureFacts.MountTaken) ? "Search the archive for the lens and its mount." :
            !Has(AdventureFacts.LensAssembled) ? "Assemble the lens in your inventory." :
            !Has(AdventureFacts.LensInstalled) ? "Install the lens in the observatory." : "Inspect the illuminated mechanism.";
    }
    public static class AdventureChapter
    {
        public static AdventureSnapshot NewGame() => new AdventureSnapshot(1, 0, AdventureLocation.Courtyard, AdventureFacts.None);
        public static bool TryTravel(AdventureSnapshot current, AdventureLocation target, long expectedRevision,
            out AdventureSnapshot candidate, out string error)
        {
            candidate = null;
            if (!CanChange(current, expectedRevision, out error)) return false;
            if (!Enum.IsDefined(typeof(AdventureLocation), target) || current.Location == target)
            { error = "Invalid destination."; return false; }
            if (current.Location != AdventureLocation.Courtyard && target != AdventureLocation.Courtyard)
            { error = "Return through the courtyard."; return false; }
            if (target != AdventureLocation.Courtyard && !current.Has(AdventureFacts.ArchiveOpened))
            { error = "The archive key opens the inner grounds."; return false; }
            candidate = new AdventureSnapshot(1, current.Revision + 1, target, current.Facts);
            return true;
        }
        public static bool TryAct(AdventureSnapshot current, AdventureAction action, long expectedRevision,
            out AdventureSnapshot candidate, out string error)
        {
            candidate = null;
            if (!CanChange(current, expectedRevision, out error)) return false;
            AdventureFacts added, prerequisites;
            AdventureLocation location;
            switch (action)
            {
                case AdventureAction.TakeKey: added = AdventureFacts.KeyTaken; prerequisites = AdventureFacts.None; location = AdventureLocation.Courtyard; break;
                case AdventureAction.OpenArchive: added = AdventureFacts.ArchiveOpened; prerequisites = AdventureFacts.KeyTaken; location = AdventureLocation.Courtyard; break;
                case AdventureAction.TakeLens: added = AdventureFacts.LensTaken; prerequisites = AdventureFacts.ArchiveOpened; location = AdventureLocation.Archive; break;
                case AdventureAction.TakeMount: added = AdventureFacts.MountTaken; prerequisites = AdventureFacts.ArchiveOpened; location = AdventureLocation.Archive; break;
                case AdventureAction.AssembleLens: added = AdventureFacts.LensAssembled; prerequisites = AdventureFacts.LensTaken | AdventureFacts.MountTaken; location = current.Location; break;
                case AdventureAction.InstallLens: added = AdventureFacts.LensInstalled; prerequisites = AdventureFacts.LensAssembled; location = AdventureLocation.Observatory; break;
                default: error = "Unknown adventure action."; return false;
            }
            if (current.Location != location || !current.Has(prerequisites) || current.Has(added))
            { error = "Action prerequisites are not met, or the action is already complete."; return false; }
            candidate = new AdventureSnapshot(1, current.Revision + 1, current.Location, current.Facts | added);
            return true;
        }
        private static bool CanChange(AdventureSnapshot current, long expectedRevision, out string error)
        {
            error = null;
            if (current == null) { error = "Missing adventure state."; return false; }
            if (current.Revision != expectedRevision) { error = "Stale adventure command."; return false; }
            if (current.Revision == long.MaxValue) { error = "Revision exhausted."; return false; }
            return true;
        }
    }
}
