# TheOrderRoom v4.30 — Source remediation and verification

## Scope

Based on the recovered v4.29 candidate. All original archive entries are retained, with `Assets/_Project/Runtime/OrderScreenLayout.cs` as the only changed gameplay source. Existing generated verification reports are refreshed by the rerun. Added one Unity EditMode regression test and its `.meta`, plus two executable Python source-contract checks.

## Confirmed root cause

`OrderScreenLayout.Arrange` and `Place` mutate UI child RectTransforms and label auto-sizing, but the previous disable/reconfigure path restored only the board camera, content root anchors/offsets and CanvasScaler. Child controls could retain layout modifications across disabling or replacement, producing layout drift.

## Remediation

Capture the first pre-layout state of each modified child RectTransform and Text, including anchors, offsets, anchoredPosition, sizeDelta and best-fit text sizing. Restore the captured values on disable or reconfigure and clear the capture dictionaries. Capture each element once per activation, and do not add per-frame allocations for static layouts.

## Verification

- `Verification/screen_layout_gate_v430.py`: ten source invariants (static only).
- `Verification/test_screen_layout_gate_v430.py`: one positive and three mutation-negative checks.
- `Assets/_Project/Tests/EditMode/ScreenLayoutRestorationRegressionTests.cs`: new NUnit regression test, not executed here.
- Previous source governance, architecture, camera and integration gates rerun successfully.
- Independent Python adventure model checked; limited model only.
- Unity, dotnet SDK and C# compiler were not installed in the execution environment; compilation and Unity tests were NOT run.

## Blocked release gates

1. Unity 2022.3.62f3 C# assembly compilation and package resolution.
2. Batch-generated scene validation and Unity EditMode + PlayMode testing.
3. Actual Android interaction and suspend/resume, storage power-interruption fault injection.
4. Device profiling for CPU/GPU/GC/memory/battery thermal behavior.
5. Cross-system adventure/store/UI integration and end-to-end gameplay acceptance.

The root cause above is remediated in source; it is not yet runtime-verified. This package is a development candidate, not a release build.

## Primary documentation

- Unity 2022.3 `Application.targetFrameRate`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Application-targetFrameRate.html
- Unity Test Framework command line: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Microsoft .NET FileStream: https://learn.microsoft.com/en-us/dotnet/api/system.io.filestream
