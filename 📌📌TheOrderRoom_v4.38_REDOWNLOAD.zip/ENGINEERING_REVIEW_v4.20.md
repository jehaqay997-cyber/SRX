# TheOrderRoom v4.20 — Engineering continuation and evidence ledger

Date: 2026-11-16. Baseline: v4.19 ROOT_CAUSE_REMEDIATION. This is a **candidate for testing**, not an approved release.

## Verified source changes

1. New `Assets/_Project/Infrastructure` assembly (`noEngineReferences=true`, references only Domain + AppCore), including `AdventureJournalStore.cs`. Persistence remains separate from AppCore and Domain.
2. The adventure journal uses a persisted genesis record, same-directory temporary-file publishing, append-only revision files, exclusive cross-process OS file locking, and compare-and-swap against the authoritative latest revision. Every accepted candidate must match one production Domain transition. Duplicate/stale revisions are rejected. Failed or ambiguous writes signal `Unknown`; callers quarantine until authoritative reload.
3. Journal parser validates fixed binary payload size *before allocating*, schema/state constraints, latest digest, contiguous revision identifiers, and bounded record count. Missing/damaged latest files fail closed rather than loading older state silently.
4. `AdventureSession.TryReload` blocks recursion and mutation while a store callback is running; reload failure does not clear quarantine.
5. Added `AdventureJournalStoreTests.cs` with regression cases for initialization, duplicate commit, forged transition, corrupt record, conflicting writers, deleted records, oversized records, and invalid prefixes.
6. Updated Unity test asmdef and portable .NET verification project; added `.meta` files for new Unity sources.

## Explicitly unresolved / not claimed

- **P0:** Unity compilation and NUnit tests are NOT executed. .NET SDK, Unity Editor, and Android device were not available here. All newly authored C# requires actual compilation.
- **P0:** Adventure journal is an **implemented infrastructure adapter** but is not yet wired into a real Unity gameplay scene. The existing `OrderSaveStore` remains a separate save system and is not replaced.
- **P1:** Full crash-power durability depends on filesystem and storage barriers; `Flush(true)` is used, but parent-directory `fsync` is not portable in this adapter. Device-level fault injection is still required.
- **P1:** SHA-256 is accidental corruption detection, not an anti-cheat signature or authentication. A malicious party with local file write access can rewrite records and digests.
- **P1:** Journal storage is bounded to 10,000 records with fail-closed overflow; snapshotting and **provably safe** pruning/compaction are a future feature. Journal writes require writable local persistent storage and exclusive file-lock semantics verified on target OS.
- **P1:** The supplied initial session state must be obtained from `TryInitialize` or `TryRead` rather than user input; this remains a caller contract. Never trust arbitrary imported states.
- **P1:** Python state-space result covers only the fixed 20-state example, not all procedural chapters or visual accessibility.
- **P2:** Existing runtime architecture retains coupling to Unity APIs; migration is ongoing.
- **Version:** Existing editor target is `2022.3.62f3`, not a proven `6.3.28f1` migration.

## Verification gate

Run `python Verification/verify_v4_20.py` and `python Verification/audit_candidate.py`, then compile and test with the exact installed Unity Editor. Run portable tests using `Verification/PORTABLE_RUN.md` when .NET 8 SDK is available; retain test logs. Do not mark COMPILE_VERIFIED, TEST_VERIFIED, or DEVICE_VERIFIED until appropriate evidence exists.
