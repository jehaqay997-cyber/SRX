# TheOrderRoom v4.15 | Adventure architecture foundation candidate

Unity Editor: **2022.3.62f3**.

Base archive: TheOrderRoom_Unity2022.3.62f3_v4.10_PACKAGE_RESOLUTION_FIX_CANDIDATE.zip.
Package date: 2026-11-15.
Status: source candidate; Unity compilation, runtime tests and device validation pending.

## Adventure foundation status

This release adds a pure-C# adventure chapter and an independent AppCore assembly. The logical chapter supports three locations, gated navigation, inventory collection, tool assembly and consumption, contextual objectives, stale-command rejection and transactional publication through IAdventureStore.

The new chapter is verified through automated tests. It is not yet connected to Unity scenes or a production adventure save adapter. The playable Unity prototype remains the v4.14 puzzle experience. Do not interpret this archive as a finished Lost Lands-style game. Existing puzzle saves and gameplay are retained.

See Design/ADVENTURE_DIRECTION.md for the landscape 3D direction, ownership boundaries and remaining integration work.

## Existing prototype play sequence

1. Solve the room's compartment puzzle.
2. Select INSPECT. Rotate the artifact to expose a seal.
3. Use FOCUS - / FOCUS + to match the displayed focus target, then SCAN.
4. After scanning three seals, select CLAIM to open the energy circuit.
5. Rotate the illuminated pipe cells to connect the west inlet of cell 1 to the east outlet of cell 9. HINT, UNDO and RESET are available inside the circuit.
6. Close the solved circuit and select CLAIM. The existing durable reward transaction commits the artifact and unlocks the next room.

Focus uses three discrete magnifications (100/125/150 percent), not free orbit or continuous pinch zoom. The current perspective task uses actual seal visibility and camera zoom; arbitrary camera-position alignment puzzles remain future work.

Circuit progress and optical inspection are session-local. Closing the circuit panel preserves its progress, but restarting the game restarts unclaimed inspection/circuit progress. Claimed rewards and room progress continue to use the existing save journal. No new save schema is introduced.

## New systems

- Linked pairs and destination-specific keys are active in rooms 6, 9 and 12 (content version 2).
- RULES, HINT, Prepare/Commit, reset and save validation share the same Domain rules.
- Content versions 0 and 1 retain their original definitions; old saves are not silently migrated.
- Safe-area HUD layout supports portrait and landscape. Board and inspection cameras reserve a separate central viewport.
- Board framing fits all eight world-bounds corners. Input outside the board viewport is rejected.
- Editor bootstrap wires camera, canvas scaler and safe-area root automatically.
- Existing scenes from older releases require the new layout component; use this archive as a fresh project so bootstrap generates the current scene.

## Open and play

1. Extract the archive to a new folder.
2. In Unity Hub, add the folder containing `Assets`, `Packages`, and `ProjectSettings`.
3. Open in Unity 2022.3.62f3. Wait for package resolution and script compilation. The first clean interactive import generates, validates, and opens `Assets/_Project/Scenes/Main.unity`. It also enables Main in Build Settings.
4. Press Play. Drag a piece onto a drawer, or click a piece and then click a drawer. Use RULES and HINT to inspect puzzle constraints. Solve the room, scan three artifact seals, claim the artifact, and select NEXT.
5. Run **TheOrderRoom > Validate Project & Scene**, then run the EditMode suite from **Window > General > Test Runner**.

If another Editor has this project open, close that instance before opening it again. To diagnose a failed startup, collect `%LOCALAPPDATA%\\Unity\\Editor\\Editor.log` and `%LOCALAPPDATA%\\Unity\\Editor\\upm.log`.

## Batch scene validation on Windows

With the project closed in Unity and PowerShell at the project root:

```powershell
$editor = Join-Path $env:ProgramFiles 'Unity\Hub\Editor\2022.3.62f3\Editor\Unity.exe'
$project = (Get-Location).Path
$log = Join-Path $project 'UnitySceneValidation.log'
if (-not (Test-Path -LiteralPath $editor -PathType Leaf)) {
    throw "Unity Editor was not found at $editor. Set the editor path to the installed 2022.3.62f3 Editor."
}
$unityArguments = @(
    '-batchmode', '-quit',
    '-projectPath', ('"{0}"' -f $project),
    '-executeMethod', 'TheOrderRoom.Editor.OrderProjectBootstrap.BuildAndValidateBatch',
    '-logFile', ('"{0}"' -f $log)
)
$unityProcess = Start-Process -FilePath $editor -ArgumentList $unityArguments -Wait -PassThru
$validated = (Test-Path -LiteralPath $log -PathType Leaf) -and
    (Select-String -Quiet -LiteralPath $log -Pattern 'THEORDERROOM_MAIN_SCENE_VALIDATED')
if ($unityProcess.ExitCode -ne 0 -or -not $validated) {
    throw "Scene validation failed. Read $log."
}
```

The scene generator validates required components, serialized references, and button bindings before saving a new scene. Existing Main scenes are validated instead of overwritten. The startup path leaves unrelated scenes and their build order intact.

## v4.15 changes

- Read the correct uGUI assembly name, `UnityEngine.UI`, in the runtime, editor and EditMode assemblies. The Package Manager dependency remains `com.unity.ugui`.
- Mouse and touch share the same world gesture flow. The view follows a dragged piece. The accepted drop uses the same rules, revision checks and persistence path as click-to-place.
- Releasing over UI or outside the board cancels the gesture. Multitouch, focus loss and a changed board also cancel it. Drop target checks visit up to the number of active destination colliders and allocate no result array.
- Main scene setup supports interactive first import and explicit batch validation.
- The original campaign, save schema, and historical save identifiers are preserved. Free artifact rotation and zoom are outside this candidate.

## Verification

C# syntax, manifest JSON, assembly reference layout, asset metadata, and ZIP integrity were checked for v4.15. Historical portable test XML in `Verification/TestResults` belongs to earlier source. The Unity Editor, Unity EditMode and PlayMode tests, and an Android device were unavailable for v4.15. Main is generated by Unity on the first import and is not pre-serialized in this ZIP.

Before an Android release, validate mouse and touch drops, UI overlap, rejected moves, Undo/Redo, and pause/resume. Build using Unity 2022.3.62f3 with Android Build Support, SDK, NDK and OpenJDK installed, then test installation and save recovery on a physical device.
