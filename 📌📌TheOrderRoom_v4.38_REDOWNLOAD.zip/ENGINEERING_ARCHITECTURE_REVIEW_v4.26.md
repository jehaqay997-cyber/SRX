# TheOrderRoom v4.26 — File Architecture and Scene Wiring Review

## Source baseline
v4.25 is preserved as the baseline. Two editor source files were modified: `OrderSceneValidator.cs` and `OrderProjectBootstrap.cs`. A new static governance script and its machine-readable results were added.

## Confirmed failure mode
The previous scene validator checked only whether a callback method appeared somewhere in the scene. Swapping the callbacks on two buttons, disabling a listener, or duplicating a listener could pass this check. The new validator requires exactly one persistent listener for every named button, verifies the exact owning OrderGame and callback name, and rejects inactive buttons. The scene generator now rejects unrecognized callback identifiers instead of silently producing an inert button.

## Architecture governance
`Verification/architecture_gate_v426.py` inventories every C# file by owning assembly, validates assembly dependency edges, detects cycles and undefined internal assembly names, checks pure-layer Unity isolation, and cross-checks generated button callbacks with the validator contract. The source ownership report is `Verification/ARCHITECTURE_REPORT_v4.26.json`.

## Boundaries and limitations
A source-level dependency scan is not a C# compiler. It does not verify that serialized Unity object instances or runtime UI buttons exist until the editor generates and validates the scene. This project remains configured for Unity 2022.3.62f3. Required release checks: Unity batch-mode compile, scene creation and validation, EditMode/PlayMode tests, and actual Android frame-time/memory/battery profiling.

## Further architecture risks
1. `OrderGame` remains a broad MonoBehaviour with multiple responsibilities and needs staged separation into presentation/controller services, keeping domain rules pure.
2. AppCore and Infrastructure adventure capabilities are not yet connected end-to-end to the player-facing scene. Do not claim the new adventure mode is integrated.
3. Button names are still string IDs at the editor boundary. Future work should generate the scene and its validation expectations from one typed binding catalog; this release adds bidirectional fail-closed validation without attempting a high-risk scene rewrite.
4. Persisted saves must undergo Unity execution and fault-injection testing. Static hashing is not authentication of player saves.

## Release state
`SOURCE_GOVERNANCE`: check machine-readable results. `COMPILE_VERIFIED`: NO. `TEST_VERIFIED`: NO. `DEVICE_VERIFIED`: NO.
