# TheOrderRoom v4.35 — Release Source Governance Candidate

## Scope and evidence

This revision is based on the existing v4.34 ZIP. It makes focused corrections in the Unity verification workflow and in runtime scene validation without rewriting the game's already-reviewed transactional rules. All changes are explicitly classified as either authored source changes, new tooling, or regenerated static reports.

**Important:** Static verification is not evidence that the project compiles in the Unity Editor, that NUnit test cases execute under Unity, or that Android performance and power consumption are acceptable. This candidate is NOT RELEASE VERIFIED.

## Proven defects corrected

1. `Verification/Run-UnityVerification.ps1` used `-accept-apiupdate` for both Unity invocations, allowing the verification procedure to automatically rewrite authored C# while attempting to verify it. This option has been removed. A SHA-256 source baseline is now computed before import and verified after the scene bootstrap and EditMode test run. All existing C# files, assembly definitions, Unity metadata outside the generated scene directory, and the package manifest and editor version are covered. Generated `Assets/_Project/Scenes` files are excluded because scene generation is part of the defined bootstrap action.
2. `Assets/_Project/Editor/OrderSceneValidator.cs` previously counted EventSystem, Canvas, pointer source, energy governor and audio feedback components without comprehensively enforcing that each essential component was active and enabled. The validator now rejects inactive or disabled instances. The existing one-instance and identity checks remain in place.
3. The Unity verification runner checked only a narrowly anchored compiler-error pattern in the bootstrap log. The pattern now catches common `error CS####` and compilation-failure text anywhere on the log line.

## Architecture decision: preserve intentional ticket invalidation

`OrderBoard.PrepareCore` clears previously issued tickets on every attempted Prepare, even if the new attempt fails. `DomainQualityTests.FailedSecondPrepareInvalidatesPreviouslyIssuedCapability` explicitly enforces this as the current single-outstanding-capability contract. Changing it would be a breaking semantics change to a security-sensitive flow. This revision intentionally **does not** alter that behavior. The potential usability trade-off is recorded but cannot be called an undocumented bug without revising its contract and all dependent tests.

## New mandatory static governance

`Verification/release_source_gate_v435.py` enforces exact reviewed assembly inventories and reference sets, prevents engine dependencies in Domain/AppCore/Infrastructure, detects cycles or duplicate assembly references, rejects missing/duplicate/orphaned Unity GUID/meta files, rejects unpinned or local-path package dependencies, and confirms verification-runner and scene-activation contracts. The tool reports only `STATIC_PASS_ONLY`, never a fabricated compilation or device result.

`Verification/test_release_source_gate_v435.py` contains mutation-oriented tests for dependency cycles, duplicate references, duplicate GUIDs, missing metadata, unpinned packages, automatic source rewriting, and removed scene activation checks.

`Verification/run_static_audit_v435.py` executes twelve static gates and the entire current Python unittest discovery suite, producing `Verification/AUDIT_EVIDENCE_v4.35.json`.

## Actual audit results

- Static gates: **12/12 returned exit code zero**.
- Python unittest suite: **37 passed**.
- Editor version in the actual project: **Unity 2022.3.62f3**. No silent editor version migration was performed.
- Assembly definitions: **6**. Source C# files: **100**. Unique Unity GUIDs: **137**. Missing Unity meta files: **0**.
- Unity compilation: **not executed**; no Unity editor binary is available in this environment.
- NUnit inside Unity: **not executed**; the tests included in the source are not proof of execution.
- Android smoke test, memory profiling, battery or thermal measurement: **not executed**.
- `OrderGame` remains relatively monolithic. AppCore and Infrastructure still require a runtime integration review; offline assembly-reference compliance alone does not prove functional integration.

## Actual Unity verification command (Windows PowerShell)

```powershell
& ".\Verification\Run-UnityVerification.ps1" -ProjectPath "."
```

The runner uses `ProjectSettings/ProjectVersion.txt` for its default editor location, produces `Verification/LocalResults/verification.json` and EditMode XML results, and fails when scene validation, tests, or source integrity fails.

## Release gates

`DESIGN_STATIC: PASS` (scope limited to checked source contracts)

`UNITY_COMPILE: NOT VERIFIED`

`EDITMODE_TESTS: NOT VERIFIED`

`PLAYMODE_TESTS: NOT VERIFIED`

`ANDROID_BUILD_AND_DEVICE: NOT VERIFIED`

`PERSISTENCE_CRASH_RECOVERY_ON_DEVICE: NOT VERIFIED`

`PERFORMANCE_MEMORY_THERMAL: NOT VERIFIED`

The final release designation must remain blocked until all mandatory runtime gates have real logs and reproducible device evidence.
