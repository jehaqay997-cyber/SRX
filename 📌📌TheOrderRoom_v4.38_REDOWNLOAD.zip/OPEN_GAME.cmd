@echo off
setlocal
set "TOR_EDITOR=%ProgramFiles%\Unity\Hub\Editor\2022.3.62f3\Editor\Unity.exe"
if not "%~1"=="" set "TOR_EDITOR=%~1"
if not exist "%~dp0ProjectSettings\ProjectVersion.txt" (
  echo Extract the complete archive before opening the game.
  pause
  exit /b 1
)
if not exist "%TOR_EDITOR%" (
  echo Unity 2022.3.62f3 was not found at the default installation path.
  echo Open this project folder from Unity Hub with Unity 2022.3.62f3.
  echo Alternatively, drag the correct Unity.exe onto this script.
  pause
  exit /b 2
)
start "TheOrderRoom" "%TOR_EDITOR%" -projectPath "%~dp0."
endlocal
