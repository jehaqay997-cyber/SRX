# TheOrderRoom v4.24 — Evidence-Based Hardening

## Scope and evidence

Starting source: v4.23. Only the two documented production source files were changed. Existing assets, scenes, and tests are preserved byte-for-byte otherwise. Four new NUnit tests were added but **not executed**.

## Confirmed architectural risks and fixes

1. `AdventureJournalStore.TryReadRecord` performed a file length check and then re-opened the file with `File.ReadAllBytes`. Under concurrent external modification, memory could be allocated based on a changed file size. A single file handle and fixed 56-byte read buffer now enforce exact-length reads. Journal checks still fail closed.
2. `AdventureJournalStore.TryReadLocked` materialized a full directory listing before enforcing the 10,000-record quota. Now file enumeration stops once the limit is exceeded, bounding the listing's memory use.
3. `OrderPerformanceGovernor` previously disabled VSync only on mobile. Unity desktop behavior gives `vSyncCount` precedence over `targetFrameRate`, leaving its frame-governance promise ineffective under common quality settings. The governor now disables VSync while active and restores the prior value on disable. Multiple concurrent governors must remain prohibited by scene validation.

## Residual high-priority limitations

- No Unity executable or .NET compiler in the analysis environment. Compilation, NUnit, PlayMode, Android, memory and battery performance **not verified**.
- The adventure append-only store re-verifies the full journal on each read and commit: O(N) per operation and O(N^2) cumulative for N commits. Retention/compaction requires a separate, atomic, crash-safe design with independent proof before implementation.
- SHA-256 detects accidental corruption but is not tamper authentication. On-device embedded secrets cannot guarantee resistance against motivated attackers.
- Project's source editor version remains 2022.3.62f3; editor migration to Unity 6.3.28f1 not attempted.
- World scene and mobile performance must be exercised in a real Player; static inspections do not certify the UI/camera/audio experience.

## Test evidence

Run `Verification/Run-UnityVerification.ps1` in the matching Unity environment to build the scene and run EditMode NUnit. The test runner must produce XML with `failed=0` before test verification can change from unverified.
