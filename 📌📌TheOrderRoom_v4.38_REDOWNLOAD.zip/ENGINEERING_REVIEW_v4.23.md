# TheOrderRoom v4.23 — Verified-source governance and automated Unity gate

## Scope
This release preserves all source content from v4.22 and adds a fail-closed Windows Unity verification workflow, a separate static governance check, and an evidence report. **No Unity compilation or NUnit test was executed in this environment.** The project version is still 2022.3.62f3; no editor upgrade was attempted.

## Run with no manual scene assembly
From PowerShell on a Windows machine with the exact Unity editor installed, execute:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1
```

The script locates the exact required Unity version, runs `TheOrderRoom.Editor.OrderProjectBootstrap.BuildAndValidateBatch` to construct and validate `Assets/_Project/Scenes/Main.unity`, runs all EditMode tests, and records test results, logs, and `Verification/LocalResults/verification.json` without asking the operator to connect scene objects.

If Unity is installed at a non-default location, supply `-UnityEditorPath` with the installed Unity executable. The exact version requirement is fail-closed.

**Do not open this project in the Unity Editor concurrently with the batch script.** Unity cannot safely open the same project twice.

### Verification gate semantics
- `STATIC_PASS_ONLY`: metadata, GUIDs, basic dependency boundaries, and JSON layout inspected; does not prove C# compilation.
- `bootstrap=PASS`: editor built and validated the actual scene.
- `editmode=PASS`: a nonempty NUnit XML result reports no failures and Unity exits successfully.
- Device performance, audio output, battery drain and memory leaks require player/device instrumentation and remain `NOT_VERIFIED`.

### Highest-priority follow-on improvements
1. Execute the automated Unity gate and preserve logs; resolve actual C# compilation/Unity package failures before expanding product features.
2. Integrate `AdventureJournalStore` with runtime gameplay using its authoritative state, with independent shutdown and power-failure tests.
3. Replace full historical journal replay on every commit with a proven checkpoint/compaction protocol before long campaigns. Current journal validation scales with the history length and caps at 10,000 entries; changing this naively could compromise correctness.
4. Capture on-device CPU, GPU, Memory Profiler and battery measurements across a continuous 20-minute gameplay run and after 20 pause/resume cycles; report baseline and deltas, not unverifiable leak-free claims.
5. Verify UI touch target sizes and accessibility at 16:9, 19.5:9 and 21:9 with real safe-area cutouts.

## Official references
- Unity 2022.3 Editor CLI: https://docs.unity3d.com/cn/2022.3/Manual/EditorCommandLineArguments.html
- Unity profiling: https://docs.unity3d.com/2022.2/Documentation/Manual/profiler-profiling-applications.html
- OWASP input validation: https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html
- .NET File.Move semantics: https://learn.microsoft.com/en-us/dotnet/api/system.io.file.move

## Change governance
Original v4.22 project files are not overwritten. The new automation requires PowerShell and the exact Unity editor installed locally; it does not bypass missing build dependencies. The results of an absent test execution are never marked green.
