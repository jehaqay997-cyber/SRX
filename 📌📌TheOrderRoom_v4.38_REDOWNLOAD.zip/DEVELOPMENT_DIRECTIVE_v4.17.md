# TheOrderRoom v4.17 - Development Directive

## Source preservation
All v4.16 source files are retained; only the portable test project has one new test inclusion. Added files are listed in `CHANGESET_v4.17.json`.

## Delivered now
- Production `AdventureSolvabilityVerifier` enumerates all reachable finite adventure state identities using `AdventureChapter` rules, and reverse-searches for victory reachability.
- Two EditMode tests enforce reachability and deterministic verifier output.
- Python independent reference enumeration results are in `Verification/ADVENTURE_REFERENCE_MODEL.json`.
- No gameplay content, saves, or scene assets were overwritten.

## Important limitation
This proof covers the existing three-location `AdventureChapter` mechanics only. It does not prove the entire game, any hidden-object scenes, or persisted states are free from softlocks. Large future state graphs require bounded/exhaustive semantics and separate storage correctness checks.

## Next release gates
1. Build the current actual Unity project and run EditMode tests. Do not mark a success without logs.
2. Resolve the Unity editor version decision against installed editors and package compatibility; source currently targets 2022.3.62f3.
3. Implement actual adventure persistence adapter and restart-in-the-middle fault tests.
4. Integrate the fixed-camera landscape vertical slice and touch UI.
5. Add knowledge-graph semantics and prove authored chapter reachability.

## Verification
Independent Python model was executed here. No Unity editor or .NET compiler execution was available in this container, so compile/test/device gates remain unverified.
