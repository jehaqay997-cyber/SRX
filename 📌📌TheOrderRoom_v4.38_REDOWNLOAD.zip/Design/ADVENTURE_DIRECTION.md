# TheOrderRoom adventure direction

Status: approved product direction; implementation is incremental.
Target presentation: landscape, actual 3D environments, first-person point-and-click adventure.
Reference experience: Lost Lands-style location exploration, inventory use, contextual puzzles, clues, journal and map; original world, narrative, assets and puzzle arrangements.

## Experience contract

Explore a location, observe a clue, collect or combine a tool, solve an environmental mechanism, and visibly change the world. A puzzle must have an in-world purpose. Do not repeat sorting, seals and energy in the same order in every room.

Camera modes: location overview, point-of-interest approach, mechanism interaction, item inspection, return to overview. Preserve the return pose. Only one mode owns pointer input at a time; modal UI consumes input. No camera movement during atomic placement commits.

Landscape HUD: compact inventory at the bottom, map/journal/hint controls at edges, central scene unobstructed. Item selection must be explicit; invalid use gives contextual feedback without consuming the item.

## Ownership

| Layer | Responsibility | State of implementation |
| --- | --- | --- |
| Domain | Board invariants, puzzle rules, immutable adventure snapshots, chapter transitions | Existing puzzle logic plus new adventure core |
| AppCore | Commands, expected revisions, transactional persistence boundary | New independent assembly and AdventureSession |
| Infrastructure | Production adventure store, migration, immutable journal, assets | Adventure adapter pending; existing game save store remains |
| Input | Touch/mouse routing and cancellation | Existing Runtime code; dedicated assembly pending |
| Presentation | Location scenes, hotspots, inventory, camera modes, journal | Adventure presentation pending; current puzzle UI retained |
| Root | Explicit service wiring and validated scene construction | Existing editor bootstrap; adventure composition pending |

AdventureSession owns the current immutable adventure snapshot. It publishes a candidate only after the store confirms a complete commit. Unknown outcomes and conflicts block further commands until a new session is created from authoritative storage. IAdventureStore implementations must compare revisions atomically. No in-memory store is presented as production persistence.

OrderBoard remains the sole owner of compartment state. Adventure transitions must not mutate its internal collections. The existing circuit owns its own subpuzzle state. A future world transaction must persist puzzle completion and its world effect together, with an idempotent reward identifier. That adapter is not implemented here.

## First chapter

Courtyard: collect brass key and unlock inner grounds.
Archive: find lens and lens mount; combine them into one mounted lens.
Observatory: install the lens, consuming it and exposing the next mechanism.
Return paths remain available. Duplicate collection, repeated consumption, locked travel and stale commands are rejected. The three locations are logical definitions, not finished 3D scenes.

Next integration: bind observatory illumination to an original spatial puzzle, route its result into an environmental power mechanism, and make the world change visible. Reuse existing puzzle rules behind these interactions.

## Release gates

- Design: all required objects have identities, prerequisites, effects and clues; every mandatory path has an executable witness.
- Compile: target Unity imports and compiles the full source without Safe Mode.
- Test: invalid actions do not mutate state; future saves are untouched; save failures do not grant tools or rewards; reload restores the complete world and puzzle state.
- Device: landscape Android touch, safe areas, focus loss, back navigation, relaunch and representative-device profiling pass.
- Visual: hotspots are discoverable, interactive items remain readable, camera transitions are stable, and mechanisms communicate their state through shape/text as well as color.
- Playtest: new players can infer the first objective, understand tool use and finish the chapter with graded hints. Numerical success targets must be established before the session; none are claimed here.

## Explicit gaps

This package does not contain finished Lost Lands-style environments, cinematic narrative, hidden-object scenes, production adventure persistence, a complete inventory UI or integrated map/journal. It is not a visual replacement for the existing prototype. Existing partial artifact/circuit progress is still session-local. No Unity or Android execution is claimed.
