# TheOrderRoom v4.21 Engineering Delivery

Baseline: v4.20. Existing source retained except bounded, traceable changes.

## Root-cause fixes and added integrations
- OrderScreenLayout previously ran OnEnable before Configure on an active GameObject, leaving `configured=false` forever. Configure now captures camera state and updates the layout on subsequent LateUpdate; OnDisable restores camera state.
- Added pure `FrameBudgetPolicy` and scene-bound `OrderPerformanceGovernor`. Mobile defaults to 30fps, desktop to 60fps; sustained missed budgets and known discharging battery <=15% can lower to 24fps. These are *heuristics*, not measured power savings. Target/VSYNC settings are restored on disable.
- Original PCM feedback tones synthesize once at Awake; three clips and one AudioSource are cached and destroyed with the component; no frame-based AudioSource creation or clip allocations. Feedback wired to successful moves, rejected moves, and collection reveal.
- Auto-scene generation now wires an audio component, frame governor, stable camera layout and two shadow-free lights. Validates one governor, one feedback, one AudioListener and an assigned feedback field. Existing Unity scenes are not overwritten.
- Added four policy NUnit tests.

## Residual P0/P1 issues
- P0 Unity C# compilation and NUnit execution not performed in this environment. Do not mark verified.
- P0 Device battery drain, thermal throttling, GPU profiling, audio latency and 16:9-21:9 touch reachability need actual device measurement.
- P1 Existing Main.unity may not contain the new components; project validator deliberately fails rather than silently rebuilding a user's modified scene. New projects can bootstrap automatically.
- P1 AdventureJournalStore is still not integrated into the active board gameplay; its compatibility and persistence require additional testing.
- P1 Android build target and Unity 6.3.28f1 migration are unverified. Source editor version remains 2022.3.62f3.
- P1 Procedural sound is original and basic, not final sound design or accessibility audio alternative.

## Reproduction
- Python: `python Verification/verify_v4_21.py`
- Unity: open in the editor version declared by ProjectSettings/ProjectVersion.txt; allow reimport. Use TheOrderRoom/Validate Project & Scene.
- Unity batch: `Unity -batchmode -nographics -quit -projectPath <path> -executeMethod TheOrderRoom.Editor.OrderProjectBootstrap.BuildAndValidateBatch -logFile <path>`
- Run EditMode NUnit before trusting device output.
