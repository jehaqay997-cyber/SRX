# Engineering Audit v2.9 — Recovery Hardening

Source baseline: v2.8 candidate. This package is an overlay, not a complete Unity project.

## Changed code
- Runtime/OrderGame.cs: public LoadLevel now saves a candidate before publishing navigation; initial boot remains in-memory only. Guards prevent navigation while inspection/commit is active.
- Runtime/OrderGame.cs: input ignores multitouch gestures and allows at most one world dispatch per touch gesture in both legacy and new Input System branches. UI raycast remains the consumption gate.
- Runtime/OrderSaveStore.cs: pruning exceptions after successful File.Move no longer misreport a committed save as a failure.

## Known limitations
- Unity compile, EditMode, PlayMode and mobile profiling are NOT EXECUTED.
- Save journal is process-local synchronized; concurrent external writers are not supported.
- Existing valid saves are not guaranteed to be semantically compatible with every future content revision.
- New Input System touch slots may briefly retain released contacts; verify gesture reset on device.
- A successful file move is not a proven power-loss durability guarantee.
- UI world-input ownership is improved, not a full pointer capture implementation.
- No new puzzle or narrative content is added.

## Manual acceptance tests
1. Navigate to an unlocked room; restart; assert same room is restored.
2. Force save failure during LoadLevel; assert level and board remain unchanged.
3. Perform two-finger gestures; assert no world selection/movement.
4. Press UI then move finger over world; assert no world interaction.
5. Simulate prune failure after commit; assert save returns success and next load sees committed generation.
6. Run Unity 6.3.28f1 compilation and EditMode/PlayMode tests.

Status: SOURCE_PATCHED / ARCHIVE_VERIFIED / UNITY_UNVERIFIED / NOT_RELEASE_READY.
