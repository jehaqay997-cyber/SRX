# TheOrderRoom v2.2 — Source-level remediation

## Changes
- Reject mismatched generation filename/payload; filter generation filenames to canonical numeric forms.
- Continue saving past corrupt legacy/journal files when a valid generation exists; never delete unreadable files. Future schemas block writes.
- Reject all-invalid existing save sets; guard cleanup with two independently readable newer generations.
- Stage complete saved session (board and artifact ledger) before publishing progress.
- Save target level before changing active scene level.
- Replace quadratic per-item slot counting with a per-destination counter.
- Add camera visibility helper for seals; not yet wired to ScanArtifact because the scene camera/inspection camera setup requires Unity verification.

## Remaining risks
- The save system still uses Unity JsonUtility and local checksum (not tamper proof).
- Cross-process writes are not locked. Crash durability requires real device testing.
- The inspection visibility helper is not an authoritative scan gate; camera rig and raycast layers need integration in Unity.
- A recovered corrupted file is retained; no automatic quarantine or repair.
- No Unity compilation or NUnit execution in this environment.
- This is an overlay, not a complete Unity project.
