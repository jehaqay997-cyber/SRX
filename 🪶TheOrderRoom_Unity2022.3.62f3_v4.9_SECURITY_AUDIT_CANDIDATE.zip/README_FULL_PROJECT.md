# TheOrderRoom v4.9 - puzzle systems and security-review candidate

Unity Editor target: **2022.3.62f3**.

Puzzle systems and campaign content are the v4.8 baseline. This v4.9 package adds a dated external security review and a repeatable static attack-surface scan; it does not claim Unity Editor or Android security certification.

## Open in Unity

1. Extract the complete archive into a new directory.
2. Unity Hub > Add project from disk > choose the folder containing Assets, Packages and ProjectSettings.
3. Open using 2022.3.62f3 and allow package resolution/script compilation.
4. On a clean interactive first import, Main.unity is generated and wired automatically. Press Play.
5. Run TheOrderRoom > Validate Project & Scene, then Window > General > Test Runner > EditMode.

Existing or modified scenes are not overwritten. If Main cannot be generated because an existing scene is dirty, save/close that scene and use TheOrderRoom > Create Integrated Scene (Non-Destructive). A new extraction is recommended because older generated scenes lack the new rules/label/button bindings.

## Play

Tap an item, then tap a matching drawer. Read item IDs/weights and drawer count/weight quotas. RULES displays all current restrictions. HINT gives one legal suggestion without changing the board. After solving, INSPECT, rotate, SCAN three visible seals and CLAIM the artifact to save the reward, reveal the next story fragment and unlock the next room.

The 12 stages now use weight quotas, separated pairs, first-key dependencies and intermediate count balance. Later gates accept valid alternative arrangements. Continuous drag/drop and free rotation/zoom are not implemented by this patch.

## Save compatibility

- Historical saves: schemaVersion=1 / contentVersion=0, original campaign definitions.
- New games: schemaVersion=2 / contentVersion=1, new campaign definitions.
- Loading an old campaign preserves its rules; it is not silently converted to the new puzzles.
- Unknown future save/content versions block recovery and writes.
- No existing save reset or destructive migration is performed. The historical filename prefix is retained.

## Evidence

- 153 actual pure C# tests passed; 56 persistence tests passed with a portable JSON adapter.
- Pure source compiled for .NET Standard 2.1 and ran on .NET 8. Engine/editor assemblies were not compiled here.
- Unity JsonUtility, physics, scene generation, UI and Android remain UNVERIFIED.
- See ENGINEERING_AUDIT_v4.8.md for exact scope and open blockers, PUZZLE_DESIGN_v4.8.md for laws/story, and Verification for raw NUnit XML, source hashes and executed legal solution paths.
- Earlier audit documents are historical, not current runtime proof.
- `SECURITY_REVIEW_2026-11-09.md` records current official Unity security advisories and this project's static attack-surface scan. Engine, Package Manager, Android OpenJDK and device behavior remain outside host-test evidence.

## Reproduce portable checks

Install a .NET 8 SDK. From the project root:

```bash
dotnet run --project Verification/Portable/Portable.Tests.csproj -- --workers=0 --result=pure-results.xml
dotnet run --project Verification/Portable/Portable.Persistence.Tests.csproj -- --workers=0 --result=persistence-results.xml
dotnet run --project Verification/Portable/Portable.CampaignExport.csproj -- campaign-paths.json
python3 Verification/Portable/security_surface_scan.py
```

The persistence adapter is outside Assets. It deliberately substitutes System.Text.Json for Unity's serializer; its results are not Unity engine verification. The generated project contains no Unity cache, fabricated Main scene or compiled binaries.
