# v3.3 Journal Root Safety — candidate

## Confirmed source defect
v3.2 computed `removable = files.Count - RetainedGenerations` across **all** journal filenames, but skipped invalid files when deleting. This could prune valid recovery generations even when fewer than eight valid generations remained.

## Changes
- Retention now counts **verified valid** generations only.
- Invalid generation files are never deleted automatically.
- Save operations fail closed when more than 32 invalid journal generations exist; manual recovery is required. This is a bounded-count guard, **not** a total-byte storage quota.
- Added EditMode NUnit tests for retention arithmetic and invalid-generation budget.
- Preserved schema v1 and existing GUIDs. New test has its own GUID.

## Remaining risks
- This does not protect against multiple independent processes writing simultaneously.
- Malformed filenames outside the canonical journal pattern are not counted in the quota.
- Storage can still grow through files not managed by this journal.
- Filesystem durability on sudden power loss is unverified.
- Unity compilation and EditMode execution were not performed.

Status: SOURCE_PATCHED / ARCHIVE_VERIFIED / UNITY_UNVERIFIED / NOT_RELEASE_READY.
