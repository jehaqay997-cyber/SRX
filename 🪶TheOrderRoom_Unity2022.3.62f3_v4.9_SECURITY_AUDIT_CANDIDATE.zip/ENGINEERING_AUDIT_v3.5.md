# TheOrderRoom v3.5 — Recovery Authority Audit

## Confirmed root cause
`TryLoadCore` previously selected the largest `generation` across both immutable journal entries and legacy mutable root/backup/previous files. A legacy file containing a larger generation could supersede the newest valid journal, violating the append-only journal's authority model.

## Patch
- Explicit recovery precedence: valid journal > valid legacy, regardless of generation number; within each class select the largest generation.
- Scan all candidates even after selecting a journal; future schema remains a hard failure.
- Bound diagnostic string growth during enumeration.
- Catch UnauthorizedAccessException during temporary-file cleanup so cleanup cannot turn an otherwise successful save into a reported failure.
- Add 6 EditMode test methods covering precedence decisions.

## Scope and limitations
- This is a targeted source patch, not a full architectural certification.
- Legacy files remain supported when no valid journal exists.
- SHA-256 is an accidental corruption check, not authentication.
- No Unity Editor, Unity Test Runner, Android/iOS device, or crash-injection harness was executed.
- Existing risks: generation file accumulation, save filesystem durability, untrusted external writers, UI pointer ownership, and scene lifecycle.
- The archive is an Assets overlay, not a full Unity project.

## Verification gates
- Static source and ZIP integrity: run by packaging script.
- Unity C# compilation: UNVERIFIED.
- EditMode and PlayMode execution: NOT EXECUTED.
- On-device persistence/crash tests: NOT EXECUTED.
