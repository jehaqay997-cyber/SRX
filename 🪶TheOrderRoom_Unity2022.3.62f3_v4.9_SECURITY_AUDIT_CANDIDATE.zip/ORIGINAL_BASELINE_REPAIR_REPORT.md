# Original v3.8 Source — Targeted Repair Integration

Baseline: TheOrderRoom_v3.8_Full.zip (Unity 6000.3.28f1). Original Unity version, editor scripts, asmdefs and all unrelated files are preserved.

## Integrated source changes
- OrderBoard.cs: derived capacity/weight indexes, transaction and restore consistency guards.
- OrderSaveStore.cs: journal uncertainty handling and test-only fault checkpoints.
- OrderGame.cs: redo history and save-before-commit workflow.
- CollectionMilestones.cs, LevelSolvability.cs, PuzzleMath.cs: targeted mathematical hardening.
- SaveTestAssemblyAccess.cs: friend access for EditMode fault tests.
- BoardIndexRegressionTests.cs, BoardTransactionalRegressionTests.cs, MathematicalHardeningTests.cs, SaveFaultInjectionTests.cs: NUnit regression and fault-injection tests.

## Validation actually performed
- Original files outside the six replacements are byte-for-byte preserved except five new test/runtime files and metadata.
- ZIP CRC verification, GUID uniqueness and source .meta completeness checks.
- No Unity compilation, NUnit execution, Android IL2CPP build or device testing was performed; these remain mandatory release gates.
- Fault injection is implemented as isolated test hooks, not a real power-loss test.

## Important
This is a repaired candidate based on the original Unity 6 v3.8 baseline, NOT the Unity 2022 compatibility branch. No claim of production readiness or guaranteed fault-free behavior.
