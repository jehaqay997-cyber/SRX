# v1.9 Persistence hardening — static candidate

## P0: Removed non-atomic copy overwrite
The v1.8 fallback copied a replacement over the live save. A power loss during copy could truncate the primary. v1.9 uses File.Replace when a primary exists; if unsupported or failing, the save operation fails without a fallback copy. On first creation, File.Move is used after temp write and readback.

## P1: Input validation
Save locations must have unique, nonblank, bounded IDs and destinations; null entries are rejected before write and after load. This does not establish that the IDs are valid for the specific level; board Restore remains responsible for that.

## Residual risks
* File.Replace support and durability depend on target filesystem/platform; test on Android/iOS and actual devices.
* Existing recovery semantics can restore older backups; it does not guarantee latest-commit recovery.
* Save integrity SHA256 is not an authentication mechanism.
* Concurrent TrySave calls are not serialized; no interprocess lock or generation counter.
* The whole-game Unity compilation and tests have not been executed here.
* Existing Unity scenes are not rewritten.

## Verification gates
Run Unity EditMode tests; simulate I/O failures, corrupt/truncated primary, future-version primary, and backup recovery on each target platform. Confirm reward claim and unlock survive relaunch.
