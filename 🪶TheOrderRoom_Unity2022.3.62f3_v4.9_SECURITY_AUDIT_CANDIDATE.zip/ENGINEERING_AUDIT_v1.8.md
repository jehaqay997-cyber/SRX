# TheOrderRoom v1.8 — Root-Cause Review and Reward Consistency

## Source baseline
Based on actual v1.7 candidate archive. No Unity executable or C# compiler available in this environment. All previous GUID/meta retained; one new test GUID generated.

## P0 — reward persistence ordering (fixed)
Before: `TryClaim` deactivated inspection, ledger and unlock mutated, then `Persist()` might fail. This produced an unlocked in-memory session without a durable reward and made retry impossible.
After: stage a complete save containing the new artifact and unlocked level; require successful `OrderSaveStore.TrySave` before claiming or modifying the in-memory ledger. Failed save leaves inspection active and retryable. A process crash after successful save recovers the award from disk.

## P1 — inspection view reset (fixed)
Before: reopening the same level retained old rotation and hidden seal renderers while state restarted at zero. After: reset sculpture rotation and re-enable all seals when Show is called.

## P1 — runtime contract tests (added)
Two EditMode tests for inspection reset and exact-identity single-use claim. They are written, not executed in Unity.

## Remaining release blockers
- **Durability**: File.Replace is not guaranteed atomic across all Unity target filesystems. The fallback File.Copy(primary) is non-atomic; requires platform-specific durable storage design and fault-injection testing.
- **Save validation**: SHA-256 checksum detects accidental corruption, not malicious tampering. Client-side saves are not cryptographically authenticated. Recovery precedence and old-save migration require end-to-end tests.
- **Visual puzzle**: scan checks orientation only; it does not raycast/verify actual visibility of a seal. Current geometric seal positions can be occluded. Gameplay requires camera/occlusion verification in Unity.
- **View lifetime**: primitive and material destruction is deferred by Unity; actual PlayMode inspection required.
- **Architecture**: OrderGame remains a large MonoBehaviour and reward logic is not extracted into an application service. Avoid speculative refactor without compiler and integration tests.
- **Verification**: Unity compile, NUnit EditMode and PlayMode tests NOT EXECUTED. Candidate is NOT RELEASE READY.

## Complexity
- Reward staging: O(N + A) time and memory, N=board item count, A=discovered artifacts. Disk serialization bounded by save validation limits.
- View reset: O(1), exactly 3 seal renderers.

## Recommended Unity checks
1. Import candidate into a disposable copy of the Unity 6000.3.28f1 project preserving .meta.
2. Compile and run all EditMode tests; fix any failures from actual console output.
3. PlayMode: scan 3 faces, force persistentDataPath write failure, attempt CLAIM, confirm no reward/unlock and retry remains possible.
4. Restore write access, CLAIM, restart, verify reward and unlock restored.
5. Close and reopen inspection on the same level, verify seals and rotation reset.
