# TheOrderRoom v3.8 — Consolidated engineering candidate

## Scope
Complete standalone Unity project assembled from v3.7 source, with a gameplay-session compare-and-swap write path and regression tests. Earlier historical audits are retained as records, not current test proof.

## Root-cause fix: stale session writes
- v3.7 writer isolation serialized physical writes but permitted stale gameplay sessions to overwrite newer session state.
- v3.8 introduces `OrderSaveStore.TrySaveIfCurrent(document, expectedGeneration, out committedGeneration, out reason)`.
- Under the same cross-process writer lock, it checks the latest recoverable generation before appending.
- `OrderGame` tracks the generation it loaded/committed and rejects divergent writes; unrecoverable ambiguity disables its component pending scene reload.
- Existing `TrySave` remains for compatibility and tests; gameplay uses only the guarded method.
- Important limitation: save verification after rename can fail after a commit; failure is NOT proof of rollback. Some failure types still need reconciliation and actual device testing.

## Quality gates
- ZIP integrity and SHA256: verified by packaging script.
- Unity compilation / NUnit EditMode / PlayMode / device power-loss: NOT EXECUTED.
- Project is a candidate, not a verified release.

## Remaining risks
- Full persistence fault-injection suite and cross-process integration tests absent.
- A stale gameplay session that receives a generic I/O failure must reload before retrying if commit outcome is uncertain.
- OS-level FileShare.None semantics need validation on target Android/iOS/desktop filesystems.
- UI/camera performance and visual scene generation require Unity Editor validation.
- `OrderGame` remains a large presentation/application orchestrator; staged refactor is preferable after first compilation proof.
