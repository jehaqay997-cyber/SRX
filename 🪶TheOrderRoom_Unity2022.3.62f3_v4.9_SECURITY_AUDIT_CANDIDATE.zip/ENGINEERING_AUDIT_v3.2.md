# TheOrderRoom v3.2 — Journal Preservation Audit

## Confirmed source defect
`PruneOldGenerations` in v3.1 counted all generation filenames against retention, and could delete a corrupt/unsupported older generation once two newer valid generations existed. This destroyed forensic evidence without an explicit user recovery decision.

## Patch
- Never delete an invalid generation during automatic retention cleanup.
- Only prune validated generations with at least two newer independently validated generations.
- Add four EditMode tests for the pure retention decision.
- Preserve all prior file GUIDs; add a GUID only for the new test.

## Limits
- No Unity compilation, EditMode execution, device I/O fault injection, or power-loss durability verification was performed.
- File-based saves remain vulnerable to concurrent external writers; `SaveGate` is process-local.
- Invalid journal files can accumulate; manual recovery/cleanup tooling needs a separate reviewed design.
- This is a source overlay, not a complete Unity project.
