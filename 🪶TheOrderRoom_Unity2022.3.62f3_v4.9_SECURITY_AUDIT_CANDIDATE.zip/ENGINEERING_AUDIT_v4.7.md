# TheOrderRoom v4.7 - detailed static audit and corrective candidate

Target: Unity 2022.3.62f3.
Input: TheOrderRoom_Unity2022.3.62f3_v4.6_CANDIDATE.zip.
Release decision: NOT RELEASE VERIFIED.

## Confirmed findings and corrections

| Priority | Finding in v4.6 | Correction in v4.7 | Runtime evidence |
| --- | --- | --- | --- |
| P0 | Transfer identifiers were predictable per-board longs. Two boards could both issue token 1; passing one board's token to the other could commit its unrelated pending move. | Use board-stored Guid tickets; reject absent, foreign and consumed tickets. Update all callers and add a cross-board regression. UUID collision resistance is probabilistic; no client-side anti-cheat guarantee is claimed. | Regression included, not executed. |
| P1 | Prepare(null, ...) and Prepare(..., null) could throw through Dictionary calls; Restore could do the same for null destinations. | Reject blank identifiers and null destinations through ordinary failure returns. | Six parameterized transfer cases and an atomic restore regression included. |
| P1 | Board revisions were int despite the agreed long revision boundary. | Change board/proposal/expected revisions to long, preserve exhaustion guards, update tests. | Exhaustion regression included. |
| P1 | Solver explored-node counter could overflow if the caller supplied int.MaxValue as its budget. | Use a long explored counter for the int budget. | Syntax/static check only; exhaustive extreme-budget execution not performed. |
| P1 | Invalid TrySave documents created the storage directory and opened/created the writer lock before validation. Several existing invalid-save tests could touch the real application storage directory. | Validate before storage access in both write APIs and retain validation inside the commit core. | No-directory/no-lock regression included. |
| P1 | A view exception after durable board publication could leave input active against a partial scene. | Catch refresh failures, retain the committed board, block the save session, disable gameplay and gate public interactions. | Static control-flow review; runtime fault injection pending. |
| P1 | Startup allowed gameplay without complete configured scene references; unreadable saves were displayed as a new session without an explicit session block. | Validate references before startup; block saving and interaction when existing saves cannot load. | Static control-flow review only. |
| P1 | Gate instructions require numeric item identities and A/B destinations, but generated objects only had names, not visible identity text. | Add item IDs and destination labels with explicit font/material assignment. | Editor rendering and readability pending. |
| P1 | The old tray used five columns with 1.9-unit spacing; later rows overlapped compartment positions in larger levels. | Use six columns with 1.08-unit horizontal / 0.8-unit row spacing; expand and reposition the tray target. | Independent arithmetic bounds/spacing checks passed for all 12 level sizes. Camera readability pending. |
| P1 | Explicit engine module list omitted TextRendering while using Font and Text. | Declare com.unity.modules.textrendering; labels also depend on it. | Package resolution/Unity compilation pending. |

## Executed evidence

- Parsed every C# source file with tree-sitter-c-sharp: 61 files, 3979 lines, zero syntax error or missing nodes. This is syntax parsing, not C# type checking or Unity compilation.
- Parsed all JSON files and assembly definitions.
- Checked 94 metadata GUIDs: no duplicates; every Assets file has matching metadata.
- Checked every MonoBehaviour class has a matching source filename.
- Checked Domain source has no UnityEngine/UnityEditor dependencies; its assembly disables engine references.
- Independently recomputed authored count/weight capacities for all 12 campaign levels in Python; all fit their authored bins.
- Independently checked all initial tray cube bounds and pairwise spacing for 6 through 16 items, and quarter-turn seal alignment to tolerance 1e-12.
- These independent arithmetic checks do not execute the C# implementation, Unity physics, renderers or event dispatch.
- Archive CRC, file count, SHA-256 manifest and baseline metadata preservation checked at packaging.

Per-source hashes and syntax status: Verification/SOURCE_INVENTORY.json.
Machine-readable results: Verification/STATIC_RESULTS.json.

## Regression suite additions

- TransferBoundaryRegressionTests: blank/null transfer identifiers, foreign-board ticket, atomic null restore rejection and long revision exhaustion.
- SaveFaultInjectionTests: invalid input must not create a storage directory/lock; future-schema save must block fallback and preserve existing file bytes.
- Existing scene round-trip regression from v4.6 is retained.
- All tests are source additions only. No NUnit pass count is claimed.

## Open findings and release gates

| Priority | Unresolved item | Required evidence or action |
| --- | --- | --- |
| P0 | Unity compilation and package resolution have not run. | Open a fresh extracted folder in 2022.3.62f3; record Editor.log and all compiler/package errors. |
| P0 | No executed EditMode/PlayMode/Android proof. | Execute tests, play the full campaign and inspect every artifact; build and test on Android. |
| P1 | The recovered architecture is Domain plus combined Runtime, not the agreed AppCore/Infrastructure/Input/Presentation separation. Its board is OrderBoard, not the agreed PuzzleBoard/ItemCatalog/TrayState implementation. | Reconcile the recovered source with the accepted architecture before calling DESIGN_VERIFIED for the whole product. |
| P1 | Every move synchronously scans/validates journal files and flushes a save on the main thread. | Profile actual device latency; move I/O behind an application boundary with serialized/backpressured writes and explicit pending-commit UX. Preserve uncertain-commit recovery. |
| P1 | Save schema v1 permits historical unlocked-level values without a complete reward ledger. A SHA-256 checksum can be recomputed by a local editor. | Define legacy migration and authoritative progression policy before tightening validation. Do not claim tamper-proof saves or secure paid entitlements. |
| P1 | Interaction remains tap-select/tap-place, not the requested drag/drop design. Hint, pause/resume, continuous inspection rotation and zoom are not implemented here. | Implement and verify those flows separately; they are not implied by this audit. |
| P2 | Validator opens Main in Single mode, changing the user's clean open-scene setup. Build preflight is a menu check, not an enforced build pipeline gate. | Make validation preserve the scene setup and add a build processor when preparing release. |
| P2 | Some historical documentation and XML comments describe older states; compressed Domain formatting and duplicate collection abstractions remain. | Consolidate after architectural reconciliation; historical reports are not current verification evidence. |

## Complexity

Let N be items, B compartments, K the solver node budget, G journal entries and S maximum save size.

- OrderBoard Prepare/Commit: average O(1) time and O(1) additional state using hash lookups and one pending ticket. Guid generation is treated as constant size.
- Snapshot: O(N) time/space. Solved: O(N). Reset: O(N+B).
- Restore: O(N*B + N log N) time when exact objective validation is included, O(N+B) working space.
- Solver: O(N*B + N log N + K*B) bounded search time including validation, O(N+B) working state. BudgetExceeded remains distinct from Unsolvable.
- Full gameplay move includes board reconstruction, solver, snapshot validation and synchronous journal I/O; the O(1) Domain transfer bound does not describe end-to-end latency.
- Journal scan: O(G*S) bytes read, plus board validation for each valid candidate; pruning sorts O(G log G). Multiple scans per move remain a profiling concern.

## Compatibility boundaries

The public Domain transfer API intentionally changes long ticket identifiers to Guid and int revisions to long. Included callers/tests are updated. External consumers must update their source. Save schema stays v1; board transfer tickets and revisions were not serialized in that schema. Existing save files are not migrated or reset by this patch.

## Verification status

DESIGN_VERIFIED: PARTIAL / unresolved architecture differences.
COMPILE_VERIFIED: false.
TEST_VERIFIED: false.
DEVICE_VERIFIED: false.

## Official references checked

https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.FindObjectsByType.html
https://docs.unity3d.com/2022.3/Documentation/Manual/script-Serialization.html

The current first-open instructions are README_FULL_PROJECT.md. Earlier audit reports remain historical.
