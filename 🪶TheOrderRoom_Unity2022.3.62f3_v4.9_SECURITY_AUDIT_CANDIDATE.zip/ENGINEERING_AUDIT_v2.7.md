# TheOrderRoom v2.7 — Camera / Input Root-Cause Fix

## Source-based findings and changes

1. **P0 — seal geometry and orientation were inconsistent.** In v2.6 the seal with index 1 was positioned at local -X, but a positive 90-degree turn brought local +X toward the camera at -Z. Therefore the state machine orientation could select a seal on the back side. Place seal i at `(sin(i*pi/2)*0.53, 0.28, -cos(i*pi/2)*0.53)` and face outward using yaw `180-i*90`. After i positive quarter turns the matching seal is centered at the camera-facing -Z side.
2. **P0 — touch/UI dispatch could leak to the world.** `IsPointerOverGameObject(touchId)` is not reliable when the touch ID differs from the UI EventSystem pointer ID. Replace with a screen-position-based EventSystem.RaycastAll before world Physics.Raycast.
3. **P1 — inactive inspection rotation.** Reject RotateQuarter when the view is not active.

## Independent static geometric checks

For i=0,1,2, applying +i*90-degree Y rotation to seal i yields (x≈0,z=-0.53). Outward normal rotates to -Z. These identities were verified by a Python geometric test while packaging.

## Remaining risks

- No Unity editor or C# compiler was run in this environment. Camera and Physics Raycast tests must be executed in Unity.
- Camera layer 30 is project-global and may conflict with user-created layers.
- URP overlay camera setup and render pipeline-specific camera ordering require runtime verification.
- RaycastAll allocates per tap; replace with a pooled list if profiling demonstrates allocation pressure.
- Input System touch emulation and pointer ownership over drags require dedicated PlayMode tests.
- Save journal crash recovery and memory leak tests remain unexecuted.

## Unity acceptance tests

1. Compile without CS errors; run all EditMode tests.
2. Scan front seal at 0 turns, second at +1 turn, third at +2 turns. At +3 turns scan must fail.
3. Touch an interactive UI button overlaying a world object; no world selection should occur.
4. Tap rapidly on SCAN/TURN/CLAIM and test touch + simulated mouse input.
5. Reopen inspection 100 times and compare camera/material counts with Unity Profiler.

Status: STATIC_VERIFIED / UNITY_UNVERIFIED / NOT_RELEASE_READY.
