# Security review: Unity advisories and project attack surface

Review date: 2026-11-09. Target editor remains Unity 2022.3.62f3.

## Findings

| Finding | Evidence and scope | Action |
| --- | --- | --- |
| CVE-2025-59489, unsafe file loading | Unity's advisory identifies Unity 2022.3.62f2 as a first patched version for the legacy 2022.3 LTS line and 2022.3.67f2 for the xLTS line. The project's 2022.3.62f3 is newer than the first legacy fix, but below the listed xLTS fix. Confirm the installed Editor's servicing branch with Unity before distribution; prefer the first later patch that preserves the project's compatibility target. | No source-level application fix is available for an Editor/runtime library flaw. Keep the current target fixed until a supported compatible patch is selected; do not ship a build from an unresolved affected branch. |
| CVE-2026-111943, compromised certificate validation | Unity's November 7 advisory says fixes are being prepared for Unity 6000.0 and later and older lines, including 2022.3, remain under assessment. Android game players are protected by Google's October 2026 Play Services update, while the OpenJDK shipped for Android builds is separately affected and awaiting an Adoptium update. | Keep Android devices and build tooling updated. Do not send secrets over network paths until the editor/build-tool status and every network dependency are reviewed. No application network API was found in the scanned C# files. |
| CVE-2026-111497, Brotli decoder | Unity says exposure requires Brotli decoding of attacker-controlled data through BrotliStream, BrotliDecoder or HttpClient Brotli decompression. Its advisory says UnityWebRequest and AssetBundles do not use Brotli. | No listed decoder API was found in 68 C# files; no third-party DLL/SO/AAR/JAR was found under Assets. This is source-level evidence only and does not cover packages downloaded by Package Manager or native code hidden elsewhere. Do not add untrusted Brotli decoding until a patched Unity release is available. |
| Package registry trust | The project's Packages/manifest.json has no custom scoped registry and declares 11 exact package versions. Unity warns that an impersonated registry can target Package Manager while its patch is unavailable for older lines. | Keep scoped registries absent unless controlled and independently authenticated. Use Unity's default registry and re-evaluate before adding packages. |

## Verification method

`Verification/Portable/security_surface_scan.py` performs a repeatable scan of the Unity version, package manifest, C# API references and binary files under Assets. Its JSON output is `Verification/SECURITY_SURFACE.json`. The script is intentionally conservative: a clean result narrows the reviewed source surface but cannot establish that third-party package contents, Unity Editor internals, generated code, remote responses or runtime behavior are safe.

The 153 pure-domain tests and 56 persistence tests were rerun on 2026-11-09 and passed. These tests do not execute Unity, Unity's Package Manager, Android OpenJDK, the Unity serializer, engine physics or device networking.

## Release decision

Security status: **REVIEWED WITH EXTERNAL ENGINE/TOOLCHAIN ITEMS OPEN**. The project source contains no discovered Brotli or application networking entry points, and no custom registry is configured. This does not certify the requested Unity editor line as patched for the October 2026 advisories. Before publication, verify Unity's current patch status for 2022.3, the Android OpenJDK distribution shipped by the installed editor, and any subsequently added package or native dependency.

## Official sources

- CVE-2025-59489: https://unity.com/security/sept-2025-01
- CVE-2026-111943: https://gw-prd.hexagon.unity.com/security/unity-emudhra-compromise
- CVE-2026-111497: https://activation.unity3d.com/security/unity-brotli-decoder-vulnerability
