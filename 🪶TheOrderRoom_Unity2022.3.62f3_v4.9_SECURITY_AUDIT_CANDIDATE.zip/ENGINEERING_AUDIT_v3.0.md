# TheOrderRoom v3.0 — Integrity Gate Candidate

## Scope
Source-based hardening of v2.9. This is a Unity overlay, not a full Unity project.

## Changes
- `OrderSaveStore.ValidBoardSnapshot`: validate the exact item-to-destination map using `OrderLevels.Create(level).Restore(...)` before accepting *or writing* a save. This rejects structurally valid but impossible game states and prevents an invalid newest generation from being selected.
- `TryLoad` / `TrySave`: handle file enumeration/inspection exceptions at public API boundary; no unhandled exception escapes and no partial load is published.
- `OrderGame.Select`: block selection during inspection, reward commit and level transition.
- `OrderGame.HandleWorldTap`: exclude inspection layer 30 from world physics raycasts; ignore triggers.

## Compatibility
- Save schema stays at 1. Existing files are never rewritten during load.
- Existing GUID/.meta and asmdef names retained.
- No claims of executed Unity compilation or EditMode/PlayMode tests.

## Limitations / remaining risks
- Runtime Unity compilation and all Unity tests unverified.
- A malicious local actor can modify both save payload and SHA-256 checksum; SHA-256 is not authentication.
- Cross-process file concurrency and storage power-loss durability not proven.
- Runtime input pointer ownership, URP rendering and memory profile require PlayMode/device testing.
- Rejecting previously tolerated invalid board snapshots may require manual recovery from older valid generations; preserve backups.

## Suggested Unity acceptance tests
1. Save and load valid puzzle board; check exact item locations.
2. Create checksum-valid but invalid destination snapshot; load must reject it.
3. Make newest generation invalid and retain older valid generation; load must recover older one.
4. Inject IOException/UnauthorizedAccessException on journal enumeration; API must return failure, not throw.
5. Confirm world clicks do not target layer 30 or UI while inspection is open.
