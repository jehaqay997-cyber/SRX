# TheOrderRoom v2.6 — Critical source remediation

## Root causes corrected
- Inspection seal normals were inward-facing (`+Z` at front `-Z` seal), causing the facing check to reject legitimate scans. The seal rotations are now 180 degrees outward from the sculpture core.
- The inspection camera GameObject was active during construction. Camera construction now occurs while inactive, then activates with rendering disabled.
- Restore loaded a fresh board and refreshed UI, then replaced the board with a restored instance; restored positions could therefore remain visually stale. Restore now publishes the validated board once and refreshes once.
- Reward and level transition operations now block Reset/Undo/Place during an in-progress transaction.
- Save artifact identifiers are checked against the campaign catalog rather than accepting arbitrary strings.
- Missing optional save files are excluded from error messages.

## Open / unverified
- Unity compilation, Test Runner, PlayMode, platform filesystem durability, camera layering with URP, mobile multi-touch and GPU profiling remain unverified.
- Save data is not cryptographically authenticated. SHA-256 only detects accidental corruption.
- A stronger next iteration should decouple save validation from Unity file IO and add deterministic failure-injection tests.
- Unity `Destroy` is deferred until end-of-frame; resource usage must be measured in the Unity Profiler.

## Unity test protocol
1. Import `Assets/_Project` into a BACKUP of the Unity 6000.3.28f1 project, retaining existing .meta files.
2. Check Console compilation errors, then run all EditMode tests.
3. Start a new session; solve room; INSPECT; SCAN front seal; TURN 90; SCAN second; TURN 90; SCAN third; CLAIM.
4. Save, quit PlayMode, reenter; verify board positions, title and rewards agree.
5. Open/close inspection 100 times; monitor cameras, managed memory and materials in Profiler.
6. Repeat rapid clicks, multi-touch, occlusion and failed-save scenarios.

STATUS: STATIC_SOURCE_PATCHED; UNITY_UNVERIFIED; NOT_RELEASE_READY.
