# TheOrderRoom v3.4 — Writer Isolation Candidate

## Verified source changes
- Added an OS-enforced exclusive writer lock around the full save inspection, generation allocation, append-only commit and pruning operation.
- Lock uses FileShare.None and a persistent `.writer.lock` file; the OS releases the handle after a crash. Do not delete the lock file to unlock the save.
- Lock file is deliberately excluded from recovery candidates and generation numbering.
- Added two EditMode tests for exclusion and exclusive file-handle semantics; tests have NOT been executed in Unity.

## Limitations / unresolved risks
- Non-cooperating writers or direct file modification are not prevented.
- Filesystem durability after power loss remains device dependent.
- The 32-invalid-generation limit can still block writes until explicit maintenance; no automatic deletion is permitted.
- The lock is held during synchronous disk I/O; high latency may stall the main thread.
- No Unity compilation, PlayMode, Android or iOS verification was performed.
- This is an overlay, not a complete Unity project.

STATUS: SOURCE_PATCHED / ARCHIVE_VERIFIED / UNITY_UNVERIFIED / NOT_RELEASE_READY.
