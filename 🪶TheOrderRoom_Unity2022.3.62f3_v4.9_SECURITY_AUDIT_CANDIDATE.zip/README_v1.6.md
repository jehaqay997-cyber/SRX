# TheOrderRoom v1.6 — 3D Artifact Inspection Candidate

Target: Unity 6000.3.28f1. Derived from v1.5; preserves existing sources and .meta GUIDs.

## Player loop
1. Solve the puzzle.
2. The 3D inspection object appears automatically. INSPECT reopens it.
3. TURN LEFT / TURN RIGHT rotate the actual 3D model; two quarter-turns reveal its secret.
4. CLAIM grants the artifact exactly once, persists the journal, and unlocks the next room.
5. Reload: collected artifacts are restored; unclaimed solved puzzles can be inspected again.

## Important integration limitations
- Editor bootstrap is non-destructive: existing Main.unity is NOT updated. Build in a clean test project or manually migrate the scene.
- Current model is an original procedural prototype made from Unity primitives, not final art; no real 3D asset package or reveal VFX.
- Turn-count is a prototype interaction, NOT a finished deductive puzzle.
- Legacy 12-level rules still exist. The inspection is a gated collection step, not a new puzzle objective.
- Unity compilation, EditMode tests, PlayMode, mobile performance and persistence crash tests are NOT executed here.
- Previous saves may have unlocked levels before claiming artifacts; the new Next button requires artifact ownership. Old unlocked levels remain selectable via LoadLevel, which is a migration policy requiring product review.

## Setup
Copy Assets/_Project into a clean Unity 6.3 project preserving .meta files. Install Input System if using new-input-only mode. In Editor run TheOrderRoom > Create Integrated Scene (Non-Destructive). Run EditMode tests. Press Play.

## Design follow-up
Replace turn-count gate with authored clue hotspots, inspection camera, contextual hints, 3D art, lighting and audio. Add PlayMode tests and persistence fault-injection before release.
