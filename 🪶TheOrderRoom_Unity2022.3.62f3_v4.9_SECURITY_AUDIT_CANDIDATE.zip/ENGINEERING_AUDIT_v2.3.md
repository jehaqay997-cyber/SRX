# TheOrderRoom v2.3 Camera Integrity Audit

## Source modifications
- Dedicated inspection camera with explicit enable/disable lifecycle.
- Scan is gated by real viewport/frustum check and Physics.Raycast first-hit collider identity.
- Three seal colliders retained; core/satellite colliders removed, preventing false occlusion.
- Rotation and seal placement align with logical 0/1/2 orientation (90-degree increments).
- Physics.SyncTransforms after UI-driven rotation.
- Repeated inspections restore renderer/collider state and zero rotation.

## Remaining risks / validation
- Camera culling mask includes all scene layers; nearby scene geometry may occlude seals. This is safe fail-closed but can block gameplay. For production use a dedicated inspection layer and configure culling/lighting per project.
- Camera renders a solid background and UI canvas must render above it. Verify canvas render mode and sorting.
- Main scene and inspection camera both render during inspection: measure mobile overdraw and optimize later.
- Unity compilation, tests, device camera framing and physics ray hits have NOT been executed here.
- Do not replace existing .meta files with different GUIDs; this package retains prior metadata.

## Manual Unity checks
1. Open generated scene and enter Play Mode. Solve room; press INSPECT.
2. Verify dedicated inspection camera renders artifact; SCAN at orientation 0 succeeds once.
3. TURN RIGHT, SCAN: orientation 1 succeeds; repeat for orientation 2.
4. TURN RIGHT to blank orientation 3; SCAN must fail.
5. Disable/occlude a seal: SCAN must fail without awarding progress.
6. CLAIM only after three successful scans; restart and verify saved reward.
7. Check Console for compile/runtime errors, and test on target mobile graphics API.
