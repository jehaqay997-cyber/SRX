# TheOrderRoom v4.8 - puzzle systems development and verification

Target editor: Unity 2022.3.62f3.
Input baseline: v4.7 audited candidate, SHA-256 8c406fa78a29abd2d978263c73e61a5fd4e51c015429ed23b3f4812965bee0a7.
Release decision: NOT RELEASE VERIFIED.

## Delivered behavior

- Twelve authored puzzle definitions now combine symbol sorting, exact weight quotas, separated pairs, first-key dependencies and intermediate count balance.
- Later gates accept every arrangement satisfying their published laws. The authored assignment is a constructive witness and hint target, not a hidden mandatory solution. Only the first teaching gate uses an explicitly published exact identity assignment.
- Every level has a title, setup and artifact-earned revelation in a four-chapter investigation. The story progresses from the erased signal through conflicting testimony and a falsified timeline to the unedited archive.
- In-game RULES and HINT buttons, item weights, drawer counters/quotas and longer plot reveals are wired by the scene generator.
- New definitions are pure C# data and rules, lazily cached. They validate their authored solutions before becoming available.
- Snapshot restoration validates simultaneous states instead of alphabetic replay; valid dependency states no longer fail merely because a dependent ID sorts before its key.
- Cyclic prerequisites are rejected with an iterative topological check.

## Implemented safeguards

| Area | Correction | Evidence |
| --- | --- | --- |
| Domain state | Board mutations and snapshot reads share a state lock; revisions and occupancy/weight indexes stay coherent. | A 4,000-attempt concurrent move regression checks successful-move/revision equality and final indexes. |
| Rule evaluation | Candidate state is evaluated before mutation; failed moves preserve locations, revision and indexes. | Independent bounded model compares 432 states and 2,016 transitions across all 16 combinations of four rule families. |
| Content persistence | Schema 1 / content 0 retains legacy definitions. Schema 2 / content 1 selects new definitions. Unknown future schema/content prevents recovery and writes. | Executed topology distinction, modern round-trip, future-version and unchanged-file tests under the portable serializer adapter. |
| Progression | Modern saves require the reward ledger for all previously unlocked rooms. Legacy historical progress is preserved under its original version. | Executed skipped-reward rejection regression. This is logical validation, not client-side tamper resistance. |
| Read-only future protection | Inspect store before creating directories or writer-lock files, then recheck under writer exclusion. | A future-only store regression confirms no lock/new file is created and original bytes remain unchanged. |
| Uncertain commits | Exceptions during public post-publication verification are reported as unknown commit and force authoritative reconciliation. | Executed failure injection between core publication and public verification. |
| Visual consistency | Missing piece roots fail closed. Artifact construction failure blocks interaction. Owner checks reject foreign item/destination markers; missing EventSystem blocks world taps. | Static review; complete Unity behavior still unverified. |
| Inspection geometry | Opaque sculpture geometry retains colliders; satellites are below the seal ray; discarded objects are deactivated before deferred destruction. Rules overlay prevents scans while covering the artifact. | Independent geometry calculation; 12 engine occlusion cases included but not run. |
| Build integrity | Scene validation scopes checks to Main, preserves other loaded scenes, checks serialized references, input owner, all destinations and persistent button methods. Build preprocessor rejects invalid/missing Main setup. | Source/syntax review only. Requires Unity execution. |

## Executed validation

| Scope | Result | Limits |
| --- | --- | --- |
| v4.7 pure baseline | 93 passed / 0 failed | Portable source subset; not Unity. |
| v4.8 pure source | 153 passed / 0 failed | Actual C# compiled against .NET Standard 2.1; tests run on .NET 8. |
| v4.8 persistence repository | 56 passed / 0 failed | Actual OrderSaveStore source and real file I/O, using a System.Text.Json adapter for Unity API calls. |
| Authored campaign | 12 legal move paths executed and exported | Feasibility and fresh-board hint checks; not human difficulty testing. |
| Syntax/metadata | 68 C# Assets files; 5,014 lines; zero parser errors; 101 unique GUIDs; no missing asset metadata | Syntax parsing does not type-check engine/editor assemblies. |
| Geometry | Tray and drawer cube bounds, quarter-turn alignment and decorative scan-ray clearance passed | Arithmetic model, not rendered or physics-engine proof. |

Current executed test total: 209. Baseline 93 is reported separately and is not added to that total.

The standalone SDK was downloaded from Microsoft's release metadata and SHA-512 verified before use. Portable test infrastructure pins NUnit/NUnitLite 3.13.3, uses C# 9 for the pure target and keeps the adapter outside Assets. It is not a fake Unity runtime, and no Unity compilation is inferred from those results.

The initial VSTest launcher failed before test execution; the final runs used NUnitLite directly. Two historical gate tests now explicitly select the legacy content profile, because arbitrary move order is not a valid assumption for the new balance/dependency rules. Separate current-campaign tests execute valid legal paths.

Raw results: Verification/TestResults/*.xml.
Source hashes: Verification/SOURCE_INVENTORY.json.
Executed definitions and paths: Verification/CAMPAIGN_EXECUTED_PATHS.json.
Puzzle design and story: PUZZLE_DESIGN_v4.8.md.

## State invariants

1. Catalog identities are fixed for the lifetime of an OrderBoard; every identity has exactly one location, including TRAY.
2. Every non-tray location is known and matches the item's symbol.
3. Cached count and weight equal the sum represented by locations and stay within drawer limits.
4. Every committed intermediate state satisfies all active placement rules.
5. Accepted state mutation advances the long revision once; exhaustion is rejected without wrapping.
6. Only a currently issued board-stored Guid ticket can commit; tickets are single-use and revision-bound. Guid collision resistance is probabilistic; this is not an anti-cheat boundary.
7. Restore validates a private candidate and swaps locations/indexes under the same state lock.

Inductive reasoning: the constructor validates the empty initial state; Prepare cannot change locations/indexes; Commit validates the proposed result before updating known entries; Restore validates the complete candidate before swapping; Reset restores the already validated empty state. Public state reads and mutations share the lock. These arguments assume trusted immutable rule implementations and ordinary managed execution; no guarantee is made for process termination or resource exhaustion inside a mutation.

Positive int item weights and at most int.MaxValue items bound any sum by (2^31-1)^2 = 4611686014132420609, below long.MaxValue = 9223372036854775807. Revision increment and solver budget counters use long, and graph/solver traversal is iterative.

## Complexity

Let N be items, B bins, R special rules, G journal files, S maximum save size and K solver node budget.

- Rule-free Prepare/Commit: average O(1) hash operations. With special laws: O(R*N) time and O(N) candidate state, not O(1).
- Restore: O(N+B+R*N) time and O(N+B) temporary state. Solved: O(N+R*N). Snapshot/Reset: O(N) / O(N+B).
- Dependency graph validation: O(N+R) expected time and space. Immutable catalog/rule/target views are cached.
- Hint: O(R*N^2) worst-case time with repeated candidate checks; O(N+B+R) live working state. It is a legal-action heuristic, not an optimal search guarantee.
- Legacy exact feasibility solver: O(N*B + N log N + K*B) time and O(N+B) state, with an explicit BudgetExceeded outcome.
- Journal scanning remains O(G*S) byte I/O plus board validation, with O(G log G) pruning sort. Read-only preflight adds a scan; saves remain synchronous on the Unity main thread.

## Remaining release blockers

- Unity Editor compilation, package resolution, test discovery, EditMode/PlayMode execution, serialized scene generation and Android build/device tests are unverified.
- The project still uses a pure Domain plus combined Runtime assembly. The agreed complete AppCore/Infrastructure/Input/Presentation split and PuzzleBoard/ItemCatalog/TrayState structure are not claimed complete.
- Synchronous journal I/O per move needs actual device profiling and a separately designed serialized background write boundary. No latency/frame-rate/availability SLA is claimed.
- SHA-256 detects accidental byte changes and can be recomputed by a local editor. Paid entitlement/server-authoritative anti-cheat infrastructure is not implemented.
- Human puzzle difficulty, UI readability, safe areas, touch feel, camera composition and narrative reward quality still require playtesting.
- Continuous drag/drop, free inspection rotation/zoom and complete pause/resume state machine remain outside this patch.
- No production-ready, OWASP-certified, tamper-proof, 99.999%-available or sixfold-performance claim is made.

## Verification ledger

DESIGN_VERIFIED: PARTIAL - rule invariants and bounded checks have evidence; full architecture differs from the accepted design.
COMPILE_VERIFIED: PARTIAL - pure .NET Standard 2.1 compilation passed; Unity assemblies unverified.
TEST_VERIFIED: PARTIAL - 209 host tests passed; actual Unity serializer/engine tests unverified.
DEVICE_VERIFIED: UNVERIFIED.

## Authoritative references consulted

https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/edit-mode-vs-play-mode-tests.html
https://docs.unity3d.com/2022.3/Documentation/Manual/script-Serialization.html
https://learn.microsoft.com/en-us/dotnet/core/install/linux-scripted-manual
https://docs.nunit.org/articles/nunit/getting-started/installation.html

Earlier audit reports are historical snapshots. This report and README_FULL_PROJECT.md govern this delivery.
