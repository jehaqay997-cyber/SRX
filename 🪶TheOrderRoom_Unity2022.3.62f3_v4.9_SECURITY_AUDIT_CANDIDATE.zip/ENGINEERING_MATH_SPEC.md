# Mathematical contracts and engineering hypotheses

## Discrete rotational group C4
Quarter-turn states form Z/4Z. Normalize `q mod 4` to [0,3]. Time O(1), space O(1). Avoid accumulating floating point Euler angle increments.

## Seal geometry
For seal index i in {0,1,2}, radius r > 0: x_i = r sin(i*pi/2), z_i = -r cos(i*pi/2). After a positive i*90 degree Y rotation, (x_i,z_i) maps to (0,-r). Tested at tolerance 1e-12 in double precision. Unity casts to float for Transform.

## Differentiation and integration
Use smoothstep s(t)=3t^2-2t^3, t in [0,1], for *future* rotation animations (not activated in current runtime). s'(t)=6t(1-t), s'(0)=s'(1)=0, integral_0^1 s'(t)dt=1. A primitive is S(t)=3t^2-2t^3. This constrains animation endpoints and velocity, not gameplay scoring.

## Hypotheses and acceptance
H1: Each seal is geometrically front-aligned at its expected discrete orientation. Static mathematical test available; Unity occlusion/raycast remains unverified.
H2: Saving a reward must be durable before the UI reports success. Runtime fault injection remains unverified.
H3: No input event that starts over UI reaches a world target. Multi-touch PlayMode tests remain unverified.
H4: 100 inspection open/close cycles leave no rising managed/native memory trend. Requires Unity Profiler.

## Complexity
- Rotation, seal position, easing and derivative: O(1) time / O(1) space.
- Current board validation and save serialization scale with board item count and retained journal generations; bound and profile on device before production.
