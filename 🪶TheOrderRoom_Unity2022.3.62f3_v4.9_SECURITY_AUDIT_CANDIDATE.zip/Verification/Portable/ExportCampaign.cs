using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using TheOrderRoom.Domain;

internal static class ExportCampaign
{
    private static void Main(string[] args)
    {
        if (args.Length != 1) throw new ArgumentException("Expected output JSON path.");
        var exported = new List<object>();
        for (int level = 0; level < CampaignRules.LevelCount; level++)
        {
            var definition = CampaignPuzzles.Get(level);
            var board = definition.CreateBoard();
            var pending = definition.Items.Select(x => x.Id).ToList();
            var moves = new List<object>();
            while (pending.Count > 0)
            {
                int before = pending.Count;
                foreach (string id in pending.ToArray())
                    if (board.Move(id, definition.Solution[id], out _))
                    {
                        moves.Add(new { item = id, destination = definition.Solution[id], revision = board.Revision });
                        pending.Remove(id);
                    }
                if (pending.Count == before) throw new InvalidOperationException("Authored path is blocked: " + level);
            }
            if (!board.Solved) throw new InvalidOperationException("Authored path did not solve level " + level);
            exported.Add(new
            {
                level = level + 1, contentVersion = CampaignPuzzles.ContentVersion,
                title = definition.Title, brief = definition.Brief, revelation = definition.Revelation,
                exactIdentityRequired = definition.ExactIdentityRequired,
                items = definition.Items.Select(x => new { id = x.Id, tag = x.Tag, weight = x.Weight }).ToArray(),
                bins = definition.Compartments.Select(x => new { id = x.Id, tag = x.Tag, capacity = x.Capacity, maxWeight = x.MaxWeight }).ToArray(),
                rules = definition.Rules.Select(x => new { type = x.GetType().Name, description = x.Description }).ToArray(),
                authoredSolution = definition.Solution, legalSolutionPath = moves, solvedByExecution = board.Solved
            });
        }
        File.WriteAllText(args[0], JsonSerializer.Serialize(exported, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine("Exported 12 executed legal campaign paths.");
    }
}
