#!/usr/bin/env python3
"""Conservative source-level checks for the documented Unity security advisories."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "Assets"
MANIFEST = ROOT / "Packages" / "manifest.json"
VERSION = ROOT / "ProjectSettings" / "ProjectVersion.txt"
OUTPUT = ROOT / "Verification" / "SECURITY_SURFACE.json"

RISK_PATTERNS = {
    "BrotliStream": re.compile(r"\bBrotliStream\b"),
    "BrotliDecoder": re.compile(r"\bBrotliDecoder\b"),
    "HttpClient": re.compile(r"\bHttpClient\b"),
    "AutomaticDecompression": re.compile(r"\bAutomaticDecompression\b"),
    "UnityWebRequest": re.compile(r"\bUnityWebRequest\b"),
}


def main() -> int:
    problems: list[str] = []
    findings: list[dict[str, str]] = []

    try:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        problems.append(f"Cannot parse package manifest: {type(exc).__name__}")
        manifest = {}

    scoped = manifest.get("scopedRegistries", [])
    if scoped:
        problems.append("Custom scoped package registries are configured.")
    else:
        findings.append({"check": "scoped_registries", "result": "none_configured"})

    dependencies = manifest.get("dependencies", {})
    unpinned = sorted(
        name for name, version in dependencies.items()
        if not isinstance(version, str) or not re.fullmatch(r"\d+\.\d+\.\d+", version)
    )
    if unpinned:
        problems.append("Non-exact package versions: " + ", ".join(unpinned))
    else:
        findings.append({
            "check": "manifest_dependency_pins",
            "result": "all_exact_versions",
            "count": str(len(dependencies)),
        })

    try:
        version_text = VERSION.read_text(encoding="utf-8")
        version_match = re.search(r"(?m)^m_EditorVersion:\s*(\S+)\s*$", version_text)
        if not version_match:
            problems.append("Unity editor version is missing from ProjectVersion.txt.")
            editor_version = "unknown"
        else:
            editor_version = version_match.group(1)
            findings.append({"check": "editor_version", "result": editor_version})
    except OSError as exc:
        problems.append(f"Cannot read editor version: {type(exc).__name__}")
        editor_version = "unknown"

    files = sorted(ASSETS.rglob("*.cs"))
    occurrences: dict[str, list[str]] = {name: [] for name in RISK_PATTERNS}
    for source in files:
        try:
            text = source.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            problems.append(f"Cannot scan {source.relative_to(ROOT)}: {type(exc).__name__}")
            continue
        relative = source.relative_to(ROOT).as_posix()
        for name, pattern in RISK_PATTERNS.items():
            if pattern.search(text):
                occurrences[name].append(relative)

    for name, paths in occurrences.items():
        findings.append({
            "check": "source_api_scan",
            "api": name,
            "result": "found" if paths else "not_found",
            "files": ";".join(paths),
        })
        if name in {"BrotliStream", "BrotliDecoder", "HttpClient", "AutomaticDecompression"} and paths:
            problems.append(f"Review untrusted compression/network usage: {name} in {', '.join(paths)}")

    binaries = sorted(
        path.relative_to(ROOT).as_posix()
        for pattern in ("*.dll", "*.so", "*.aar", "*.jar")
        for path in ASSETS.rglob(pattern)
    )
    findings.append({
        "check": "third_party_binary_inventory",
        "result": "found" if binaries else "none_found",
        "files": ";".join(binaries),
    })

    result = {
        "scope": "static source and manifest scan; not a dependency binary audit or proof of runtime non-exposure",
        "unity_editor": editor_version,
        "source_files_scanned": len(files),
        "findings": findings,
        "problems": problems,
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
