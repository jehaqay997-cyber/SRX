using System;
using System.IO;
using System.Text.Json;
namespace UnityEngine
{
    // Portable test adapter only. It is excluded from Assets and is not a Unity implementation.
    public static class Application
    {
        public static string persistentDataPath => Path.Combine(Path.GetTempPath(), "TheOrderRoom_Portable_" + Environment.ProcessId);
    }
    public static class Debug
    {
        public static void LogWarning(object message) => Console.WriteLine("PORTABLE WARNING: " + message);
    }
    public static class JsonUtility
    {
        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions { IncludeFields = true };
        public static string ToJson(object value) => JsonSerializer.Serialize(value, value.GetType(), Options);
        public static T FromJson<T>(string value) => JsonSerializer.Deserialize<T>(value, Options);
    }
}
