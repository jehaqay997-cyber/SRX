# TheOrderRoom v2.5 — Stabilization Candidate

## Source baseline
v2.4 CameraIsolation, copied without renaming existing assets or regenerating existing .meta GUIDs.

## Changes
- ArtifactInspectionView: integer quarter-turn tracking instead of reading back Euler angles; reject back-facing seals and points beyond far clip; explicit owned-resource disposal in editor and runtime.
- OrderPointerInput: single dispatch per frame, suppress mouse events following touchscreen activity; preserve EventSystem UI hit-testing through OrderGame.HandleWorldTap.
- OrderGame: explicit reward and transition in-progress guards, with try/finally around persistence operations.

## Remaining known risks
- The UI event system can invoke separate button callbacks on distinct frames; command suppression is not a complete gesture-state machine.
- The inspection camera uses a secondary Camera with a screen rect; URP camera stacking / mobile renderer compatibility must be checked in Unity.
- `Physics.SyncTransforms` is a global physics synchronization point; profile under load.
- Resource cleanup is deterministic in intent but must be measured with Memory Profiler across repeated sessions.
- Save journal recovery and cross-process locking require fault-injection testing.
- Reward commit after durable save still has a theoretical in-memory failure window; restart should restore persisted truth.
- The bootstrap is non-destructive and does not update pre-existing scenes.

## Verification status
STATIC_SOURCE_REVIEWED. Unity compilation, EditMode, PlayMode, iOS and Android are NOT EXECUTED. This is an overlay, not a full Unity project.

## Unity acceptance checks
1. Import in a COPY of the project; resolve all Console errors.
2. Test Runner EditMode; record all failures.
3. Open/close inspection 100 times; inspect Camera/Material/RenderTexture counts in Profiler.
4. Rapid TURN/SCAN/CLAIM; verify no duplicate claim and correct orientation.
5. Scan from front, back and occluded angles; only the first visible target collider may succeed.
6. Restart after claim; confirm recovered artifact and level unlock.
7. Test touch on UI versus world and simultaneous touches on device.
