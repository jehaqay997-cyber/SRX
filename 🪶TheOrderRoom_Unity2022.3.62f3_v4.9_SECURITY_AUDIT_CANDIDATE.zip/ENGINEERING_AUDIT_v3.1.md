# TheOrderRoom v3.1 — Journal Allocation Safety

## Confirmed source defect
v3.0 selected the next save generation from **valid payloads only**. If an unreadable higher-numbered `.gNNN.json` existed alongside an older valid save, the new save could allocate an already occupied filename, fail repeatedly, and block progress. The append-only journal must not reuse filenames of unreadable generations.

## Changes
- `OrderSaveStore.cs`: allocate the next generation after both highest valid payload and highest existing journal filename; refuse `long.MaxValue`; preserve unreadable files without overwriting.
- `OrderGame.cs`: reject world input when the game component is disabled (e.g. after a post-save state divergence).
- `SaveGenerationAllocationTests.cs`: four new EditMode regression cases (written, not run).

## Scope / limitations
- Source-level fix; no Unity compilation or test runner available in this environment.
- Not a full Unity project; copy `Assets/_Project` to a backed-up Unity project.
- Concurrent processes, power-loss durability, save schema migrations, and complete UI pointer ownership remain unverified.
