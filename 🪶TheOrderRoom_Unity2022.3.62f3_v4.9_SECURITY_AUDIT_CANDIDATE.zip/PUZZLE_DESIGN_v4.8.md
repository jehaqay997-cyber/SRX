# TheOrderRoom v4.8 - puzzle engineering and story dossier

Target: Unity 2022.3.62f3. New campaign: contentVersion=1 / save schemaVersion=2.
Historical campaign: contentVersion=0 / schemaVersion=1.

## Play contract

Select an object, then tap a destination. Every object displays its stable ID and weight. Drawer labels display count/capacity and current weight/quota. RULES shows all restrictions; HINT suggests one legal action without changing the live board. Artifact inspection becomes available after solving; three deliberate seal scans reveal a claimable artifact. Only a durable claim unlocks the next room and reveals its plot information.

## Core rule families

| Rule | Valid move condition | Completion condition | Purpose |
| --- | --- | --- | --- |
| Symbol / capacity / weight | Correct symbol; count <= capacity; weight <= maximum. | Every item leaves TRAY. | Foundational spatial classification. |
| Weight quota | Current drawer weight <= published quota. | Current drawer weight equals quota. | Subset selection and conservation. |
| Separated evidence | Named pair cannot occupy the same non-tray bin. | Same invariant. | Exclusion and relational clues. |
| First-key dependency | A dependent item can be placed only while its prerequisite is placed. A key cannot be removed while dependents remain. | Same invariant. | Reversible dependency planning. |
| Count balance | Absolute count difference in paired bins <= 1 after every accepted action. | Same invariant. | Alternation and intermediate-state reasoning. |
| Exact numbered placement | Used only by the first teaching gate. | Published lower-number A / higher-number B assignment. | Introduces gates without silently imposing a hidden witness on later puzzles. |

## Authored campaign

The table is generated from definitions whose legal solution paths were executed in C#.

| Level | Title | Items / drawers | Active special laws | Plot revelation |
| --- | --- | --- | --- | --- |
| 1 | The Misfiled Signal | 6 / 3 | Symbol classification | The signal was addressed to the curator, not the missing archivist. |
| 2 | The Weight of a Message | 7 / 4 | WeightQuota | The message's weight changed after someone removed a page. |
| 3 | The First Seal | 7 / 6 | Exact teaching assignment | The seal identifies a witness whose name was erased from the archive. |
| 4 | The Witnesses Apart | 9 / 4 | SeparatedPair | The two witnesses never met; the curator combined their statements. |
| 5 | The Archive Needs a Key | 10 / 5 | Prerequisite, WeightQuota | Only the archivist's key could open the original testimony. |
| 6 | The Testimony Lock | 10 / 6 | Prerequisite, SeparatedPair, WeightQuota | The restored testimony places the curator inside the sealed room. |
| 7 | The Two Pendulums | 12 / 4 | CountBalance | The pendulums disagree because one was stopped deliberately. |
| 8 | The Missing Seconds | 13 / 6 | Prerequisite, WeightQuota | The missing seconds reveal when the archive was altered. |
| 9 | The Clock That Lied | 13 / 6 | CountBalance, Prerequisite, WeightQuota | The clock was accurate; the written timeline was the lie. |
| 10 | The Divided Memory | 15 / 5 | CountBalance, SeparatedPair | One memory belongs to the witness, the other to the person who rewrote it. |
| 11 | The Price of Passage | 16 / 6 | Prerequisite, WeightQuota | The passage requires evidence, not the destruction of a memory. |
| 12 | The Last Honest Door | 16 / 6 | CountBalance, Prerequisite, SeparatedPair, WeightQuota | The last door opens onto the unedited archive. The missing archivist preserved the truth. |

## Story structure

1. Signal room: reconstruct the message and discover that its intended recipient was the curator.
2. Living archive: separate conflicting witnesses and recover evidence that implicates the curator.
3. Fractured hour: reconstruct missing seconds and show that the written timeline, rather than the clock, was falsified.
4. Last door: preserve both memory and evidence to reach the unedited archive.

Each revelation follows an earned artifact claim. No cinematic, voice acting, branching ending, or human playtest result is claimed by this source delivery.

## Mathematical model

For item i and destination d, x(i,d) is binary and sum over all destinations including TRAY equals one. Each non-tray placement must match its symbol. A drawer d satisfies sum x(i,d) <= capacity(d) and sum weight(i)*x(i,d) <= maximum(d). Quota drawers replace the completion inequality with equality. Pair separation forbids x(a,d)+x(b,d)>1. Dependency requires placed(dependent) <= placed(key). Count balance requires |count(A)-count(B)| <= 1 at every committed state.

A candidate move is evaluated against the full resulting state before the live board changes. A restored save is evaluated as one simultaneous state, avoiding false rejection caused by alphabetic replay order. Prerequisite graphs are checked with an iterative topological traversal; cycles are rejected before play.

An authored solution is a feasibility witness and hint target. Later stages accept other solutions satisfying visible laws. One executed regression swaps equal-weight SUN items in level 11 and confirms the alternative remains solved.

The 16-rule-combination differential checker exhaustively evaluates 27 three-item states per combination against an independent array/arithmetic oracle. This is a bounded proof for that small model; it is not an exhaustive proof of every large campaign state.

## Constructive solvability and hint limits

CAMPAIGN_EXECUTED_PATHS.json records every stable item ID, weight, drawer, law, authored assignment and an executed legal move path. Every fresh stage was also solved through repeated hints in at most one placement per item. Hints from arbitrary partially rearranged states are legal suggestions; global shortest-path optimality and guaranteed no-cycle completion from every possible state are not claimed.

## Geometry

Initial tray layout uses six columns, 1.08-unit horizontal spacing and 0.8-unit row spacing for 0.65-unit cubes. All 12 initial layouts fit the tray bounds. Drawer capacities fit their visible rectangular geometry. Seal rotations use exact quarter turns; independent calculations verify alignment to tolerance 1e-12. Decorative satellites remain below the scan ray, and opaque geometry keeps its colliders so actual blockers can prevent scanning.

These arithmetic checks do not replace Unity rendering, physics, touch usability, safe-area or readability tests. InspectionOcclusionTests contains engine-level visibility/blocker tests, not yet executed here.

## Design acceptance still required

- Human playtests must measure clarity, challenge, time-to-solve, frustration and whether each revelation rewards the puzzle.
- A higher count of rules does not establish higher quality or difficulty. The present 6-16 item stages are a testable prototype, not a validated commercial difficulty curve.
- Interaction remains tap-select/tap-place. Continuous drag/drop, continuous inspection rotation and zoom are outside this patch.
- Background art, item silhouettes, audio, cinematic staging and localization remain separate production work.
