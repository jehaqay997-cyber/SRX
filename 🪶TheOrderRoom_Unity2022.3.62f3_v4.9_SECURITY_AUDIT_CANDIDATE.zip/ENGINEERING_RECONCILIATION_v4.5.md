# TheOrderRoom v4.5 — Save Reconciliation Implementation

Base: TheOrderRoom_v3.8_Original_Repaired_ValidatedStatic.zip (Unity 6000.3.28f1).

## Changed
- `Assets/_Project/Runtime/OrderGame.cs`: block writes after indeterminate/stale journal results; perform read-only authoritative recovery; stage and validate board and ledger before publishing; clear volatile Undo/Redo; keep session write-blocked until restart.
- All other original files preserved byte-for-byte. Save format unchanged.

## Safety boundaries
- No blind retry after uncertain journal publication.
- Recovery failure leaves the session blocked.
- No Unity compile or NUnit execution available in this environment.
- Unity scene serialization remains a separate release blocker.
- This is a source-level candidate, not a verified release.
