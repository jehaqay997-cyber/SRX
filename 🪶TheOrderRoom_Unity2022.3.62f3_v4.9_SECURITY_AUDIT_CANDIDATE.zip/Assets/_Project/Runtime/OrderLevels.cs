using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Runtime
{
    /// <summary>Deterministic twelve-level campaign; level definitions have no random runtime state.</summary>
    public static class OrderLevels
    {
        public const int Count = CampaignRules.LevelCount;
        private static readonly string[] Tags = { "SUN", "MOON", "STAR" };

        public const int CurrentContentVersion = CampaignPuzzles.ContentVersion;
        public static OrderBoard Create(int level) => Create(level, CurrentContentVersion);
        public static OrderBoard Create(int level, int contentVersion)
        {
            if (contentVersion == CurrentContentVersion) return CampaignPuzzles.Get(level).CreateBoard();
            if (contentVersion != 0) throw new ArgumentOutOfRangeException(nameof(contentVersion));
            return CreateLegacy(level);
        }
        private static OrderBoard CreateLegacy(int level)
        {
            CampaignRules.ValidateLevel(level);
            var items = new List<Item>();
            var compartments = new List<Compartment>();
            int chapter = CampaignRules.ChapterOf(level);
            int stage = level % CampaignRules.LevelsPerChapter;
            for (int tagIndex = 0; tagIndex < Tags.Length; tagIndex++)
            {
                string tag = Tags[tagIndex];
                int count = 2 + chapter + (stage >= 1 && tagIndex == stage - 1 ? 1 : 0);
                int totalWeight = 0;
                for (int i = 0; i < count; i++)
                {
                    int weight = 1 + ((i + chapter + tagIndex) % 3);
                    totalWeight = checked(totalWeight + weight);
                    items.Add(new Item(tag + "_" + (i + 1), tag, weight));
                }
                // The gate stage splits each tag into two bins; weights are conservatively
                // bounded so the puzzle remains solvable, then verified by the exact solver.
                if (stage == 2)
                {
                    int first = (count + 1) / 2;
                    int second = count - first;
                    compartments.Add(new Compartment(tag + "_A", tag, first, totalWeight));
                    compartments.Add(new Compartment(tag + "_B", tag, second, totalWeight));
                }
                else compartments.Add(new Compartment(tag, tag, count, totalWeight));
            }
            LevelRules.Validate(items, compartments);
            if (!LevelSolvability.TryFindSolution(items, compartments, out var witness, 1000000))
                throw new InvalidOperationException("Campaign level has no solution");
            // The gate objective is authored, not an arbitrary solver witness:
            // within each tag, ascending item index fills A first, then B.
            // The same rule is shown to the player as a visible clue.
            if (stage != 2) return new OrderBoard(items, compartments);
            var targets = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var tag in Tags)
            {
                var group = items.FindAll(x => x.Tag == tag);
                int first = (group.Count + 1) / 2;
                for (int i = 0; i < group.Count; i++)
                    targets.Add(group[i].Id, tag + (i < first ? "_A" : "_B"));
            }
            // OrderBoard validates every authored objective against capacity and weight.
            return new OrderBoard(items, compartments, targets);
        }
    }
}
