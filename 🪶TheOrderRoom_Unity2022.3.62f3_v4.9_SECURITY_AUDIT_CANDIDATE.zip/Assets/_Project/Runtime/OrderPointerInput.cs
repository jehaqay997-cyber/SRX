using UnityEngine;

namespace TheOrderRoom.Runtime
{
    public sealed class OrderPointerInput : MonoBehaviour
    {
        public OrderGame Game;
        private int suppressMouseUntilFrame = -1;
        private int lastDispatchFrame = -1;
        private bool touchGestureConsumed;
        private void Update()
        {
            if (Game == null || lastDispatchFrame == Time.frameCount) return;
#if ENABLE_INPUT_SYSTEM
            var touchscreen = UnityEngine.InputSystem.Touchscreen.current;
            if (touchscreen != null)
            {
                bool touchPresent = false;
                int activeCount = 0;
                foreach (var touch in touchscreen.touches)
                    if (touch.press.isPressed || touch.press.wasPressedThisFrame) activeCount++;
                touchPresent = activeCount > 0;
                if (touchPresent)
                {
                    suppressMouseUntilFrame = Time.frameCount + 2;
                    // Ignore multitouch completely; never transfer ownership mid-gesture.
                    if (activeCount != 1) touchGestureConsumed = true;
                    if (!touchGestureConsumed && activeCount == 1)
                        foreach (var touch in touchscreen.touches)
                            if (touch.press.wasPressedThisFrame)
                            {
                                touchGestureConsumed = true;
                                lastDispatchFrame = Time.frameCount;
                                Game.HandleWorldTap(touch.position.ReadValue(), touch.touchId.ReadValue());
                                return;
                            }
                    return;
                }
                touchGestureConsumed = false;
            }
            if (Time.frameCount <= suppressMouseUntilFrame) return;
            var mouse = UnityEngine.InputSystem.Mouse.current;
            if (mouse != null && mouse.leftButton.wasPressedThisFrame)
            {
                lastDispatchFrame = Time.frameCount;
                Game.HandleWorldTap(mouse.position.ReadValue());
            }
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.touchCount > 0)
            {
                suppressMouseUntilFrame = Time.frameCount + 2;
                if (Input.touchCount != 1) touchGestureConsumed = true;
                if (!touchGestureConsumed && Input.touchCount == 1)
                {
                    var touch = Input.GetTouch(0);
                    if (touch.phase == TouchPhase.Began)
                    {
                        touchGestureConsumed = true;
                        lastDispatchFrame = Time.frameCount;
                        Game.HandleWorldTap(touch.position, touch.fingerId);
                    }
                }
            }
            else if (Time.frameCount > suppressMouseUntilFrame && Input.GetMouseButtonDown(0))
            {
                lastDispatchFrame = Time.frameCount;
                Game.HandleWorldTap(Input.mousePosition);
            }
            if (Input.touchCount == 0) touchGestureConsumed = false;
#endif
        }
    }
}
