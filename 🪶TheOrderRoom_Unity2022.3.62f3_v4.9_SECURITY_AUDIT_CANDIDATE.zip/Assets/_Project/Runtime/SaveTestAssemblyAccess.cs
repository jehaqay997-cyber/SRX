using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("TheOrderRoom.Tests.EditMode")]
