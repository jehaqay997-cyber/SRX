using UnityEngine;

namespace TheOrderRoom.Runtime
{
    public sealed class OrderClick : MonoBehaviour
    {
        public OrderGame Game;
        public string ItemId;
    }
}
