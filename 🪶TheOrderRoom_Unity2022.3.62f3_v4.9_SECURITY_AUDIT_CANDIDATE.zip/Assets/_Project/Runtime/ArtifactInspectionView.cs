using UnityEngine;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Runtime
{
    /// <summary>Owns an isolated inspection camera and authoritative line-of-sight checks.</summary>
    public sealed class ArtifactInspectionView : MonoBehaviour
    {
        // Reserved for inspection-only objects. The bootstrap excludes it from the world camera.
        public const int InspectionLayer = 30;
        public const int InspectionMask = 1 << InspectionLayer;
        private Transform sculpture;
        private int lastRotationFrame = -1;
        private int quarterTurn;
        private Camera inspectionCamera;
        private Material bronze;
        private Material crystal;
        private int lastLevel = -1;
        private readonly Renderer[] sealRenderers = new Renderer[3];
        private readonly Collider[] sealColliders = new Collider[3];

        public void Show(int level)
        {
            if (level != lastLevel || sculpture == null)
            {
                Clear();
                Build(level);
                lastLevel = level;
            }
            if (sculpture != null) sculpture.localRotation = Quaternion.identity;
            quarterTurn = 0;
            for (int i = 0; i < sealRenderers.Length; i++)
            {
                if (sealRenderers[i] != null) sealRenderers[i].enabled = true;
                if (sealColliders[i] != null) sealColliders[i].enabled = true;
            }
            gameObject.SetActive(true);
            lastRotationFrame = -1;
            if (inspectionCamera != null) inspectionCamera.enabled = true;
        }

        public void Hide()
        {
            if (inspectionCamera != null) inspectionCamera.enabled = false;
            gameObject.SetActive(false);
        }

        public void RotateQuarter(int direction)
        {
            if (!isActiveAndEnabled || sculpture == null || (direction != 1 && direction != -1) || lastRotationFrame == Time.frameCount) return;
            lastRotationFrame = Time.frameCount;
            // Snap to an exact quarter turn; no accumulated floating-point drift or tween overlap.
            quarterTurn = PuzzleMath.NormalizeQuarterTurn(quarterTurn + direction);
            sculpture.localRotation = Quaternion.Euler(0f, (float)PuzzleMath.QuarterTurnDegrees(quarterTurn), 0f);
        }

        public bool IsSealVisible(int orientation)
        {
            if (!isActiveAndEnabled || inspectionCamera == null || !inspectionCamera.enabled ||
                orientation < 0 || orientation >= sealRenderers.Length) return false;
            Renderer seal = sealRenderers[orientation];
            Collider target = sealColliders[orientation];
            if (seal == null || target == null || !seal.enabled || !target.enabled ||
                !seal.gameObject.activeInHierarchy) return false;

            // Explicit sync: inspection rotation is driven by UI events, not FixedUpdate.
            Physics.SyncTransforms();
            Vector3 point = seal.bounds.center;
            Vector3 viewport = inspectionCamera.WorldToViewportPoint(point);
            const float margin = 0.08f;
            if (viewport.z <= inspectionCamera.nearClipPlane || viewport.z >= inspectionCamera.farClipPlane ||
                viewport.x < margin || viewport.x > 1f - margin ||
                viewport.y < margin || viewport.y > 1f - margin) return false;

            Vector3 delta = point - inspectionCamera.transform.position;
            float distance = delta.magnitude;
            if (distance <= inspectionCamera.nearClipPlane) return false;
            // Reject a seal facing away from the viewer even if its center is projected.
            if (Vector3.Dot(seal.transform.forward, inspectionCamera.transform.position - point) <= 0f) return false;
            // First hit must be the exact seal collider; never accept an occluded seal.
            if (!Physics.Raycast(inspectionCamera.transform.position, delta / distance,
                out RaycastHit hit, distance + 0.2f, InspectionMask,
                QueryTriggerInteraction.Ignore)) return false;
            return hit.collider == target;
        }

        public void HighlightSeal(int orientation)
        {
            if (orientation < 0 || orientation >= sealRenderers.Length) return;
            if (sealRenderers[orientation] != null) sealRenderers[orientation].enabled = false;
            if (sealColliders[orientation] != null) sealColliders[orientation].enabled = false;
        }

        private void Build(int level)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null) throw new System.InvalidOperationException("Artifact inspection: missing Lit shader.");
            bronze = new Material(shader) { color = new Color(.73f, .47f, .19f) };
            crystal = new Material(shader) { color = new Color(.29f, .83f, .91f) };
            sculpture = new GameObject("InspectableArtifact").transform;
            sculpture.SetParent(transform, false);
            sculpture.gameObject.layer = InspectionLayer;
            sculpture.localPosition = Vector3.zero;
            AddPrimitive("Core", PrimitiveType.Sphere, Vector3.zero, new Vector3(.8f, .8f, .8f), crystal);
            AddPrimitive("Spine", PrimitiveType.Cylinder, new Vector3(0, -.55f, 0), new Vector3(.18f, .6f, .18f), bronze);
            for (int i = 0; i < 3; i++)
            {
                float angle = (i * 120f + level * 23f) * Mathf.Deg2Rad;
                AddPrimitive("Satellite_" + i, PrimitiveType.Cube,
                    new Vector3(Mathf.Cos(angle) * .68f, -.18f - i * .12f, Mathf.Sin(angle) * .68f),
                    new Vector3(.24f, .24f, .24f), bronze);
                var seal = GameObject.CreatePrimitive(PrimitiveType.Cube);
                seal.name = "Seal_" + i;
                seal.transform.SetParent(sculpture, false);
                seal.layer = InspectionLayer;
                PuzzleMath.SealPositionXZ(i, .53, out double sealX, out double sealZ);
                seal.transform.localPosition = new Vector3((float)sealX, .28f, (float)sealZ);
                seal.transform.localRotation = Quaternion.Euler(0f, 180f - i * 90f, 0f);
                seal.transform.localScale = new Vector3(.19f, .19f, .07f);
                sealRenderers[i] = seal.GetComponent<Renderer>();
                sealColliders[i] = seal.GetComponent<Collider>();
                sealRenderers[i].sharedMaterial = crystal;
            }
            var cameraObject = new GameObject("InspectionCamera");
            cameraObject.transform.SetParent(transform, false);
            cameraObject.transform.localPosition = new Vector3(0f, .3f, -3.2f);
            cameraObject.transform.LookAt(transform.TransformPoint(new Vector3(0f, .12f, 0f)));
            cameraObject.SetActive(false);
            inspectionCamera = cameraObject.AddComponent<Camera>();
            inspectionCamera.depth = 10f;
            inspectionCamera.cullingMask = InspectionMask;
            // Keep the puzzle visible outside the inspection region; avoid full-screen camera overwrite.
            inspectionCamera.rect = new Rect(.28f, .30f, .44f, .48f);
            inspectionCamera.fieldOfView = 38f;
            inspectionCamera.nearClipPlane = .1f;
            inspectionCamera.farClipPlane = 30f;
            inspectionCamera.clearFlags = CameraClearFlags.SolidColor;
            inspectionCamera.backgroundColor = new Color(.045f, .055f, .08f);
            inspectionCamera.enabled = false;
            cameraObject.SetActive(true);
        }

        private void AddPrimitive(string name, PrimitiveType type, Vector3 position, Vector3 scale, Material material)
        {
            var obj = GameObject.CreatePrimitive(type);
            obj.name = name;
            obj.transform.SetParent(sculpture, false);
            obj.layer = InspectionLayer;
            obj.transform.localPosition = position;
            obj.transform.localScale = scale;
            // Keep opaque geometry in the raycast so visible blockers really occlude seals.
            obj.GetComponent<Renderer>().sharedMaterial = material;
        }

        private void Clear()
        {
            if (inspectionCamera != null) { inspectionCamera.enabled = false; inspectionCamera.gameObject.SetActive(false); DestroyOwned(inspectionCamera.gameObject); }
            if (sculpture != null) { sculpture.gameObject.SetActive(false); DestroyOwned(sculpture.gameObject); }
            if (bronze != null) DestroyOwned(bronze);
            if (crystal != null) DestroyOwned(crystal);
            inspectionCamera = null;
            sculpture = null;
            for (int i = 0; i < sealRenderers.Length; i++)
            {
                sealRenderers[i] = null;
                sealColliders[i] = null;
            }
        }
        private static void DestroyOwned(Object owned)
        {
            if (owned == null) return;
#if UNITY_EDITOR
            if (!Application.isPlaying) { Object.DestroyImmediate(owned); return; }
#endif
            Object.Destroy(owned);
        }
        private void OnDestroy() => Clear();
    }
}
