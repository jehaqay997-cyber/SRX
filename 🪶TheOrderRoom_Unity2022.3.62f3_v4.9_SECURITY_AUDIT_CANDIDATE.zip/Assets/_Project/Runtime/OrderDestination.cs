using UnityEngine;

namespace TheOrderRoom.Runtime
{
    public sealed class OrderDestination : MonoBehaviour
    {
        public OrderGame Game;
        public string Destination;
        public TextMesh Label;
    }
}
