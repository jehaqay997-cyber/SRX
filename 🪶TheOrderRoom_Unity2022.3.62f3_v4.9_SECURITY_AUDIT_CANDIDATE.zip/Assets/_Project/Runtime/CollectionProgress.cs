using System;
using System.Collections.Generic;

namespace TheOrderRoom.Runtime
{
    /// <summary>Session-scoped, deterministic collection journal. Persistence is not yet implemented.</summary>
    public sealed class CollectionProgress
    {
        private readonly HashSet<string> discovered = new HashSet<string>(StringComparer.Ordinal);
        public int Count => discovered.Count;
        public bool Discover(string artifactId)
        {
            if (string.IsNullOrWhiteSpace(artifactId)) throw new ArgumentException("Artifact id required", nameof(artifactId));
            return discovered.Add(artifactId);
        }
        public bool HasDiscovered(string artifactId) => artifactId != null && discovered.Contains(artifactId);
        public IReadOnlyCollection<string> Snapshot() => new List<string>(discovered).AsReadOnly();
    }
}
