using System.Collections.Generic;
namespace TheOrderRoom.Runtime
{
    internal static class DictionaryExtensions
    {
        public static bool TryAddCompat(this Dictionary<string, string> map, string key, string value)
        {
            if (map.ContainsKey(key)) return false;
            map.Add(key, value);
            return true;
        }
    }
}
