using System;
namespace TheOrderRoom.Runtime
{
    /// <summary>Deterministic, view-independent inspection puzzle. Scanning is an explicit action.</summary>
    public sealed class ArtifactInspectionState
    {
        private readonly bool[] scanned = new bool[4];
        public string ArtifactId { get; private set; }
        public int Orientation { get; private set; }
        public int SealsFound { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsRevealed => IsActive && SealsFound == 3;
        public void Begin(string artifactId)
        {
            if (string.IsNullOrWhiteSpace(artifactId)) throw new ArgumentException("Artifact ID required", nameof(artifactId));
            ArtifactId = artifactId;
            Orientation = 0;
            SealsFound = 0;
            Array.Clear(scanned, 0, scanned.Length);
            IsActive = true;
        }
        public bool Turn(int direction)
        {
            if (!IsActive || IsRevealed || (direction != -1 && direction != 1)) return false;
            Orientation = (Orientation + direction + 4) % 4;
            return true;
        }
        public bool Scan()
        {
            if (!IsActive || IsRevealed || Orientation == 3 || scanned[Orientation]) return false;
            scanned[Orientation] = true;
            SealsFound++;
            return true;
        }
        public bool TryClaim(string expectedId)
        {
            if (!IsRevealed || !string.Equals(expectedId, ArtifactId, StringComparison.Ordinal)) return false;
            IsActive = false;
            return true;
        }
        public void Cancel()
        {
            IsActive = false;
            ArtifactId = null;
            Orientation = 0;
            SealsFound = 0;
            Array.Clear(scanned, 0, scanned.Length);
        }
    }
}
