using System;
using System.Globalization;

namespace TheOrderRoom.Runtime
{
    /// <summary>Stable artifact IDs; UI labels are presentation data, never persistence keys.</summary>
    public static class ArtifactPresentation
    {
        private static readonly string[] Names =
        {
            "Signal Prism", "Whisper Dial", "Silent Beacon",
            "Ink Compass", "Memory Seal", "Unwritten Page",
            "Second Hand", "Time Fragment", "Witness Lens",
            "Threshold Key", "Last Reflection", "The Impossible Collection"
        };
        public static string ForLevel(int zeroBasedLevel)
        {
            if (zeroBasedLevel < 0 || zeroBasedLevel >= Names.Length)
                throw new ArgumentOutOfRangeException(nameof(zeroBasedLevel));
            return "campaign.level." + (zeroBasedLevel + 1).ToString("D2", CultureInfo.InvariantCulture);
        }
        public static string DisplayName(string id)
        {
            if (id == null) return "Unknown";
            const string prefix = "campaign.level.";
            if (id.StartsWith(prefix, StringComparison.Ordinal) &&
                int.TryParse(id.Substring(prefix.Length), NumberStyles.None, CultureInfo.InvariantCulture, out int number) &&
                number >= 1 && number <= Names.Length && id == ForLevel(number - 1))
                return Names[number - 1];
            return "Unknown Artifact";
        }
    }
}
