using System;
namespace TheOrderRoom.Runtime
{
    /// <summary>Authored narrative identifiers and player-facing English fallback copy.</summary>
    public static class CampaignNarrative
    {
        public static readonly string[] ChapterTitles =
        {
            "THE SIGNAL ROOM", "THE LIVING ARCHIVE", "THE FRACTURED HOUR", "THE LAST DOOR"
        };
        public static readonly string[] ChapterHooks =
        {
            "A message arrives from a room that was erased from every blueprint.",
            "Every object returned to its place changes a missing person's testimony.",
            "The clock records events that have not happened yet.",
            "The final gate asks which memory deserves to remain."
        };
        public static readonly string[] StageTitles = { "DISCOVER", "RECONSTRUCT", "UNSEAL" };
        public static string Title(int zeroBasedLevel)
        {
            if (zeroBasedLevel < 0 || zeroBasedLevel >= 12) throw new ArgumentOutOfRangeException(nameof(zeroBasedLevel));
            return ChapterTitles[zeroBasedLevel / 3] + " / " + StageTitles[zeroBasedLevel % 3];
        }
        public static string Hook(int zeroBasedLevel)
        {
            if (zeroBasedLevel < 0 || zeroBasedLevel >= 12) throw new ArgumentOutOfRangeException(nameof(zeroBasedLevel));
            return ChapterHooks[zeroBasedLevel / 3];
        }
    }
}
