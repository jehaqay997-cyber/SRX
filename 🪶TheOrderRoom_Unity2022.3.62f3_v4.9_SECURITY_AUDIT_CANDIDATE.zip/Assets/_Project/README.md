# TheOrderRoom v1.2 Domain Hardening — CANDIDATE
Target Unity 6000.3.28f1. Overlay only after GUID/meta review. See Docs/DOMAIN_HARDENING_v1.2.md.
Status: static validation only, Unity compilation unverified.
