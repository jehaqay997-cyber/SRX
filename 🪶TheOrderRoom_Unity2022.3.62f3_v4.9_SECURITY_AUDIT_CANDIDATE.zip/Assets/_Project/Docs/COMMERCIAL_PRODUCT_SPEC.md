# Commercial product baseline v0.8

## Product thesis
TheOrderRoom: an interactive collection gallery. Each artifact earns a reveal and a meaningful puzzle; the gallery visually grows. The existing SUN/MOON/STAR board is one puzzle mode, not the entire product.

## Actual implementation in this archive
- Stable content-pack IDs and immutable pack descriptors in Domain.
- Default free-only entitlement provider and fail-closed paid access policy; no client-side claim of validated purchases.
- Session-only idempotent collection journal.
- NUnit tests authored for catalog access and duplicate discovery.
- Existing 12-level board, story and PNG Canvas wiring preserved from v0.7.

## NOT IMPLEMENTED (do not sell or advertise yet)
- Paid pack level content, IAP checkout, receipt verification, purchase restore, remote entitlements.
- Persistent gallery, artifact inspection, new puzzle mechanics, weekly events, server sync, telemetry.
- Mobile optimization and Unity 6000.3.28f1 compilation.

## Commercial milestones
G0: compile/import and test existing prototype in Unity 6.3.28f1.
G1: first five-minute artifact reveal and playable collection loop.
G2: 20-user moderated usability test and instrumentation with opt-in analytics.
G3: retention cohort and content-production-cost validation.
G4: purchase system, verified entitlement restoration and storefront compliance.

## KPIs (targets, not forecasts)
First-session completion >=75%; D1 >=35%; D7 >=10%; paid pack conversion measured only after purchase integration.

## Security
Do not grant paid content from a mutable local boolean. Production provider must verify store entitlements and cache cautiously with expiration and offline rules. Never store secrets in the client. Ensure idempotent purchase processing and restoration. Avoid logging user identifiers.
