# Domain hardening v1.2 — source audit

- Optional exact objective map on OrderBoard; legacy constructor retains original all-placed victory behavior. This is a compatible API extension, not a replacement of all puzzle mechanics.
- Objective construction validates complete coverage, matching tags, capacities and weights. Wrong-but-valid placement no longer wins an exact-objective board.
- Restore preserves objective definition and remains transactional on invalid snapshots.
- Reserve TRAY identifier for board location only.
- Reject revision overflow rather than silently wrapping. Tokens remain board-local, single-use, not cryptographic capabilities.
- CollectionMilestones exposes a read-only wrapper instead of mutable array.
- LevelSolvability validates input before exact search; exponential search budget still applies.

## Remaining blockers
- Campaign OrderLevels currently uses legacy constructor, so the new exact objective is not yet enabled in shipped levels.
- No new 3D artifacts, store, purchases, or production-grade persistence in this revision.
- No Unity compilation or EditMode/PlayMode execution performed. All tests are source-authored only.
- GUIDs inherited from v1.1 preserved. New GUID assigned only to new script.

## References
Unity 6000.3 Manual: Assembly Definitions, Input System, Test Framework; Microsoft Framework Design Guidelines: Collections.
