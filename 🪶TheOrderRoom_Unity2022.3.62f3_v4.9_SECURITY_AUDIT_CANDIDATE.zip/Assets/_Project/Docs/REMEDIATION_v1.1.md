# v1.1 Integrity & Gameplay — engineering report

Target Unity: 6000.3.28f1. Candidate source overlay, not a complete Unity project.

## Changes
- Runtime access policy guard on entry points (base content only). Paid pack purchase/entitlements are NOT implemented.
- Save temp-file readback before mutating primary, with recovery paths retained. File.Copy fallback is NOT atomic.
- Artifact ID length validation aligned across domain and persistence.
- Bounded undo history (64; clearing stack at limit is a deliberate prototype limitation).
- Added collection milestone domain and tests; NOT YET surfaced in Gallery UI.
- Explicit editor scene preflight; does not run on import.

## Release blockers
1. Unity compile, EditMode, PlayMode, Android/iOS device execution: UNVERIFIED.
2. Original `.meta` GUIDs must be reconciled before importing over an existing project.
3. Save integrity is SHA256 corruption detection, NOT authentication; clients can forge checksums.
4. Restore and unlock values remain client controlled. No paid entitlements should depend on local save data.
5. Missing: complete interactive collectible, gallery, paid packs, billing, analytics consent, accessibility and localized content.
6. Input System package dependency must be configured in Unity Package Manager; no manifest is bundled.
7. Narrative and mechanics still need player research and playtesting.

## Verification
ZIP CRC and manifest hash verification can be performed without Unity. Test scripts are authored, not executed.
