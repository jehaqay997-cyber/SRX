# TheOrderRoom — Story & Puzzle Bible v0.7

## Creative thesis
A mysterious restoration desk receives objects from rooms erased from history. Every correct placement restores evidence, but also changes the next room. The player is not simply sorting: they are deciding which testimony is true.

## 4 chapters / 12 stages
| Chapter | Discover | Reconstruct | Unseal | Narrative reversal |
|---|---|---|---|---|
| 1 Signal Room | 1 | 2 | 3 | The message is from the player's future self |
| 2 Living Archive | 4 | 5 | 6 | The records rewrite themselves after every solution |
| 3 Fractured Hour | 7 | 8 | 9 | The clock is a witness, not a machine |
| 4 Last Door | 10 | 11 | 12 | The player must choose what history preserves |

## Existing mechanical implementation
SUN/MOON/STAR items have identity, tag and weight; compartments enforce capacity and total weight.
Stage 3 of each chapter is a gate with two compartments per tag.
The gate uses `_A`/`_B` identifiers; scene bootstrap now creates and runtime activates the matching targets.
Puzzle completion, saving and undo remain implemented by existing systems; not runtime verified.

## Proposed distinct future mechanics (NOT IMPLEMENTED)
1. Evidence inspection: rotate an object to discover a hidden clue.
2. Contradiction board: connect a clue to a testimony, not a brute-force combination.
3. Echo reconstruction: infer the missing order of three events.
4. Gate choice: preserve one of two memories; both branches must remain fair.
5. Contextual hints: three escalating tiers without punishing accessibility.

## Originality boundaries
Study tactile feedback and progressive revelation in The Room, and deductive scene reconstruction in Golden Idol / Obra Dinn. Do not copy their characters, objects, puzzles, scripts, scenes or trade dress.

## PNG source-of-truth and display
`Art/PNG/puzzle_assets.json` maps SUN/MOON/STAR to `sun.png`, `moon.png`, `star.png`.
`Editor/OrderPngImport.cs` configures Sprite import; `Editor/OrderProjectBootstrap.cs` loads sprites and creates three UI Image nodes.
Current PNGs are HUD reference glyphs; they are NOT yet textured onto the 3D puzzle pieces.
Do not label the visual art or narrative scenes complete.

## Unity compatibility
Target Unity 6000.3.28f1. Scene creation is explicit from editor menu; no import-time scene mutation.
Unity compilation, scene PlayMode and mobile profiling remain unverified.
