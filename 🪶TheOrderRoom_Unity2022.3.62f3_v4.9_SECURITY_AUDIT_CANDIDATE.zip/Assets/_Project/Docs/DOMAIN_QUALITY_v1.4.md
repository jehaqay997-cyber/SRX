# Domain Quality Gate v1.4 — Static Candidate

## Root causes addressed
- Gate targets are now authored deterministically by item index rather than copied from an opaque feasibility witness.
- Gate clue is displayed on screen at level load; this is an explicit rule, not a hidden random solution.
- Board exposes read-only copies of exact targets for inspection/testing, not mutable internal state.
- A second Prepare attempt invalidates the previously issued capability even if the new attempt fails.
- Prepare rejects revision exhaustion before issuing a token.
- Reset no longer allocates a temporary item ID array.
- Previous gate test corrected: a generic feasible witness need not equal a deliberately authored objective.

## Known limitations
- Gate rule remains simplistic; no visual clue art or rich 3D artifact mechanic yet.
- The full game is not compiled or run in Unity 6000.3.28f1 in this environment.
- Persistence fault injection, UI integration, and commercial entitlements remain open.
- The gate objective's weights are checked by the board constructor; future authored objectives should be validated in an editor build gate.

## Complexity
- Prepare/Commit placement validation O(N) time, O(1) auxiliary space; snapshot O(N) time and space.
- Exact target validation O(N+B+N*B) in current constructor due to per-bin filtering; candidate for grouping optimization.
- Solver worst-case O(B^N) time and O(N+B) auxiliary memory, authoring-time only.

## Acceptance evidence
- ZIP CRC, SHA-256 manifest, assembly JSON, duplicate GUID and source static checks can run offline.
- NUnit EditMode tests written, NOT EXECUTED.
- Unity compile and PlayMode NOT VERIFIED.
