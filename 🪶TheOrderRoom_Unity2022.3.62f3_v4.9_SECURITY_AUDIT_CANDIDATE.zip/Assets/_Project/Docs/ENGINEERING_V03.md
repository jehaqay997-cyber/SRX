# TheOrderRoom Unity v0.3 — Engineering candidate

## Changes
- Exact offline feasibility solver for level data; worst-case O(B^N) time, O(N+B) stack/counters; node budget guards pathological input.
- Necessary capacity validation O(N+B), including tag and weight checks.
- Deterministic PNG import settings and per-file SHA-256 provenance mapping. PNG images are NOT yet displayed on the puzzle pieces.
- Reuses scene cube objects between moves to reduce allocations and instantiate/destroy churn; materials destroyed on owner teardown.
- Save input capped at 1 MiB; future schema primary/backup preserved; File.Replace preferred when supported. Fallback copy is NOT atomic under power loss. .previous is not yet integrated into automatic recovery.

## Known issues / release blockers
- No Unity executable compilation or device profiling performed.
- Existing bootstrap scene and touch interactions need PlayMode tests.
- Existing save JSON checksum detects corruption, NOT malicious tampering; embedded keys would not fix this.
- Domain proposal tokens are long integers, not cryptographically unforgeable capabilities; do not expose to untrusted clients.
- Multiple same-tag bins exact solver runs at level construction; move to Editor validation for large levels.
- PNG sprites not yet bound to runtime cube renderer; import rules only.
- No measurements of energy draw, memory leaks, FPS, or crash rate; cannot claim resolved.
