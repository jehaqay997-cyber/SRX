# v0.9 Engineering Remediation (static candidate)

Target: Unity 6000.3.28f1. **NOT UNITY-VERIFIED**.

## Implemented
- Input System path under ENABLE_INPUT_SYSTEM, legacy fallback under ENABLE_LEGACY_INPUT_MANAGER.
- InputSystemUIInputModule selected by editor bootstrap when ENABLE_INPUT_SYSTEM is defined.
- UI pointer consumption uses supplied pointer ID. Requires on-device touch test.
- Save reader checks primary, .bak, .previous in that order; future schema fails closed.
- Save fallback refuses to overwrite an invalid primary; non-atomic fallback is documented.
- Size checks before save serialization writes.
- Pure C# idempotent ArtifactLedger and two NUnit tests (not executed).
- .meta GUIDs generated deterministically for all shipped source/assets and folders.
- Runtime null guards for some game actions.

## Known gaps / no unsupported claims
- New Input System package must be installed through Unity Package Manager; no package manifest is forced onto existing projects.
- Save fallback remains non-atomic on platforms lacking File.Replace. Needs platform-specific transactional implementation and fault injection.
- Existing CollectionProgress is not yet persisted. ArtifactLedger is not integrated into saved game or UI.
- Paid content has definitions only, no levels, checkout, ownership verification, store integration or server authority.
- Board puzzle still largely tag sorting; no novel playable collectible puzzle implemented.
- No Unity compiler or editor available here: no Unity build, EditMode, PlayMode or Android validation.
- Do not overwrite existing Unity .meta files blindly: reconcile GUIDs with the real project.

## Required next gates
1. Unity 6000.3.28f1 clean import, Input System package, compile, inspect Console.
2. Execute EditMode and PlayMode tests; tap UI vs world regression.
3. Build a novel vertical slice and instrument completion/retention before monetization.
