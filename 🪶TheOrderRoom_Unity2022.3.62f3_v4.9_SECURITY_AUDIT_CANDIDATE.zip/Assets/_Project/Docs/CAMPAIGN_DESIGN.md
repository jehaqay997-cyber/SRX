# TheOrderRoom — Campaign v0.6

Four chapters, three levels per chapter (12 levels). Levels 3, 6, 9 and 12 are gate puzzles. The final gate is a campaign completion marker; there is no additional chapter yet.

1. **The Observatory** (levels 1–3): learn SUN / MOON / STAR placement, gate introduces split compartments.
2. **The Archive** (levels 4–6): more pieces and heavier weights, gate requires planning around capacity.
3. **The Clock Hall** (levels 7–9): denser sorting, gate has paired compartments per tag.
4. **The Inner Vault** (levels 10–12): largest sets and final gate.

The gate is a **rules/data milestone**, not a rendered gate animation, separate scene, or monetization purchase. All levels use the same proven placement rules. The levels are deterministic and validate with the exact solver. These are authored procedural configurations, not 12 independently art-directed puzzles.

## Monetization guardrails

No ad SDK, IAP, tracking, telemetry upload, or payment processing is included. Future monetization must use store-authorized APIs, consent where required, restore purchases, server verification for high-value entitlements, and an offline playable core. No pay-to-win requirement or deceptive timers.

## Runtime limits

- Solver is for level creation/validation; do not run it per frame.
- `OrderBoard.Prepare` retains at most one pending capability.
- The save store uses SHA-256 to detect accidental corruption, not authentication.
- The fallback save copy remains non-atomic on unsupported platforms; interrupted writes require device tests.
- Camera, UI, and rendering remain those of v0.5; do not claim production quality.
