# Safe Mode risk audit — v0.5

## Static changes
- Removed InitializeOnLoadMethod automatic scene creation during asset import.
- Scene creation is manual via `TheOrderRoom/Create Integrated Scene (Non-Destructive)` only.
- Scene Build Settings are not overwritten if existing entries are present.
- Persisted editor-created materials as `.mat` assets, rather than embedding unowned temporary material objects.
- Puzzle pieces are parented under a dedicated `Pieces` node, separating them from static scenery.
- Legacy input calls are guarded by `ENABLE_LEGACY_INPUT_MANAGER`; when only the new Input System is active, this fallback is disabled until an Input System adapter is implemented.
- Shader resolution failure is explicit rather than passing a null shader to `new Material`.

## Known release blockers
- Unity editor version and package compatibility have not been tested.
- New Input System support is not implemented. Choose Input Handling = Both or Input Manager (Old) for current tap control.
- UI uses `UnityEngine.UI` and built-in LegacyRuntime.ttf; availability depends on installed UI package and editor version.
- Domain invariants, save crash consistency, touch gestures, scene serialization, PlayMode and energy usage are NOT verified.
- `OrderGame.Refresh()` still scans items repeatedly and is not optimized for large boards.
- Safe Mode prevention cannot be guaranteed by static checks. Capture Editor.log/Console on first import.
