# TheOrderRoom Unity v0.2 — Engineering Status

## Source provenance
Derived from the actual v0.1 Unity ZIP found in this conversation, not from a running Unity project. The three PNG symbol files are carried over byte-for-byte. All C# source is an uncompiled candidate.

## Implemented source
- Pure C# puzzle board: unique item IDs, location map, capacity/weight/tag validation, revisioned Prepare/Commit, atomic restore, reset, completion.
- Three deterministic prototype levels, progression gate, one-level-at-a-time unlock.
- Save envelope with SHA-256 accidental-corruption checksum, temp-file staging and previous valid backup, schema v1 rejection of future versions.
- Undo of successful moves (in-memory only); Reset and Next controls.
- Scene bootstrap: camera, directional light, table, 4 targets, canvas, event system, persistent serialized UI button listeners, 3 PNG sprites.
- Touch and mouse selection; UI interception through EventSystem.
- Seven EditMode source tests (not executed).

## Known limitations / blockers
- Unity version not supplied. No Unity Editor or C# compiler available in execution environment. Compilation and runtime **UNVERIFIED**.
- Save SHA-256 is not a secret MAC; it detects accidental corruption but not adversarial tampering.
- Save commit uses File.Delete then File.Move, which is NOT atomic across a crash window; backup recovery is best effort, and a crash after deleting the primary may leave only backup. No production-grade transactional guarantee.
- Scene bootstrap is intended for a fresh empty Unity project, with legacy Input Manager enabled (or Active Input Handling = Both). No Input System package requirement.
- The prototype uses tap-to-select/tap-to-place; true drag-and-drop, multi-touch gesture arbitration, audio, accessibility, localization, mobile build, art polish and performance profiling are NOT implemented.
- Generated material assets at edit time may be transient; scene render after editor reload must be verified. A production upgrade should persist materials as .mat assets.
- Unity 6 may not include the LegacyRuntime.ttf builtin font path in all editor configurations. Verify with actual editor.
- Do not copy this candidate into an existing project without version control or a backup.

## Import
1. Create a fresh Unity **3D Built-in Render Pipeline** project. Use the installed editor version; do not force 2022.3.
2. Close the editor. Copy `Assets/_Project` into the project `Assets` folder.
3. Reopen Unity and wait for import/compilation. Ensure `Active Input Handling` supports Input Manager (Old or Both).
4. If not created automatically, choose `TheOrderRoom > Create Prototype Scene (Non-Destructive)`.
5. Open `Assets/_Project/Scenes/Main.unity` and press Play.
6. Record Console errors, if any; only then mark compilation/runtime as verified.

## Validation levels
- ZIP integrity: verified by Python zipfile.testzip after packaging.
- Source inventory / SHA-256 manifest: verified in container.
- Unity compilation: unverified.
- EditMode execution: unverified.
- PlayMode: unverified.
- iOS build: unverified.

## Next priority
P0: editor compile and scene smoke test; P1: persist .mat assets, true pointer drag-and-drop, save power-loss safety, undo across sessions; P2: scalable level content data and test coverage; P3: mobile QA and visual design.
