# Domain root-cause remediation v1.3

## Confirmed defect
Previously all 12 levels instantiated `OrderBoard` without exact targets, even though v1.2 supported them. Gate stages therefore accepted any tag-compatible complete assignment.

## Changes
- Exact solver now returns a deterministic, immutable assignment witness; `HasSolution` delegates to it.
- Gate levels (3, 6, 9, 12) pass the validated witness as `exactTargets` to `OrderBoard`.
- All other levels retain existing free placement behavior to avoid changing onboarding without playtesting.
- Solver materializes inputs once to support single-use enumerables.
- New regression tests cover witness validity, impossible packing, gate completion, malformed definitions.
- `Items` and `Compartments` enumerate snapshots instead of exposing mutable internal collection objects.

## Critical limitations
- An arbitrary exact witness is not a *designed* puzzle; authoring clues that communicate the target is NOT implemented. Until clues exist, gate stages can be unfair or indistinguishable. This is a design blocker.
- Gate witness is recalculated from deterministic definitions; authoring content is not serialized in a content catalog.
- Unity Editor compilation and tests NOT executed.
- No changes to persistence atomicity, monetization, art pipeline, gallery or commercial instrumentation.

## Complexity
- Solver worst-case O(B^N) time and O(N+B) auxiliary space, plus O(N) witness output.
- Board snapshot enumeration O(N+B) allocations when called; use sparingly in hot paths.

## Status
STATIC_VERIFIED only after archive and manifest validation; UNITY_UNVERIFIED; NOT_RELEASE_READY.
