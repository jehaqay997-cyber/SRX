using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SavePruningSafetyTests
    {
        private static bool MayPrune(bool valid, int newer)
        {
            var method = typeof(OrderSaveStore).GetMethod("MayPruneGeneration", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.IsNotNull(method);
            return (bool)method.Invoke(null, new object[] { valid, newer });
        }

        [Test] public void CorruptGeneration_IsNeverPruned() => Assert.IsFalse(MayPrune(false, 100));
        [Test] public void OneRecoveryCopy_IsInsufficient() => Assert.IsFalse(MayPrune(true, 1));
        [Test] public void ZeroRecoveryCopies_IsInsufficient() => Assert.IsFalse(MayPrune(true, 0));
        [Test] public void TwoVerifiedNewerCopies_PermitPruning() => Assert.IsTrue(MayPrune(true, 2));
    }
}
