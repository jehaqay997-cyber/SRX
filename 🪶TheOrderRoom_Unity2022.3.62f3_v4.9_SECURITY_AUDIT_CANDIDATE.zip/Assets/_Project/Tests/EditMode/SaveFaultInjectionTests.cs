using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    [NonParallelizable]
    public sealed class SaveFaultInjectionTests
    {
        private string directory;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "TheOrderRoom_FaultTest_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            OrderSaveStore.TestStorageDirectory = directory;
            OrderSaveStore.TestFaultInjector = null;
        }

        [TearDown]
        public void TearDown()
        {
            OrderSaveStore.ResetTestSeams();
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        private static SaveDocument Document(int unlockedLevel = 0)
        {
            var board = OrderLevels.Create(0);
            return new SaveDocument
            {
                level = 0,
                unlockedLevel = unlockedLevel,
                locations = board.Snapshot().Select(pair => new SaveEntry
                {
                    itemId = pair.Key,
                    destination = pair.Value
                }).ToList(),
                discoveredArtifacts = new List<string>()
            };
        }

        private static void SaveInitial()
        {
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(Document(), -1, out long generation, out string reason), reason);
            Assert.AreEqual(0L, generation);
        }

        [TestCase("AfterTemporaryFlush")]
        [TestCase("BeforePublish")]
        public void CrashBeforePublicationPreservesPreviousGeneration(string checkpoint)
        {
            SaveInitial();
            OrderSaveStore.TestFaultInjector = point =>
            {
                if (point == checkpoint) throw new IOException("Simulated crash at " + point);
            };
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out _, out _));
            OrderSaveStore.TestFaultInjector = null;
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument recovered, out string reason), reason);
            Assert.AreEqual(0L, recovered.generation);
            Assert.AreEqual(0, recovered.unlockedLevel);
        }

        [Test]
        public void CrashAfterPublicationRecoversCommittedGenerationWithoutRetry()
        {
            SaveInitial();
            OrderSaveStore.TestFaultInjector = point =>
            {
                if (point == "AfterPublish") throw new IOException("Simulated post-commit crash");
            };
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out _, out string failure));
            StringAssert.Contains("Commit status unknown", failure);
            OrderSaveStore.TestFaultInjector = null;
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument recovered, out string reason), reason);
            Assert.AreEqual(1L, recovered.generation);
            Assert.AreEqual(1, recovered.unlockedLevel);
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out _, out string stale));
            StringAssert.Contains("Stale", stale);
        }

        [Test]
        public void CleanupFailureDoesNotConvertCommittedSaveIntoFailure()
        {
            SaveInitial();
            OrderSaveStore.TestFaultInjector = point =>
            {
                if (point == "BeforePrune") throw new IOException("Simulated cleanup failure");
            };
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out long generation, out string reason), reason);
            Assert.AreEqual(1L, generation);
            OrderSaveStore.TestFaultInjector = null;
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument recovered, out reason), reason);
            Assert.AreEqual(1, recovered.unlockedLevel);
        }

        [Test]
        public void CorruptedNewestJournalRecoversPreviousValidGeneration()
        {
            SaveInitial();
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out _, out string reason), reason);
            string newest = Directory.GetFiles(directory, "*.g*.json").OrderBy(x => x, StringComparer.Ordinal).Last();
            File.WriteAllText(newest, "{\"payload\":\"truncated\"}");
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument recovered, out reason), reason);
            Assert.AreEqual(0L, recovered.generation);
            Assert.AreEqual(0, recovered.unlockedLevel);
        }

        [Test]
        public void AllCorruptGenerationsMustNotBeOverwritten()
        {
            SaveInitial();
            string only = Directory.GetFiles(directory, "*.g*.json").Single();
            File.WriteAllText(only, "invalid");
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out _));
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(), -1, out _, out _));
            Assert.AreEqual("invalid", File.ReadAllText(only));
        }

        [Test]
        public void InvalidDocumentDoesNotCreateStorageDirectoryOrWriterLock()
        {
            string unused = Path.Combine(directory, "must-not-exist");
            OrderSaveStore.TestStorageDirectory = unused;
            var invalid = Document();
            invalid.schemaVersion = 999;
            Assert.IsFalse(OrderSaveStore.TrySave(invalid, out _));
            Assert.IsFalse(Directory.Exists(unused));
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(invalid, -1, out _, out _));
            Assert.IsFalse(Directory.Exists(unused));
        }

        [Test]
        public void FutureSchemaBlocksRecoveryAndPreservesAllExistingSaveBytes()
        {
            SaveInitial();
            var future = Document();
            future.schemaVersion = 999;
            string payload = UnityEngine.JsonUtility.ToJson(future);
            string checksum;
            using (var hash = System.Security.Cryptography.SHA256.Create())
                checksum = Convert.ToBase64String(hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(payload)));
            string futurePath = Path.Combine(directory, "the_order_room_v1.json");
            File.WriteAllText(futurePath, UnityEngine.JsonUtility.ToJson(
                new SaveEnvelope { payload = payload, checksum = checksum }));
            var before = Directory.GetFiles(directory).ToDictionary(path => path, File.ReadAllBytes);
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out string reason));
            Assert.AreEqual("Unsupported save version", reason);
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(), 0, out _, out _));
            CollectionAssert.AreEquivalent(before.Keys, Directory.GetFiles(directory));
            foreach (var pair in before) CollectionAssert.AreEqual(pair.Value, File.ReadAllBytes(pair.Key));
        }

        [Test]
        public void ExceptionDuringPublicVerificationReportsUnknownCommitAndRecoversPublishedState()
        {
            SaveInitial();
            OrderSaveStore.TestFaultInjector = checkpoint =>
            {
                if (checkpoint == "BeforeSessionVerification") throw new IOException("Verification scan failed.");
            };
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(1), 0, out _, out string reason));
            StringAssert.StartsWith("Commit status unknown", reason);
            OrderSaveStore.TestFaultInjector = null;
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument recovered, out reason), reason);
            Assert.AreEqual(1L, recovered.generation);
        }

        [Test]
        public void ModernCampaignRoundTripPreservesItsRulesVersion()
        {
            var doc = Document();
            doc.schemaVersion = 2;
            doc.contentVersion = OrderLevels.CurrentContentVersion;
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(doc, -1, out _, out string reason), reason);
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument loaded, out reason), reason);
            Assert.AreEqual(2, loaded.schemaVersion);
            Assert.AreEqual(OrderLevels.CurrentContentVersion, loaded.contentVersion);
        }

        [Test]
        public void ModernCampaignCannotSkipRewardsToUnlockFutureRooms()
        {
            var doc = Document(2);
            doc.schemaVersion = 2;
            doc.contentVersion = OrderLevels.CurrentContentVersion;
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(doc, -1, out _, out _));
            Assert.IsEmpty(Directory.GetFiles(directory, "*.g*.json"));
        }

        [Test]
        public void SavedBoardIsValidatedAgainstItsOwnCampaignTopology()
        {
            var definition = CampaignPuzzles.Get(1);
            var doc = new SaveDocument
            {
                schemaVersion = 2, contentVersion = OrderLevels.CurrentContentVersion,
                level = 1, unlockedLevel = 1,
                discoveredArtifacts = new List<string> { ArtifactPresentation.ForLevel(0) },
                locations = definition.Solution.Select(pair => new SaveEntry { itemId = pair.Key, destination = pair.Value }).ToList()
            };
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(doc, -1, out _, out string reason), reason);
            Assert.IsTrue(OrderSaveStore.TryLoad(out SaveDocument loaded, out reason), reason);
            Assert.IsTrue(OrderSaveStore.ValidBoardSnapshot(loaded));
            loaded.schemaVersion = 1; loaded.contentVersion = 0;
            Assert.IsFalse(OrderSaveStore.ValidBoardSnapshot(loaded), "Modern SUN_A/B locations must not be interpreted as legacy SUN.");
        }

        [Test]
        public void FutureContentRevisionBlocksLegacyRecoveryWithoutChangingFiles()
        {
            SaveInitial();
            var future = Document(); future.schemaVersion = 2; future.contentVersion = 999;
            string payload = UnityEngine.JsonUtility.ToJson(future);
            string checksum;
            using (var hash = System.Security.Cryptography.SHA256.Create())
                checksum = Convert.ToBase64String(hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(payload)));
            string path = Path.Combine(directory, "the_order_room_v1.json");
            string bytes = UnityEngine.JsonUtility.ToJson(new SaveEnvelope { payload = payload, checksum = checksum });
            File.WriteAllText(path, bytes);
            Assert.IsFalse(OrderSaveStore.TryLoad(out _, out string reason));
            Assert.AreEqual("Unsupported save version", reason);
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(), 0, out _, out _));
            Assert.AreEqual(bytes, File.ReadAllText(path));
        }

        [Test]
        public void FutureOnlyStoreDoesNotCreateWriterLockOrNewFiles()
        {
            var future = Document(); future.schemaVersion = 999;
            string payload = UnityEngine.JsonUtility.ToJson(future);
            string checksum;
            using (var hash = System.Security.Cryptography.SHA256.Create())
                checksum = Convert.ToBase64String(hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(payload)));
            string path = Path.Combine(directory, "the_order_room_v1.json");
            string bytes = UnityEngine.JsonUtility.ToJson(new SaveEnvelope { payload = payload, checksum = checksum });
            File.WriteAllText(path, bytes);
            Assert.IsFalse(OrderSaveStore.TrySave(Document(), out _));
            Assert.IsFalse(OrderSaveStore.TrySaveIfCurrent(Document(), -1, out _, out _));
            CollectionAssert.AreEquivalent(new[] { path }, Directory.GetFiles(directory));
            Assert.AreEqual(bytes, File.ReadAllText(path));
        }

        [Test]
        public void IsolatedFaultTestsDoNotWriteToApplicationSaveDirectory()
        {
            Assert.IsTrue(OrderSaveStore.TrySaveIfCurrent(Document(), -1, out _, out string reason), reason);
            Assert.AreEqual(1, Directory.GetFiles(directory, "*.g*.json").Length);
        }
    }
}
