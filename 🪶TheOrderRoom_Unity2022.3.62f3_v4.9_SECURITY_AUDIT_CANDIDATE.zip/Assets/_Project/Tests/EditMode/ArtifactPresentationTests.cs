using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactPresentationTests
    {
        [Test] public void EveryCampaignLevelHasStableUniqueArtifact()
        {
            var ids = new System.Collections.Generic.HashSet<string>();
            for (int i = 0; i < OrderLevels.Count; i++)
            {
                var id = ArtifactPresentation.ForLevel(i);
                Assert.IsTrue(ids.Add(id));
                Assert.AreNotEqual("Unknown Artifact", ArtifactPresentation.DisplayName(id));
            }
        }
        [Test] public void UnknownIdentifiersAreNotPresentedAsOwnedContent()
        {
            Assert.AreEqual("Unknown Artifact", ArtifactPresentation.DisplayName("campaign.level.99"));
            Assert.AreEqual("Unknown Artifact", ArtifactPresentation.DisplayName("campaign.level.01.extra"));
        }
        [Test] public void OutOfRangeLevelRejected()
        {
            Assert.Throws<System.ArgumentOutOfRangeException>(() => ArtifactPresentation.ForLevel(-1));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => ArtifactPresentation.ForLevel(OrderLevels.Count));
        }
    }
}
