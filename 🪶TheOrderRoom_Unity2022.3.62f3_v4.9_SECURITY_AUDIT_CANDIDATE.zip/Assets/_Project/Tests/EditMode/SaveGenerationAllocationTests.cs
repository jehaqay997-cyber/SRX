using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveGenerationAllocationTests
    {
        private static long Next(long valid, long allocated)
        {
            var method = typeof(OrderSaveStore).GetMethod("NextGeneration", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.IsNotNull(method);
            return (long)method.Invoke(null, new object[] { valid, allocated });
        }

        [Test] public void EmptyJournal_StartsAtZero() => Assert.AreEqual(0L, Next(-1, -1));
        [Test] public void CorruptHigherFilename_IsNeverReused() => Assert.AreEqual(19L, Next(4, 18));
        [Test] public void ValidHigherPayload_Wins() => Assert.AreEqual(20L, Next(19, 8));
        [Test] public void ExhaustedGeneration_IsRejected()
        {
            var method = typeof(OrderSaveStore).GetMethod("NextGeneration", BindingFlags.Static | BindingFlags.NonPublic);
            var ex = Assert.Throws<TargetInvocationException>(() => method.Invoke(null, new object[] { 2L, long.MaxValue }));
            Assert.IsInstanceOf<OverflowException>(ex.InnerException);
        }
    }
}
