using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests
{
    public sealed class LevelRulesTests
    {
        [TestCase(0)] [TestCase(1)] [TestCase(2)]
        public void BuiltInLevelsAreSolvable(int level) => Assert.IsNotNull(OrderLevels.Create(level));
        [Test] public void RejectsInsufficientCapacity() => Assert.Throws<System.ArgumentException>(() =>
            LevelRules.Validate(new [] { new Item("A", "SUN", 3), new Item("B", "SUN", 3) },
                new [] { new Compartment("C", "SUN", 1, 5) }));
        [Test] public void RejectsImpossiblePacking() => Assert.IsFalse(LevelSolvability.HasSolution(
            new [] { new Item("A", "SUN", 4), new Item("B", "SUN", 4), new Item("C", "SUN", 4) },
            new [] { new Compartment("X", "SUN", 2, 6), new Compartment("Y", "SUN", 2, 6) }));
        [Test] public void RejectsInvalidLevelIndex() => Assert.Throws<System.ArgumentOutOfRangeException>(() => OrderLevels.Create(-1));
    }
}
