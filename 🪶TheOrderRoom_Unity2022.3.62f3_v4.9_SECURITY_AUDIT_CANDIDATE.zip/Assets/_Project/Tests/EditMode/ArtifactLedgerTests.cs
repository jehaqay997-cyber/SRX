using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactLedgerTests
    {
        [Test] public void DuplicateDiscoveryIsIdempotent()
        {
            var ledger = new ArtifactLedger();
            Assert.IsTrue(ledger.Discover("artifact.1"));
            Assert.IsFalse(ledger.Discover("artifact.1"));
            Assert.AreEqual(1, ledger.Count);
        }
        [Test] public void InvalidRestoreDoesNotMutateExistingState()
        {
            var ledger = new ArtifactLedger();
            ledger.Discover("original");
            Assert.IsFalse(ledger.TryRestore(new [] { "valid", "valid" }));
            Assert.IsTrue(ledger.Contains("original"));
        }
    }
}
