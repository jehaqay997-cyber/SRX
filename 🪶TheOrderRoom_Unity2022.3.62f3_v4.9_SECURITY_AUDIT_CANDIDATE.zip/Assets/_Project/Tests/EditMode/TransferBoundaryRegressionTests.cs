using System;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class TransferBoundaryRegressionTests
    {
        private static OrderBoard Create() => new OrderBoard(
            new[] { new Item("item", "SUN", 1) },
            new[] { new Compartment("target", "SUN", 1, 1) });

        [TestCase(null, "target")]
        [TestCase("", "target")]
        [TestCase(" ", "target")]
        [TestCase("item", null)]
        [TestCase("item", "")]
        [TestCase("item", " ")]
        public void InvalidTransferIdentifiersReturnFailureWithoutMutation(string item, string target)
        {
            var board = Create();
            Assert.IsFalse(board.Prepare(item, target, board.Revision, out Guid ticket, out string error));
            Assert.AreEqual(Guid.Empty, ticket);
            Assert.IsNotEmpty(error);
            Assert.AreEqual(0L, board.Revision);
            Assert.AreEqual(OrderBoard.Tray, board.Location("item"));
        }

        [Test]
        public void TicketFromAnotherBoardCannotCommitPendingTransfer()
        {
            var first = Create();
            var second = Create();
            Assert.IsTrue(first.Prepare("item", "target", 0, out Guid firstTicket, out _));
            Assert.IsTrue(second.Prepare("item", "target", 0, out Guid secondTicket, out _));
            Assert.AreNotEqual(firstTicket, secondTicket);
            Assert.IsFalse(second.Commit(firstTicket, out _));
            Assert.AreEqual(OrderBoard.Tray, second.Location("item"));
            Assert.IsTrue(second.Commit(secondTicket, out _));
        }

        [Test]
        public void NullRestoreDestinationReturnsFailureAtomically()
        {
            var board = Create();
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "item", null } }));
            Assert.AreEqual(0L, board.Revision);
            Assert.AreEqual(OrderBoard.Tray, board.Location("item"));
        }

        [Test]
        public void RevisionExhaustionDoesNotWrapOrMutate()
        {
            var board = Create();
            var setter = typeof(OrderBoard).GetProperty("Revision").GetSetMethod(true);
            setter.Invoke(board, new object[] { long.MaxValue });
            Assert.IsFalse(board.Prepare("item", "target", long.MaxValue, out _, out _));
            Assert.Throws<InvalidOperationException>(() => board.Reset());
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "item", "target" } }));
            Assert.AreEqual(long.MaxValue, board.Revision);
            Assert.AreEqual(OrderBoard.Tray, board.Location("item"));
        }
    }
}
