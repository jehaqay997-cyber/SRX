using System;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SessionIntegrityTests
    {
        [Test] public void InvalidArtifactRestoreDoesNotEraseExistingLedger()
        {
            var ledger = new ArtifactLedger();
            ledger.Discover("campaign.level.01");
            Assert.IsFalse(ledger.TryRestore(new[] { "duplicate", "duplicate" }));
            Assert.IsTrue(ledger.Contains("campaign.level.01"));
        }
        [Test] public void LevelBoardRejectsUnknownItemDuringRestore()
        {
            var board = OrderLevels.Create(0);
            var saved = new System.Collections.Generic.Dictionary<string,string>();
            foreach (var entry in board.Snapshot()) saved.Add(entry.Key, entry.Value);
            saved.Add("unknown", OrderBoard.Tray);
            Assert.IsFalse(board.Restore(saved));
        }
    }
}
