using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveJournalQuotaTests
    {
        private static object Invoke(string name, params object[] arguments)
        {
            var method = typeof(OrderSaveStore).GetMethod(name, BindingFlags.NonPublic | BindingFlags.Static);
            Assert.IsNotNull(method, name);
            return method.Invoke(null, arguments);
        }

        [TestCase(0, true)]
        [TestCase(32, true)]
        [TestCase(33, false)]
        [TestCase(-1, false)]
        public void InvalidJournalBudget_IsBounded(int count, bool expected)
            => Assert.AreEqual(expected, Invoke("WithinInvalidGenerationBudget", count));

        [TestCase(0, 0)]
        [TestCase(7, 0)]
        [TestCase(8, 0)]
        [TestCase(9, 1)]
        [TestCase(20, 12)]
        public void Retention_CountsOnlyValidGenerations(int count, int expected)
            => Assert.AreEqual(expected, Invoke("RemovableValidGenerationCount", count));
    }
}
