using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveHardeningTests
    {
        [Test] public void RejectDuplicateItemLocations()
        {
            var doc = new SaveDocument { level = 0, unlockedLevel = 0,
                locations = new List<SaveEntry> {
                    new SaveEntry { itemId = "item", destination = "TRAY" },
                    new SaveEntry { itemId = "item", destination = "TRAY" } } };
            Assert.IsFalse(OrderSaveStore.TrySave(doc, out _));
        }

        [Test] public void RejectInvalidLocationIdentifiers()
        {
            var doc = new SaveDocument { level = 0, unlockedLevel = 0,
                locations = new List<SaveEntry> { new SaveEntry { itemId = " ", destination = "TRAY" } } };
            Assert.IsFalse(OrderSaveStore.TrySave(doc, out _));
        }

        [Test] public void RejectNullLocationEntries()
        {
            var doc = new SaveDocument { level = 0, unlockedLevel = 0,
                locations = new List<SaveEntry> { null } };
            Assert.IsFalse(OrderSaveStore.TrySave(doc, out _));
        }
    }
}
