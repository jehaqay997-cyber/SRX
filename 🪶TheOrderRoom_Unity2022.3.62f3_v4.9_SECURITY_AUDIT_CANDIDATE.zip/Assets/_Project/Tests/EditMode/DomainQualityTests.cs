#if UNITY_INCLUDE_TESTS
using System;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests
{
    public sealed class DomainQualityTests
    {
        [Test]
        public void FailedSecondPrepareInvalidatesPreviouslyIssuedCapability()
        {
            var b = new OrderBoard(new[] { new Item("I", "SUN", 1) }, new[] { new Compartment("A", "SUN", 1, 1) });
            Assert.IsTrue(b.Prepare("I", "A", b.Revision, out Guid token, out _));
            Assert.IsFalse(b.Prepare("UNKNOWN", "A", b.Revision, out _, out _));
            Assert.IsFalse(b.Commit(token, out _));
            Assert.AreEqual(OrderBoard.Tray, b.Location("I"));
        }
        [Test]
        public void LegacyAuthoredGateObjectivesArePublicAndConsistentWithClue()
        {
            for (int level = 2; level < OrderLevels.Count; level += 3)
            {
                var b = OrderLevels.Create(level, 0);
                Assert.IsNotNull(b.ExactTargets);
                foreach (var group in b.Items.GroupBy(x => x.Tag))
                {
                    var ordered = group.OrderBy(x => int.Parse(x.Id.Substring(x.Id.LastIndexOf('_') + 1))).ToArray();
                    int split = (ordered.Length + 1) / 2;
                    for (int i = 0; i < ordered.Length; i++)
                        Assert.AreEqual(group.Key + (i < split ? "_A" : "_B"), b.ExactTargets[ordered[i].Id]);
                }
                foreach (var pair in b.ExactTargets) Assert.IsTrue(b.Move(pair.Key, pair.Value, out _));
                Assert.IsTrue(b.Solved);
            }
        }
        [Test]
        public void ExactTargetsCannotBeMutatedFromOutside()
        {
            var b = OrderLevels.Create(2);
            var copy = b.ExactTargets as System.Collections.Generic.IDictionary<string,string>;
            Assert.Throws<NotSupportedException>(() => copy[copy.Keys.First()] = "TRAY");
        }
    }
}
#endif
