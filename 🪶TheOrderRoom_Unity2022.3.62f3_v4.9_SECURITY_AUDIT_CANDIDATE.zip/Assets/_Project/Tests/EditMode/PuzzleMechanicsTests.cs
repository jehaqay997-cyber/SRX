using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class PuzzleMechanicsTests
    {
        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        public void EveryAuthoredPuzzleHasLegalMoveByMoveSolution(int level)
        {
            var definition = CampaignPuzzles.Get(level);
            var board = definition.CreateBoard();
            var remaining = definition.Items.Select(x => x.Id).ToList();
            while (remaining.Count > 0)
            {
                int before = remaining.Count;
                foreach (string id in remaining.ToArray())
                    if (board.Move(id, definition.Solution[id], out _)) remaining.Remove(id);
                Assert.Less(remaining.Count, before, "No legal continuation in level " + level);
            }
            Assert.IsTrue(board.Solved);
            foreach (var bin in definition.Compartments)
            {
                Assert.LessOrEqual(board.CountIn(bin.Id), bin.Capacity);
                Assert.LessOrEqual(board.WeightIn(bin.Id), bin.MaxWeight);
            }
        }

        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        public void HintIsLegalAndDoesNotMutateBoardOrPendingTicket(int level)
        {
            var definition = CampaignPuzzles.Get(level);
            var board = definition.CreateBoard();
            Assert.IsTrue(PuzzleHint.TrySuggest(definition, board, out string id, out string target));
            Assert.IsTrue(board.Prepare(id, target, board.Revision, out Guid ticket, out _));
            long revision = board.Revision;
            Assert.IsTrue(PuzzleHint.TrySuggest(definition, board, out _, out _));
            Assert.AreEqual(revision, board.Revision);
            Assert.IsTrue(board.Commit(ticket, out _));
        }

        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        public void RepeatedHintsSolveFreshPuzzleWithinOnePlacementPerItem(int level)
        {
            var definition = CampaignPuzzles.Get(level);
            var board = definition.CreateBoard();
            for (int step = 0; step < definition.Items.Count; step++)
            {
                Assert.IsTrue(PuzzleHint.TrySuggest(definition, board, out string id, out string target));
                Assert.IsTrue(board.Move(id, target, out string error), error);
            }
            Assert.IsTrue(board.Solved);
            Assert.IsFalse(PuzzleHint.TrySuggest(definition, board, out _, out _));
        }

        [Test]
        public void RestoreChecksWholeSnapshotRatherThanAlphabeticMoveOrder()
        {
            var board = new OrderBoard(new[] { new Item("A-dependent", "X", 1), new Item("Z-key", "X", 1) },
                new[] { new Compartment("bin", "X", 2, 2) }, null,
                new PuzzleRule[] { new PrerequisiteRule("A-dependent", "Z-key") });
            Assert.IsFalse(board.Move("A-dependent", "bin", out _));
            Assert.IsTrue(board.Restore(new Dictionary<string, string>
                { { "A-dependent", "bin" }, { "Z-key", "bin" } }));
            Assert.IsTrue(board.Solved);
            Assert.IsFalse(board.Move("Z-key", OrderBoard.Tray, out _));
        }

        [Test]
        public void WeightQuotaRejectsOverflowButRequiresExactCompletion()
        {
            var board = new OrderBoard(new[] { new Item("one", "X", 1), new Item("two", "X", 2) },
                new[] { new Compartment("a", "X", 2, 3), new Compartment("b", "X", 2, 3) }, null,
                new PuzzleRule[] { new WeightQuotaRule("a", 1), new WeightQuotaRule("b", 2) });
            Assert.IsFalse(board.Move("two", "a", out _));
            Assert.IsTrue(board.Move("one", "a", out _));
            Assert.IsFalse(board.Solved);
            Assert.IsTrue(board.Move("two", "b", out _));
            Assert.IsTrue(board.Solved);
        }

        [Test]
        public void SeparationAndBalanceFailuresLeaveRevisionAndIndexesUnchanged()
        {
            var board = new OrderBoard(new[] { new Item("one", "X", 1), new Item("two", "X", 1) },
                new[] { new Compartment("a", "X", 2, 2), new Compartment("b", "X", 2, 2) }, null,
                new PuzzleRule[] { new SeparatedPairRule("one", "two"), new CountBalanceRule("a", "b") });
            Assert.IsTrue(board.Move("one", "a", out _));
            long revision = board.Revision;
            Assert.IsFalse(board.Move("two", "a", out _));
            Assert.AreEqual(revision, board.Revision);
            Assert.AreEqual(1, board.CountIn("a"));
            Assert.AreEqual(1L, board.WeightIn("a"));
            Assert.IsTrue(board.Move("two", "b", out _));
            Assert.IsTrue(board.Solved);
        }

        [Test]
        public void LegacyCampaignKeepsItsOriginalBinTopology()
        {
            Assert.AreEqual(3, OrderLevels.Create(1, 0).Compartments.Count());
            Assert.AreEqual(4, OrderLevels.Create(1, OrderLevels.CurrentContentVersion).Compartments.Count());
            Assert.Throws<ArgumentOutOfRangeException>(() => OrderLevels.Create(0, 99));
        }

        [Test]
        public void AlternativeArrangementIsAcceptedWithoutRequiringAuthoredWitness()
        {
            var definition = CampaignPuzzles.Get(10);
            Assert.IsFalse(definition.ExactIdentityRequired);
            var alternative = new Dictionary<string, string>(definition.Solution);
            string first = alternative["SUN_1"];
            alternative["SUN_1"] = alternative["SUN_4"];
            alternative["SUN_4"] = first;
            var board = definition.CreateBoard();
            Assert.IsTrue(board.Restore(alternative));
            Assert.IsTrue(board.Solved);
        }

        [Test]
        public void ConcurrentMovesPreserveRevisionAndCapacityIndexes()
        {
            var board = new OrderBoard(Enumerable.Range(0, 4).Select(i => new Item("I" + i, "X", 1)),
                new[] { new Compartment("L", "X", 4, 4), new Compartment("R", "X", 4, 4) });
            int successful = 0;
            System.Threading.Tasks.Parallel.For(0, 8, worker =>
            {
                var random = new Random(9000 + worker);
                string[] destinations = { OrderBoard.Tray, "L", "R" };
                for (int i = 0; i < 500; i++)
                    if (board.Move("I" + random.Next(4), destinations[random.Next(3)], out _))
                        System.Threading.Interlocked.Increment(ref successful);
            });
            Assert.AreEqual((long)successful, board.Revision);
            var snapshot = board.Snapshot();
            foreach (string bin in new[] { "L", "R" })
            {
                int count = snapshot.Values.Count(x => x == bin);
                Assert.AreEqual(count, board.CountIn(bin));
                Assert.AreEqual((long)count, board.WeightIn(bin));
            }
        }

        [Test]
        public void DefinitionsAndRulesExposeReadOnlyCollections()
        {
            var definition = CampaignPuzzles.Get(11);
            Assert.Throws<NotSupportedException>(() => ((IList<Item>)definition.Items).Clear());
            Assert.Throws<NotSupportedException>(() => ((IList<PuzzleRule>)definition.Rules).Clear());
            Assert.Throws<NotSupportedException>(() => ((IDictionary<string, string>)definition.Solution).Clear());
        }
    }
}
