using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CampaignNarrativeTests
    {
        [TestCase(0, "THE SIGNAL ROOM / DISCOVER")]
        [TestCase(2, "THE SIGNAL ROOM / UNSEAL")]
        [TestCase(11, "THE LAST DOOR / UNSEAL")]
        public void StageTitleIsStable(int level, string expected)
            => Assert.AreEqual(expected, CampaignNarrative.Title(level));

        [Test]
        public void EveryLevelHasNarrativeHook()
        {
            for (int i = 0; i < 12; i++)
                Assert.IsNotEmpty(CampaignNarrative.Hook(i));
        }
    }
}
