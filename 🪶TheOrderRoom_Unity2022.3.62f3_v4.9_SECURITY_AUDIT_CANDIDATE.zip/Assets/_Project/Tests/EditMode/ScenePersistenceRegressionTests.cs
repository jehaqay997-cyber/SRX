using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ScenePersistenceRegressionTests
    {
        [Test]
        public void SceneRoundTripPreservesConfiguredReferencesAndComponentScripts()
        {
            string path = "Assets/OrderScenePersistence_" + Guid.NewGuid().ToString("N") + ".unity";
            Scene previous = SceneManager.GetActiveScene();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                var root = new GameObject("PersistenceFixture");
                SceneManager.MoveGameObjectToScene(root, scene);
                var game = root.AddComponent<OrderGame>();
                Text heading = CreateText(root.transform, "Heading");
                Text status = CreateText(root.transform, "Status");
                Text collection = CreateText(root.transform, "Collection");
                Text reveal = CreateText(root.transform, "Reveal");
                Text instructions = CreateText(root.transform, "Instructions");
                var pieces = new GameObject("Pieces").transform;
                pieces.SetParent(root.transform);
                var camera = new GameObject("Camera").AddComponent<Camera>();
                camera.transform.SetParent(root.transform);
                var view = new GameObject("Inspection").AddComponent<ArtifactInspectionView>();
                view.transform.SetParent(root.transform);
                game.Configure(heading, status, pieces, camera);
                game.ConfigureCollection(collection, reveal);
                game.ConfigureInspection(view, instructions);
                var panel = new GameObject("RulesPanel"); panel.transform.SetParent(root.transform);
                game.ConfigureRules(CreateText(panel.transform, "RuleDetails"), panel);
                root.AddComponent<OrderClick>().Game = game;
                root.AddComponent<OrderDestination>().Game = game;
                root.AddComponent<OrderPointerInput>().Game = game;
                Assert.IsTrue(EditorSceneManager.SaveScene(scene, path));
                Assert.IsTrue(EditorSceneManager.CloseScene(scene, true));
                scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
                root = scene.GetRootGameObjects()[0];
                game = root.GetComponent<OrderGame>();
                Assert.IsNotNull(game);
                var serialized = new SerializedObject(game);
                foreach (string field in new[]
                {
                    "heading", "status", "collectionText", "revealText",
                    "inspectionText", "pieces", "sceneCamera", "inspectionView", "rulesText", "rulesPanel"
                })
                {
                    var property = serialized.FindProperty(field);
                    Assert.IsNotNull(property, field);
                    Assert.IsNotNull(property.objectReferenceValue, field);
                }
                Assert.AreSame(game, root.GetComponent<OrderClick>().Game);
                Assert.AreSame(game, root.GetComponent<OrderDestination>().Game);
                Assert.AreSame(game, root.GetComponent<OrderPointerInput>().Game);
                foreach (var component in root.GetComponents<MonoBehaviour>())
                {
                    Assert.IsNotNull(component, "Missing script after scene reload.");
                    Assert.IsNotNull(MonoScript.FromMonoBehaviour(component));
                }
            }
            finally
            {
                if (scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
                AssetDatabase.DeleteAsset(path);
            }
        }

        private static Text CreateText(Transform parent, string name)
        {
            var child = new GameObject(name, typeof(RectTransform), typeof(Text));
            child.transform.SetParent(parent, false);
            return child.GetComponent<Text>();
        }
    }
}
