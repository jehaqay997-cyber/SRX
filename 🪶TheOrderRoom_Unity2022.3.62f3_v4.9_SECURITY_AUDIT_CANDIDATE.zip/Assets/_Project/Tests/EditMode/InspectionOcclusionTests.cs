using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class InspectionOcclusionTests
    {
        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        public void FrontSealIsVisibleAndAnOpaqueColliderBlocksItsScan(int level)
        {
            var root = new GameObject("InspectionFixture");
            GameObject blocker = null;
            try
            {
                var view = root.AddComponent<ArtifactInspectionView>();
                view.Show(level);
                Assert.IsTrue(view.IsSealVisible(0), "Front seal is blocked by authored geometry.");
                blocker = GameObject.CreatePrimitive(PrimitiveType.Cube);
                blocker.layer = ArtifactInspectionView.InspectionLayer;
                blocker.transform.position = new Vector3(0f, .29f, -1.4f);
                blocker.transform.localScale = new Vector3(.4f, .4f, .4f);
                Assert.IsFalse(view.IsSealVisible(0), "Opaque blockers must prevent scanning.");
            }
            finally
            {
                if (blocker != null) Object.DestroyImmediate(blocker);
                Object.DestroyImmediate(root);
            }
        }
    }
}
