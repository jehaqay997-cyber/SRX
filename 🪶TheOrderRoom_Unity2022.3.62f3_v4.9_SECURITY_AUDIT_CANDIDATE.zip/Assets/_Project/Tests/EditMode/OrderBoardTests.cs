using System;
#if UNITY_INCLUDE_TESTS
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests
{
    public sealed class OrderBoardTests
    {
        private static OrderBoard NewBoard() => new OrderBoard(
            new[] { new Item("A", "SUN", 1), new Item("B", "SUN", 2) },
            new[] { new Compartment("SUN", "SUN", 2, 3) });
        [Test] public void PrepareDoesNotMutateState()
        {
            var board = NewBoard(); Assert.IsTrue(board.Prepare("A", "SUN", 0, out _, out _));
            Assert.AreEqual(OrderBoard.Tray, board.Location("A")); Assert.AreEqual(0, board.Revision);
        }
        [Test] public void CommitIsSingleUse()
        {
            var board = NewBoard(); Assert.IsTrue(board.Prepare("A", "SUN", 0, out Guid token, out _));
            Assert.IsTrue(board.Commit(token, out _)); Assert.IsFalse(board.Commit(token, out _));
        }
        [Test] public void RejectsStaleRevision()
        {
            var board = NewBoard(); Assert.IsTrue(board.Move("A", "SUN", out _));
            Assert.IsFalse(board.Prepare("B", "SUN", 0, out _, out _));
        }
        [Test] public void SolvedRequiresAllItemsPlaced()
        {
            var board = NewBoard(); Assert.IsTrue(board.Move("A", "SUN", out _)); Assert.IsFalse(board.Solved);
            Assert.IsTrue(board.Move("B", "SUN", out _)); Assert.IsTrue(board.Solved);
        }
        [Test] public void ResetRestoresAllToTray()
        {
            var board = NewBoard(); Assert.IsTrue(board.Move("A", "SUN", out _)); board.Reset();
            Assert.AreEqual(OrderBoard.Tray, board.Location("A")); Assert.IsFalse(board.Solved);
        }
        [Test] public void InvalidRestoreIsAtomic()
        {
            var board = NewBoard(); Assert.IsTrue(board.Move("A", "SUN", out _));
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "A", "SUN" }, { "B", "UNKNOWN" } }));
            Assert.AreEqual("SUN", board.Location("A")); Assert.AreEqual(OrderBoard.Tray, board.Location("B"));
        }
        [Test] public void InvalidWeightRejected()
        {
            var board = new OrderBoard(new[] { new Item("A", "SUN", 2) }, new[] { new Compartment("SUN", "SUN", 1, 1) });
            Assert.IsFalse(board.Move("A", "SUN", out _));
        }
    }
}
#endif
