using System;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CommercialFoundationTests
    {
        private sealed class StubEntitlements : IEntitlementProvider
        {
            public bool Owns(string id) => id == ContentCatalog.MiniatureWorlds;
        }
        [Test] public void BaseContentIsAlwaysAvailable()
        {
            Assert.IsTrue(new ContentAccessPolicy(new FreeContentEntitlements()).CanOpen(ContentCatalog.BasePack));
        }
        [Test] public void PaidContentFailsClosedWithoutPurchase()
        {
            var policy = new ContentAccessPolicy(new FreeContentEntitlements());
            Assert.IsFalse(policy.CanOpen(ContentCatalog.MiniatureWorlds));
            Assert.IsFalse(policy.CanOpen("unknown.pack"));
            Assert.IsFalse(policy.CanOpen(null));
        }
        [Test] public void PurchasedKnownPackCanBeOpened()
        {
            var policy = new ContentAccessPolicy(new StubEntitlements());
            Assert.IsTrue(policy.CanOpen(ContentCatalog.MiniatureWorlds));
            Assert.IsFalse(policy.CanOpen(ContentCatalog.LivingGallery));
        }
        [Test] public void CollectionIsIdempotent()
        {
            var progress = new CollectionProgress();
            Assert.IsTrue(progress.Discover("artifact.001"));
            Assert.IsFalse(progress.Discover("artifact.001"));
            Assert.AreEqual(1, progress.Count);
            Assert.Throws<ArgumentException>(() => progress.Discover(" "));
        }
    }
}
