using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class WorldInputContractTests
    {
        [Test]
        public void NestedColliderResolvesOwningItem()
        {
            var parent = new GameObject("owner");
            var child = new GameObject("collider");
            try
            {
                var marker = parent.AddComponent<OrderClick>();
                child.transform.SetParent(parent.transform);
                Assert.AreSame(marker, child.GetComponentInParent<OrderClick>());
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(child);
                UnityEngine.Object.DestroyImmediate(parent);
            }
        }

        [Test]
        public void NestedColliderResolvesOwningDestination()
        {
            var parent = new GameObject("owner");
            var child = new GameObject("collider");
            try
            {
                var marker = parent.AddComponent<OrderDestination>();
                child.transform.SetParent(parent.transform);
                Assert.AreSame(marker, child.GetComponentInParent<OrderDestination>());
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(child);
                UnityEngine.Object.DestroyImmediate(parent);
            }
        }
    }
}
