using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class PuzzleMathConformanceTests
    {
        [TestCase(-1, 3)] [TestCase(0, 0)] [TestCase(4, 0)] [TestCase(5, 1)]
        public void QuarterTurns_AreNormalized(int input, int expected)
            => Assert.AreEqual(expected, PuzzleMath.NormalizeQuarterTurn(input));

        [Test]
        public void SealGeometry_AlignsAfterPositiveQuarterTurns()
        {
            for (int i = 0; i < 3; i++)
            {
                PuzzleMath.SealPositionXZ(i, 0.53, out double x, out double z);
                double angle = PuzzleMath.QuarterTurnDegrees(i) * Math.PI / 180;
                double rotatedX = x * Math.Cos(angle) + z * Math.Sin(angle);
                double rotatedZ = -x * Math.Sin(angle) + z * Math.Cos(angle);
                Assert.That(rotatedX, Is.EqualTo(0).Within(1e-12));
                Assert.That(rotatedZ, Is.EqualTo(-0.53).Within(1e-12));
            }
        }

        [Test]
        public void SmoothStep_BoundaryAndIntegralConstraints()
        {
            Assert.That(PuzzleMath.SmoothStep(0), Is.EqualTo(0));
            Assert.That(PuzzleMath.SmoothStep(1), Is.EqualTo(1));
            Assert.That(PuzzleMath.SmoothStepDerivative(0), Is.EqualTo(0));
            Assert.That(PuzzleMath.SmoothStepDerivative(1), Is.EqualTo(0));
            Assert.That(PuzzleMath.SmoothStepAntiderivative(1) - PuzzleMath.SmoothStepAntiderivative(0), Is.EqualTo(1));
            for (int i = 0; i <= 100; i++)
                Assert.That(PuzzleMath.SmoothStepDerivative(i / 100.0), Is.GreaterThanOrEqualTo(0));
        }

        [Test]
        public void InvalidGeometry_IsRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => PuzzleMath.SealPositionXZ(3, 0.53, out _, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() => PuzzleMath.SealPositionXZ(0, double.NaN, out _, out _));
        }
    }
}
