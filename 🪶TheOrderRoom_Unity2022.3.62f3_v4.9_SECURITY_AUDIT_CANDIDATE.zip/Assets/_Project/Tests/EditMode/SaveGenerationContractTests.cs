using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveGenerationContractTests
    {
        [Test] public void NewDocumentDefaultsToLegacyGenerationZero()
        {
            Assert.AreEqual(0L, new SaveDocument().generation);
        }

        [Test] public void NegativeGenerationIsRejectedBeforeDiskAccess()
        {
            var document = new SaveDocument { generation = -1, level = 0, unlockedLevel = 0 };
            Assert.IsFalse(OrderSaveStore.TrySave(document, out _));
        }
    }
}
