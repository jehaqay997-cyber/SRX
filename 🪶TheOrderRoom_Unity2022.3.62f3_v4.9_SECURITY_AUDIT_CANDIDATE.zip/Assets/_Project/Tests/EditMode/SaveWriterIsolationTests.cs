using System;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveWriterIsolationTests
    {
        [Test]
        public void WriterLock_IsNotARecoveryCandidate()
        {
            var property = typeof(OrderSaveStore).GetProperty("WriterLockName", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.IsNotNull(property);
            var lockPath = (string)property.GetValue(null);
            StringAssert.EndsWith(".writer.lock", lockPath);
            var method = typeof(OrderSaveStore).GetMethod("AllSaveFiles", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.IsNotNull(method);
            foreach (string candidate in (System.Collections.Generic.IEnumerable<string>)method.Invoke(null, null))
                Assert.AreNotEqual(lockPath, candidate);
        }

        [Test]
        public void ExclusiveWriterLock_RejectsSecondWriter_AndReleasesAfterDispose()
        {
            string path = Path.Combine(Path.GetTempPath(), "tor-writer-" + Guid.NewGuid().ToString("N") + ".lock");
            try
            {
                using (var first = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
                    Assert.Throws<IOException>(() =>
                    {
                        using (var second = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None)) { }
                    });
                using (var reopened = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
                    Assert.IsTrue(reopened.CanWrite);
            }
            finally { if (File.Exists(path)) File.Delete(path); }
        }
    }
}
