using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CampaignInvariantMatrixTests
    {
        [Test]
        public void AllTwelveLevels_HaveFeasibleGoalsAndReversibleSnapshots()
        {
            for (int level = 0; level < OrderLevels.Count; level++)
            {
                var board = OrderLevels.Create(level);
                var initial = board.Snapshot();
                Assert.IsFalse(board.Solved, "level " + level);
                var ids = new HashSet<string>(StringComparer.Ordinal);
                foreach (var item in board.Items)
                {
                    Assert.IsTrue(ids.Add(item.Id), "duplicate item in level " + level);
                    Assert.AreEqual(OrderBoard.Tray, board.Location(item.Id));
                }
                Assert.IsTrue(board.Restore(new Dictionary<string, string>(initial)), "restore " + level);
                Assert.AreEqual(ids.Count, board.Snapshot().Count);
                foreach (var item in board.Items)
                    Assert.AreEqual(OrderBoard.Tray, board.Location(item.Id));
            }
        }

        [Test]
        public void TransferCapabilities_AreSingleUseAndRevisionBound()
        {
            var board = OrderLevels.Create(0);
            var item = new List<Item>(board.Items)[0];
            string destination = item.Tag;
            Assert.IsTrue(board.Prepare(item.Id, destination, board.Revision, out Guid token, out string error), error);
            Assert.IsTrue(board.Commit(token, out error), error);
            Assert.IsFalse(board.Commit(token, out _));
            Assert.IsFalse(board.Prepare(item.Id, OrderBoard.Tray, board.Revision - 1, out _, out _));
            Assert.AreEqual(destination, board.Location(item.Id));
        }
    }
}
