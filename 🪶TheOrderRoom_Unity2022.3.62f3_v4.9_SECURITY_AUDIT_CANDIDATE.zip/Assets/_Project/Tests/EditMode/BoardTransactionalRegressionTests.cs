#if UNITY_INCLUDE_TESTS
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests
{
    public sealed class BoardTransactionalRegressionTests
    {
        private static OrderBoard NewBoard()
        {
            return new OrderBoard(
                new[] { new Item("A", "SUN", 2), new Item("B", "SUN", 3), new Item("C", "MOON", 4) },
                new[] { new Compartment("L", "SUN", 2, 5), new Compartment("R", "SUN", 1, 3), new Compartment("M", "MOON", 1, 4) });
        }

        private static void SameState(IReadOnlyDictionary<string, string> expected, IReadOnlyDictionary<string, string> actual)
        {
            Assert.AreEqual(expected.Count, actual.Count);
            foreach (var pair in expected)
                Assert.AreEqual(pair.Value, actual[pair.Key], pair.Key);
        }

        private static void Invariants(OrderBoard board)
        {
            var items = board.Items.ToDictionary(x => x.Id, StringComparer.Ordinal);
            var compartments = board.Compartments.ToDictionary(x => x.Id, StringComparer.Ordinal);
            var state = board.Snapshot();
            Assert.AreEqual(items.Count, state.Count);
            foreach (var pair in state)
            {
                Assert.IsTrue(items.ContainsKey(pair.Key));
                if (pair.Value == OrderBoard.Tray) continue;
                Assert.IsTrue(compartments.ContainsKey(pair.Value));
                Assert.AreEqual(items[pair.Key].Tag, compartments[pair.Value].Tag);
            }
            foreach (var bin in compartments.Values)
            {
                var occupants = state.Where(x => x.Value == bin.Id).ToArray();
                Assert.LessOrEqual(occupants.Length, bin.Capacity);
                Assert.LessOrEqual(occupants.Sum(x => (long)items[x.Key].Weight), (long)bin.MaxWeight);
            }
        }

        [Test] public void FailedMoveDoesNotMutateStateOrRevision()
        {
            var board = NewBoard();
            var before = board.Snapshot();
            long revision = board.Revision;
            Assert.IsFalse(board.Move("A", "M", out _));
            Assert.IsFalse(board.Move("missing", "L", out _));
            Assert.IsFalse(board.Move("A", "missing", out _));
            SameState(before, board.Snapshot());
            Assert.AreEqual(revision, board.Revision);
        }

        [Test] public void StaleRevisionDoesNotIssueTransfer()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Move("A", "L", out _));
            var before = board.Snapshot();
            Assert.IsFalse(board.Prepare("B", "R", 0, out Guid token, out _));
            Assert.AreEqual(Guid.Empty, token);
            SameState(before, board.Snapshot());
        }

        [Test] public void PrepareNeverMutatesBoard()
        {
            var board = NewBoard();
            var before = board.Snapshot();
            Assert.IsTrue(board.Prepare("A", "L", board.Revision, out _, out _));
            SameState(before, board.Snapshot());
            Assert.AreEqual(0, board.Revision);
        }

        [Test] public void IssuedTokenIsSingleUse()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Prepare("A", "L", board.Revision, out Guid token, out _));
            Assert.IsTrue(board.Commit(token, out _));
            var before = board.Snapshot();
            Assert.IsFalse(board.Commit(token, out _));
            SameState(before, board.Snapshot());
            Assert.AreEqual(1, board.Revision);
        }

        [Test] public void SecondPrepareInvalidatesFirstToken()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Prepare("A", "L", 0, out Guid first, out _));
            Assert.IsTrue(board.Prepare("B", "R", 0, out Guid second, out _));
            Assert.IsFalse(board.Commit(first, out _));
            Assert.IsTrue(board.Commit(second, out _));
            Assert.AreEqual(OrderBoard.Tray, board.Location("A"));
            Assert.AreEqual("R", board.Location("B"));
        }

        [Test] public void InvalidRestoreLeavesBoardUnchanged()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Move("A", "L", out _));
            var before = board.Snapshot();
            long revision = board.Revision;
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "A", "L" } }));
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "A", "M" }, { "B", "R" }, { "C", OrderBoard.Tray } }));
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "A", "L" }, { "B", "L" }, { "C", "L" } }));
            SameState(before, board.Snapshot());
            Assert.AreEqual(revision, board.Revision);
        }

        [Test] public void SuccessfulRestoreInvalidatesPendingToken()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Prepare("A", "L", 0, out Guid token, out _));
            Assert.IsTrue(board.Restore(new Dictionary<string, string>
            {
                { "A", "L" }, { "B", "R" }, { "C", "M" }
            }));
            Assert.IsFalse(board.Commit(token, out _));
            Invariants(board);
        }

        [Test] public void ResetClearsLocationsAndPendingTransfers()
        {
            var board = NewBoard();
            Assert.IsTrue(board.Move("A", "L", out _));
            Assert.IsTrue(board.Prepare("B", "R", board.Revision, out Guid token, out _));
            board.Reset();
            Assert.IsFalse(board.Commit(token, out _));
            Assert.IsTrue(board.Snapshot().Values.All(x => x == OrderBoard.Tray));
            Invariants(board);
        }

        [Test] public void SnapshotMutationDoesNotModifyBoard()
        {
            var board = NewBoard();
            var snapshot = board.Snapshot();
            var mutable = snapshot as IDictionary<string, string>;
            Assert.IsNotNull(mutable);
            mutable["A"] = "L";
            Assert.AreEqual(OrderBoard.Tray, board.Location("A"));
        }

        [Test] public void SeededMoveSequencesPreserveInvariants()
        {
            var board = NewBoard();
            var random = new Random(240817);
            string[] ids = { "A", "B", "C" };
            string[] destinations = { OrderBoard.Tray, "L", "R", "M", "UNKNOWN" };
            for (int i = 0; i < 2000; i++)
            {
                var before = board.Snapshot();
                long revision = board.Revision;
                bool moved = board.Move(ids[random.Next(ids.Length)], destinations[random.Next(destinations.Length)], out _);
                if (!moved)
                {
                    SameState(before, board.Snapshot());
                    Assert.AreEqual(revision, board.Revision);
                }
                else Assert.AreEqual(revision + 1, board.Revision);
                Invariants(board);
            }
        }
    }
}
#endif
