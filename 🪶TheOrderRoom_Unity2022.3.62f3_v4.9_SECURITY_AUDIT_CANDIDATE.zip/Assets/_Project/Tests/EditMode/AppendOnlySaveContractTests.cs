using System;
using System.IO;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AppendOnlySaveContractTests
    {
        [Test] public void InvalidLevelCannotWriteJournal()
        {
            var invalid = new SaveDocument { level = -1, unlockedLevel = 0 };
            Assert.IsFalse(OrderSaveStore.TrySave(invalid, out _));
        }

        [Test] public void DuplicateLocationsCannotWriteJournal()
        {
            var invalid = new SaveDocument { level = 0, unlockedLevel = 0 };
            invalid.locations.Add(new SaveEntry { itemId = "A", destination = "TRAY" });
            invalid.locations.Add(new SaveEntry { itemId = "A", destination = "TRAY" });
            Assert.IsFalse(OrderSaveStore.TrySave(invalid, out _));
        }
    }
}
