#if UNITY_INCLUDE_TESTS
using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;
namespace TheOrderRoom.Tests
{
 public sealed class DomainHardeningTests
 {
  private static OrderBoard Exact() => new OrderBoard(
   new[]{new Item("A","SUN",1),new Item("B","SUN",1)},
   new[]{new Compartment("LEFT","SUN",1,2),new Compartment("RIGHT","SUN",1,2)},
   new Dictionary<string,string>{{"A","LEFT"},{"B","RIGHT"}});
  [Test] public void WrongButValidPlacementDoesNotSolveObjective(){var b=Exact();Assert.IsTrue(b.Move("A","RIGHT",out _));Assert.IsTrue(b.Move("B","LEFT",out _));Assert.IsFalse(b.Solved);}
  [Test] public void ExactPlacementSolvesObjective(){var b=Exact();Assert.IsTrue(b.Move("A","LEFT",out _));Assert.IsTrue(b.Move("B","RIGHT",out _));Assert.IsTrue(b.Solved);}
  [Test] public void InvalidObjectiveRejected(){Assert.Throws<ArgumentException>(()=>new OrderBoard(new[]{new Item("A","SUN",1)},new[]{new Compartment("LEFT","SUN",1,1)},new Dictionary<string,string>{{"A","MISSING"}}));}
  [Test] public void RestoreDoesNotBypassObjective(){var b=Exact();Assert.IsTrue(b.Restore(new Dictionary<string,string>{{"A","RIGHT"},{"B","LEFT"}}));Assert.IsFalse(b.Solved);}
  [Test] public void ReservedItemIdRejected(){Assert.Throws<ArgumentException>(()=>new OrderBoard(new[]{new Item(OrderBoard.Tray,"SUN",1)},new[]{new Compartment("LEFT","SUN",1,1)}));}
  [Test] public void MilestonesAreReadOnly(){var list=CollectionMilestones.Definitions as IList<CollectionMilestone>;Assert.IsNotNull(list);Assert.Throws<NotSupportedException>(()=>list[0]=new CollectionMilestone("x",1));}
 }
}
#endif
