using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveJournalPrecedenceTests
    {
        private static bool Select(bool hasCurrent, bool currentJournal,
            long currentGeneration, bool candidateJournal, long candidateGeneration)
        {
            var method = typeof(OrderSaveStore).GetMethod("ShouldSelectCandidate",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.IsNotNull(method);
            return (bool)method.Invoke(null, new object[] {
                hasCurrent, currentJournal, currentGeneration, candidateJournal, candidateGeneration });
        }

        [Test] public void FirstValidCandidateIsSelected()
            => Assert.IsTrue(Select(false, false, -1, false, 0));

        [Test] public void JournalOutranksLegacyEvenIfLegacyClaimsHigherGeneration()
            => Assert.IsTrue(Select(true, false, 999, true, 2));

        [Test] public void LegacyCannotReplaceCommittedJournal()
            => Assert.IsFalse(Select(true, true, 2, false, 999));

        [Test] public void NewerJournalWins()
            => Assert.IsTrue(Select(true, true, 2, true, 3));

        [Test] public void OlderOrEqualJournalCannotReplaceNewer()
        {
            Assert.IsFalse(Select(true, true, 3, true, 2));
            Assert.IsFalse(Select(true, true, 3, true, 3));
        }

        [Test] public void NewerLegacyWinsWhenNoJournalExists()
            => Assert.IsTrue(Select(true, false, 0, false, 1));
    }
}
