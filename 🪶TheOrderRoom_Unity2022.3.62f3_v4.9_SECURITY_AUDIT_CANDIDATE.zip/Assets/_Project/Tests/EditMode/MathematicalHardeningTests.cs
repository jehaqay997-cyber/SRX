#if UNITY_INCLUDE_TESTS
using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class MathematicalHardeningTests
    {
        [Test] public void MilestonesCountUniqueIdentifiersOnly()
        {
            CollectionAssert.AreEqual(new[] { "gallery.first" },
                CollectionMilestones.Evaluate(new[] { "a", "a", "a", "a" }));
        }

        [Test] public void MilestonesRejectMalformedIdentifiers()
        {
            Assert.Throws<ArgumentException>(() => CollectionMilestones.Evaluate(new[] { "a", " " }));
        }

        [Test] public void SolverReturnsExplicitBudgetExceededWithoutRecursion()
        {
            var items = new[] { new Item("A", "X", 1), new Item("B", "X", 1) };
            var bins = new[] { new Compartment("One", "X", 2, 2) };
            Assert.AreEqual(SolvabilityStatus.BudgetExceeded,
                LevelSolvability.Analyze(items, bins, out var witness, 1));
            Assert.IsNull(witness);
            Assert.AreEqual(SolvabilityStatus.Solvable,
                LevelSolvability.Analyze(items, bins, out witness, 100));
            Assert.AreEqual(2, witness.Count);
        }

        [Test] public void SolverReturnsUnsolvableWhenPackingImpossible()
        {
            var items = new[] { new Item("A", "X", 4), new Item("B", "X", 4), new Item("C", "X", 4) };
            var bins = new[] { new Compartment("One", "X", 2, 6), new Compartment("Two", "X", 2, 6) };
            Assert.AreEqual(SolvabilityStatus.Unsolvable,
                LevelSolvability.Analyze(items, bins, out var witness));
            Assert.IsNull(witness);
        }

        [Test] public void SmoothStepAntiderivativeRejectsNonFiniteInputs()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => PuzzleMath.SmoothStepAntiderivative(double.NaN));
            Assert.Throws<ArgumentOutOfRangeException>(() => PuzzleMath.SmoothStepAntiderivative(double.PositiveInfinity));
        }
    }
}
#endif
