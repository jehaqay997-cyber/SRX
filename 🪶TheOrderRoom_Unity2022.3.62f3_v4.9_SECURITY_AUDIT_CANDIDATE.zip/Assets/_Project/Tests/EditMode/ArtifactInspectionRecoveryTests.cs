using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactInspectionRecoveryTests
    {
        [Test] public void ReopeningSameArtifactStartsWithoutOldProgress()
        {
            var state = new ArtifactInspectionState();
            state.Begin("campaign.level.01");
            Assert.IsTrue(state.Scan());
            Assert.IsTrue(state.Turn(1));
            state.Cancel();
            state.Begin("campaign.level.01");
            Assert.AreEqual(0, state.Orientation);
            Assert.AreEqual(0, state.SealsFound);
            Assert.IsFalse(state.IsRevealed);
            Assert.IsTrue(state.Scan());
        }

        [Test] public void ClaimRequiresExactIdentityAndAllThreeSeals()
        {
            var state = new ArtifactInspectionState();
            state.Begin("campaign.level.01");
            for (int i = 0; i < 3; i++)
            {
                Assert.IsTrue(state.Scan());
                if (i < 2) Assert.IsTrue(state.Turn(1));
            }
            Assert.IsFalse(state.TryClaim("campaign.level.02"));
            Assert.IsTrue(state.IsRevealed);
            Assert.IsTrue(state.TryClaim("campaign.level.01"));
            Assert.IsFalse(state.TryClaim("campaign.level.01"));
        }
    }
}
