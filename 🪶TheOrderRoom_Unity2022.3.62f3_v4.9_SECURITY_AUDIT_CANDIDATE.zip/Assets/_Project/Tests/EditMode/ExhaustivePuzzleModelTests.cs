using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ExhaustivePuzzleModelTests
    {
        private static readonly string[] Ids = { "A", "B", "C" };
        private static readonly string[] Destinations = { OrderBoard.Tray, "L", "R" };
        private static OrderBoard Create(int mask)
        {
            var rules = new List<PuzzleRule>();
            if ((mask & 1) != 0) { rules.Add(new WeightQuotaRule("L", 3)); rules.Add(new WeightQuotaRule("R", 3)); }
            if ((mask & 2) != 0) rules.Add(new SeparatedPairRule("A", "B"));
            if ((mask & 4) != 0) rules.Add(new PrerequisiteRule("B", "A"));
            if ((mask & 8) != 0) rules.Add(new CountBalanceRule("L", "R"));
            return new OrderBoard(new[] { new Item("A", "X", 1), new Item("B", "X", 2), new Item("C", "X", 3) },
                new[] { new Compartment("L", "X", 2, 4), new Compartment("R", "X", 2, 4) }, null, rules);
        }
        // Independent array/arithmetic oracle. It does not call any production rule or board validator.
        private static bool Valid(int[] p, int mask, bool completion)
        {
            int left = 0, right = 0, leftWeight = 0, rightWeight = 0;
            for (int i = 0; i < 3; i++)
            {
                if (p[i] == 0 && completion) return false;
                if (p[i] == 1) { left++; leftWeight += i + 1; }
                if (p[i] == 2) { right++; rightWeight += i + 1; }
            }
            if (left > 2 || right > 2 || leftWeight > 4 || rightWeight > 4) return false;
            if ((mask & 1) != 0 && (leftWeight > 3 || rightWeight > 3 ||
                (completion && (leftWeight != 3 || rightWeight != 3)))) return false;
            if ((mask & 2) != 0 && p[0] != 0 && p[0] == p[1]) return false;
            if ((mask & 4) != 0 && p[1] != 0 && p[0] == 0) return false;
            return (mask & 8) == 0 || Math.Abs(left - right) <= 1;
        }
        private static Dictionary<string, string> Snapshot(int[] p) =>
            Enumerable.Range(0, 3).ToDictionary(i => Ids[i], i => Destinations[p[i]]);

        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        [TestCase(12)] [TestCase(13)] [TestCase(14)] [TestCase(15)]
        public void EverySmallStateAndTransitionMatchesIndependentOracle(int mask)
        {
            for (int code = 0; code < 27; code++)
            {
                int[] state = { code % 3, code / 3 % 3, code / 9 % 3 };
                var snapshot = Snapshot(state);
                var restored = Create(mask);
                bool valid = Valid(state, mask, false);
                Assert.AreEqual(valid, restored.Restore(snapshot), "restore code=" + code);
                if (!valid) { Assert.AreEqual(0L, restored.Revision); continue; }
                Assert.AreEqual(Valid(state, mask, true), restored.Solved, "completion code=" + code);
                for (int item = 0; item < 3; item++)
                    for (int target = 0; target < 3; target++)
                    {
                        var board = Create(mask);
                        Assert.IsTrue(board.Restore(snapshot));
                        long revision = board.Revision;
                        var candidate = (int[])state.Clone(); candidate[item] = target;
                        bool expected = state[item] != target && Valid(candidate, mask, false);
                        Assert.AreEqual(expected, board.Move(Ids[item], Destinations[target], out _),
                            "transition code=" + code + " item=" + item + " target=" + target);
                        Assert.AreEqual(revision + (expected ? 1 : 0), board.Revision);
                        int[] final = expected ? candidate : state;
                        for (int i = 0; i < 3; i++) Assert.AreEqual(Destinations[final[i]], board.Location(Ids[i]));
                        foreach (int bin in new[] { 1, 2 })
                        {
                            Assert.AreEqual(final.Count(x => x == bin), board.CountIn(Destinations[bin]));
                            Assert.AreEqual(Enumerable.Range(0, 3).Where(i => final[i] == bin).Sum(i => (long)i + 1),
                                board.WeightIn(Destinations[bin]));
                        }
                    }
            }
        }
        [Test]
        public void CyclicPrerequisitesAreRejectedBeforePlay()
        {
            Assert.Throws<ArgumentException>(() => new OrderBoard(
                new[] { new Item("A", "X", 1), new Item("B", "X", 1) },
                new[] { new Compartment("L", "X", 2, 2) }, null,
                new PuzzleRule[] { new PrerequisiteRule("A", "B"), new PrerequisiteRule("B", "A") }));
        }
    }
}
