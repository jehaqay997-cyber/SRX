using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveBoardIntegrityTests
    {
        private static SaveDocument ValidDocument()
        {
            var board = OrderLevels.Create(0);
            var document = new SaveDocument { level = 0, unlockedLevel = 0 };
            foreach (var pair in board.Snapshot())
                document.locations.Add(new SaveEntry { itemId = pair.Key, destination = pair.Value });
            return document;
        }

        [Test]
        public void ValidBoard_IsAccepted()
        {
            Assert.IsTrue(OrderSaveStore.ValidBoardSnapshot(ValidDocument()));
        }

        [Test]
        public void UnknownItem_IsRejected()
        {
            var document = ValidDocument();
            document.locations.Add(new SaveEntry { itemId = "NON_EXISTENT_ITEM", destination = "TRAY" });
            Assert.IsFalse(OrderSaveStore.ValidBoardSnapshot(document));
        }

        [Test]
        public void MissingItem_IsRejected()
        {
            var document = ValidDocument();
            document.locations.RemoveAt(0);
            Assert.IsFalse(OrderSaveStore.ValidBoardSnapshot(document));
        }

        [Test]
        public void DuplicateItem_IsRejected()
        {
            var document = ValidDocument();
            document.locations.Add(new SaveEntry {
                itemId = document.locations[0].itemId,
                destination = document.locations[0].destination
            });
            Assert.IsFalse(OrderSaveStore.ValidBoardSnapshot(document));
        }

        [Test]
        public void InvalidDestination_IsRejected()
        {
            var document = ValidDocument();
            document.locations[0].destination = "INVALID_DESTINATION";
            Assert.IsFalse(OrderSaveStore.ValidBoardSnapshot(document));
        }
    }
}
