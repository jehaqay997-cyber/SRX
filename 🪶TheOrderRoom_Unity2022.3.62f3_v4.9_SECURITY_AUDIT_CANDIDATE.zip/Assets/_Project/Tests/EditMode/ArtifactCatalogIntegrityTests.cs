using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactCatalogIntegrityTests
    {
        [Test] public void EveryCampaignArtifactHasUniqueStableIdentifier()
        {
            var ids = new System.Collections.Generic.HashSet<string>(System.StringComparer.Ordinal);
            for (int level = 0; level < OrderLevels.Count; level++)
            {
                string id = ArtifactPresentation.ForLevel(level);
                Assert.IsTrue(ids.Add(id));
                Assert.AreNotEqual("Unknown Artifact", ArtifactPresentation.DisplayName(id));
            }
        }

        [Test] public void InspectionOrientationReturnsToOriginAfterFourTurns()
        {
            var state = new ArtifactInspectionState();
            state.Begin(ArtifactPresentation.ForLevel(0));
            for (int i = 0; i < 4; i++) Assert.IsTrue(state.Turn(1));
            Assert.AreEqual(0, state.Orientation);
            Assert.AreEqual(0, state.SealsFound);
        }
    }
}
