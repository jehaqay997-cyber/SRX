using NUnit.Framework;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactInspectionStateTests
    {
        [Test] public void TurnsAloneNeverReveal()
        {
            var s = new ArtifactInspectionState(); s.Begin("artifact.one");
            for (int i = 0; i < 8; i++) Assert.IsTrue(s.Turn(1));
            Assert.IsFalse(s.IsRevealed);
            Assert.IsFalse(s.TryClaim("artifact.one"));
        }
        [Test] public void ThreeDistinctSealsRevealOnce()
        {
            var s = new ArtifactInspectionState(); s.Begin("artifact.one");
            Assert.IsTrue(s.Scan()); Assert.IsFalse(s.Scan());
            Assert.IsTrue(s.Turn(1)); Assert.IsTrue(s.Scan());
            Assert.IsTrue(s.Turn(1)); Assert.IsTrue(s.Scan());
            Assert.IsTrue(s.IsRevealed);
            Assert.IsFalse(s.TryClaim("artifact.other"));
            Assert.IsTrue(s.TryClaim("artifact.one"));
            Assert.IsFalse(s.TryClaim("artifact.one"));
        }
        [Test] public void BlankFaceCannotBeScanned()
        {
            var s = new ArtifactInspectionState(); s.Begin("artifact.one");
            Assert.IsTrue(s.Turn(-1)); Assert.IsFalse(s.Scan());
        }
        [Test] public void CancelAndRestartClearAllScans()
        {
            var s = new ArtifactInspectionState(); s.Begin("artifact.one");
            Assert.IsTrue(s.Scan()); s.Cancel();
            Assert.IsFalse(s.TryClaim("artifact.one"));
            s.Begin("artifact.two");
            Assert.AreEqual(0,s.SealsFound); Assert.IsTrue(s.Scan());
            Assert.IsFalse(s.TryClaim("artifact.two"));
        }
    }
}
