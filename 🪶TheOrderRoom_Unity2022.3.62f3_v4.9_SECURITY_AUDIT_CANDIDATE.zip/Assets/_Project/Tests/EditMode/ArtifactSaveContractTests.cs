using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ArtifactSaveContractTests
    {
        [Test]
        public void LedgerRoundTripViaSaveDocumentIsIdempotent()
        {
            var ledger = new ArtifactLedger();
            Assert.IsTrue(ledger.Discover("campaign.level.01"));
            Assert.IsFalse(ledger.Discover("campaign.level.01"));
            var save = new SaveDocument { discoveredArtifacts = new List<string>(ledger.Snapshot()) };
            var restored = new ArtifactLedger();
            Assert.IsTrue(restored.TryRestore(save.discoveredArtifacts));
            Assert.AreEqual(1, restored.Count);
        }

        [Test]
        public void InvalidRestoreDoesNotDestroyExistingLedger()
        {
            var ledger = new ArtifactLedger();
            ledger.Discover("campaign.level.01");
            Assert.IsFalse(ledger.TryRestore(new[] { "duplicate", "duplicate" }));
            Assert.IsTrue(ledger.Contains("campaign.level.01"));
        }
    }
}
