using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Runtime;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class SaveValidationTests
    {
        [Test] public void FutureVersionIsNotWritten()
        {
            var doc = new SaveDocument { schemaVersion = 999, level = 0, unlockedLevel = 0 };
            Assert.IsFalse(OrderSaveStore.TrySave(doc, out _));
        }
        [Test] public void DuplicateArtifactsAreRejectedBeforeWriting()
        {
            var doc = new SaveDocument { level = 0, unlockedLevel = 0,
                discoveredArtifacts = new List<string> {"campaign.level.01", "campaign.level.01"} };
            Assert.IsFalse(OrderSaveStore.TrySave(doc, out _));
        }
    }
}
