using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class BoardIndexRegressionTests
    {
        private static OrderBoard Create()
        {
            return new OrderBoard(
                new[] { new Item("a", "red", 3), new Item("b", "red", 4), new Item("c", "red", 5) },
                new[] { new Compartment("bin", "red", 2, 7) });
        }

        [Test]
        public void CapacityAndWeightIndexesStayCorrectAfterTransferAndRemoval()
        {
            var board = Create();
            Assert.IsTrue(board.Move("a", "bin", out _));
            Assert.IsTrue(board.Move("b", "bin", out _));
            Assert.IsFalse(board.Move("c", "bin", out _));
            Assert.AreEqual(OrderBoard.Tray, board.Location("c"));
            Assert.IsTrue(board.Move("b", OrderBoard.Tray, out _));
            Assert.IsFalse(board.Move("c", "bin", out _));
            Assert.IsTrue(board.Move("a", OrderBoard.Tray, out _));
            Assert.IsTrue(board.Move("c", "bin", out _));
        }

        [Test]
        public void FailedRestorePreservesLocationAndCapacityIndex()
        {
            var board = Create();
            Assert.IsTrue(board.Move("a", "bin", out _));
            long revision = board.Revision;
            var invalid = new Dictionary<string, string>(StringComparer.Ordinal)
            {
                { "a", "bin" }, { "b", "bin" }, { "c", "bin" }
            };
            Assert.IsFalse(board.Restore(invalid));
            Assert.AreEqual(revision, board.Revision);
            Assert.AreEqual("bin", board.Location("a"));
            Assert.IsTrue(board.Move("b", "bin", out _));
        }

        [Test]
        public void ResetAndRestoreRebuildDerivedIndexes()
        {
            var board = Create();
            Assert.IsTrue(board.Move("a", "bin", out _));
            var saved = new Dictionary<string, string>(board.Snapshot(), StringComparer.Ordinal);
            board.Reset();
            Assert.IsTrue(board.Move("c", "bin", out _));
            Assert.IsTrue(board.Restore(saved));
            Assert.IsTrue(board.Move("b", "bin", out _));
            Assert.IsFalse(board.Move("c", "bin", out _));
        }
    }
}
