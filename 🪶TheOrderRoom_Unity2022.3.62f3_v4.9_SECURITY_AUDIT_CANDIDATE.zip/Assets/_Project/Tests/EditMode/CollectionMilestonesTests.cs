using NUnit.Framework;
using TheOrderRoom.Domain;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CollectionMilestonesTests
    {
        [Test] public void EmptyCollectionHasNoMilestones() => Assert.IsEmpty(CollectionMilestones.Evaluate(new string[0]));
        [Test] public void FourArtifactsUnlockTwoMilestones()
        {
            var result = CollectionMilestones.Evaluate(new[] {"a", "b", "c", "d"});
            CollectionAssert.AreEqual(new[] {"gallery.first", "gallery.curator"}, result);
        }
        [Test] public void LedgerRejectsOverlongIdentifiers()
        {
            var ledger = new ArtifactLedger();
            Assert.Throws<System.ArgumentException>(() => ledger.Discover(new string('x',129)));
        }
    }
}
