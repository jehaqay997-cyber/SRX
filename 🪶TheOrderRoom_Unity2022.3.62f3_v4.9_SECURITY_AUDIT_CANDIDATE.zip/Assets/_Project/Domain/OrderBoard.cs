using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace TheOrderRoom.Domain
{
    public sealed class Item
    {
        public readonly string Id;
        public readonly string Tag;
        public readonly int Weight;
        public Item(string id, string tag, int weight)
        {
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(tag) || weight <= 0)
                throw new ArgumentException("Invalid item.");
            Id = id; Tag = tag; Weight = weight;
        }
    }

    public sealed class Compartment
    {
        public readonly string Id;
        public readonly string Tag;
        public readonly int Capacity;
        public readonly int MaxWeight;
        public Compartment(string id, string tag, int capacity, int maxWeight)
        {
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(tag) || capacity <= 0 || maxWeight <= 0)
                throw new ArgumentException("Invalid compartment.");
            Id = id; Tag = tag; Capacity = capacity; MaxWeight = maxWeight;
        }
    }

    public sealed class OrderBoard
    {
        public const string Tray = "TRAY";
        private readonly object stateGate = new object();
        private long revision;
        private readonly Dictionary<string, Item> items = new Dictionary<string, Item>(StringComparer.Ordinal);
        private readonly Dictionary<string, Compartment> compartments = new Dictionary<string, Compartment>(StringComparer.Ordinal);
        private Dictionary<string, string> locations = new Dictionary<string, string>(StringComparer.Ordinal);
        private Dictionary<string, int> occupancy = new Dictionary<string, int>(StringComparer.Ordinal);
        private Dictionary<string, long> totalWeight = new Dictionary<string, long>(StringComparer.Ordinal);
        private readonly Dictionary<Guid, Proposal> issued = new Dictionary<Guid, Proposal>();
        private readonly IReadOnlyDictionary<string, Item> itemView;
        private readonly Dictionary<string, string> requiredLocations;
        private readonly PuzzleRule[] rules;
        private readonly ReadOnlyCollection<Item> itemListView;
        private readonly ReadOnlyCollection<Compartment> compartmentListView;
        private readonly ReadOnlyCollection<PuzzleRule> ruleView;
        private readonly IReadOnlyDictionary<string, string> targetView;
        public long Revision
        {
            get { lock (stateGate) return revision; }
            private set { lock (stateGate) revision = value; }
        }
        private struct Proposal { public string Item; public string From; public string To; public long Revision; }

        public OrderBoard(IEnumerable<Item> itemList, IEnumerable<Compartment> compartmentList)
            : this(itemList, compartmentList, null, null) { }
        public OrderBoard(IEnumerable<Item> itemList, IEnumerable<Compartment> compartmentList,
            IReadOnlyDictionary<string, string> exactTargets) : this(itemList, compartmentList, exactTargets, null) { }
        public OrderBoard(IEnumerable<Item> itemList, IEnumerable<Compartment> compartmentList,
            IReadOnlyDictionary<string, string> exactTargets, IEnumerable<PuzzleRule> placementRules)
        {
            if (itemList == null) throw new ArgumentNullException(nameof(itemList));
            if (compartmentList == null) throw new ArgumentNullException(nameof(compartmentList));
            foreach (var bin in compartmentList)
            {
                if (bin == null || bin.Id == Tray || compartments.ContainsKey(bin.Id))
                    throw new ArgumentException("Null, duplicate or reserved compartment.");
                compartments.Add(bin.Id, bin); occupancy.Add(bin.Id, 0); totalWeight.Add(bin.Id, 0);
            }
            foreach (var item in itemList)
            {
                if (item == null || item.Id == Tray || items.ContainsKey(item.Id))
                    throw new ArgumentException("Null, duplicate or reserved item.");
                items.Add(item.Id, item); locations.Add(item.Id, Tray);
            }
            if (items.Count == 0 || compartments.Count == 0) throw new ArgumentException("Empty board.");
            itemView = new ReadOnlyDictionary<string, Item>(items);
            itemListView = Array.AsReadOnly(items.Values.ToArray());
            compartmentListView = Array.AsReadOnly(compartments.Values.ToArray());
            rules = placementRules == null ? Array.Empty<PuzzleRule>() : placementRules.ToArray();
            ruleView = Array.AsReadOnly(rules);
            var binView = new ReadOnlyDictionary<string, Compartment>(compartments);
            foreach (var rule in rules)
            {
                if (rule == null) throw new ArgumentException("Null puzzle rule.");
                rule.ValidateDefinition(itemView, binView);
            }
            ValidateDependencyGraph();
            if (!RulesAccept(locations, false, out string initialError)) throw new ArgumentException(initialError);
            if (exactTargets != null)
            {
                if (exactTargets.Count != items.Count) throw new ArgumentException("Objective must specify every item.");
                requiredLocations = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var pair in exactTargets)
                {
                    if (string.IsNullOrWhiteSpace(pair.Key) || string.IsNullOrWhiteSpace(pair.Value) ||
                        !items.ContainsKey(pair.Key) || !compartments.ContainsKey(pair.Value))
                        throw new ArgumentException("Invalid objective target.");
                    requiredLocations.Add(pair.Key, pair.Value);
                }
                if (!ValidateSnapshot(requiredLocations, true, out _, out _, out string error))
                    throw new ArgumentException("Invalid objective: " + error);
                targetView = new ReadOnlyDictionary<string, string>(requiredLocations);
            }
        }
        private void ValidateDependencyGraph()
        {
            var outgoing = items.Keys.ToDictionary(x => x, x => new HashSet<string>(StringComparer.Ordinal), StringComparer.Ordinal);
            var degree = items.Keys.ToDictionary(x => x, x => 0, StringComparer.Ordinal);
            foreach (var rule in rules.OfType<PrerequisiteRule>())
                if (outgoing[rule.RequiredItemId].Add(rule.ItemId)) degree[rule.ItemId]++;
            var ready = new Queue<string>(degree.Where(x => x.Value == 0).Select(x => x.Key));
            int visited = 0;
            while (ready.Count > 0)
            {
                string id = ready.Dequeue(); visited++;
                foreach (string dependent in outgoing[id]) if (--degree[dependent] == 0) ready.Enqueue(dependent);
            }
            if (visited != items.Count) throw new ArgumentException("Cyclic item prerequisites.");
        }
        public IReadOnlyDictionary<string, string> Snapshot()
        {
            lock (stateGate) return new Dictionary<string, string>(locations, StringComparer.Ordinal);
        }
        public IEnumerable<Item> Items => itemListView;
        public IEnumerable<Compartment> Compartments => compartmentListView;
        public string Location(string id) { lock (stateGate) return locations[id]; }
        public IReadOnlyDictionary<string, string> ExactTargets => targetView;
        public IReadOnlyList<PuzzleRule> Rules => ruleView;
        public bool TryGetItem(string id, out Item item)
        {
            item = null;
            return id != null && items.TryGetValue(id, out item);
        }
        public long WeightIn(string binId) { lock (stateGate) return totalWeight[binId]; }
        public int CountIn(string binId) { lock (stateGate) return occupancy[binId]; }

        public bool Prepare(string id, string destination, long expectedRevision, out Guid token, out string error)
        {
            lock (stateGate) return PrepareCore(id, destination, expectedRevision, out token, out error);
        }
        private bool PrepareCore(string id, string destination, long expectedRevision, out Guid token, out string error)
        {
            token = Guid.Empty; issued.Clear();
            if (expectedRevision != Revision) { error = "Stale revision."; return false; }
            if (string.IsNullOrWhiteSpace(id) || !items.ContainsKey(id)) { error = "Unknown item."; return false; }
            if (string.IsNullOrWhiteSpace(destination) || (destination != Tray && !compartments.ContainsKey(destination)))
            { error = "Unknown destination."; return false; }
            if (locations[id] == destination) { error = "Already placed."; return false; }
            if (Revision == long.MaxValue) { error = "Revision exhausted."; return false; }
            if (!CanPlace(id, destination, out error)) return false;
            token = Guid.NewGuid();
            issued.Add(token, new Proposal { Item = id, From = locations[id], To = destination, Revision = Revision });
            return true;
        }
        public bool Commit(Guid token, out string error)
        {
            lock (stateGate) return CommitCore(token, out error);
        }
        private bool CommitCore(Guid token, out string error)
        {
            if (!issued.TryGetValue(token, out var proposal)) { error = "Invalid or consumed ticket."; return false; }
            issued.Remove(token);
            if (proposal.Revision != Revision || locations[proposal.Item] != proposal.From)
            { error = "Stale proposal."; return false; }
            if (Revision == long.MaxValue) { error = "Revision exhausted."; return false; }
            if (!CanPlace(proposal.Item, proposal.To, out error)) return false;
            var item = items[proposal.Item];
            if (proposal.From != Tray) { occupancy[proposal.From]--; totalWeight[proposal.From] -= item.Weight; }
            if (proposal.To != Tray) { occupancy[proposal.To]++; totalWeight[proposal.To] += item.Weight; }
            locations[proposal.Item] = proposal.To;
            Revision++; issued.Clear(); error = null;
            return true;
        }
        public bool Move(string id, string destination, out string error)
        {
            lock (stateGate) return PrepareCore(id, destination, revision, out Guid ticket, out error) && CommitCore(ticket, out error);
        }

        private bool CanPlace(string id, string destination, out string error)
        {
            error = null;
            if (destination != Tray)
            {
                var item = items[id]; var bin = compartments[destination];
                if (item.Tag != bin.Tag) { error = "Wrong symbol."; return false; }
                if (occupancy[destination] >= bin.Capacity) { error = "Compartment full."; return false; }
                if (totalWeight[destination] + item.Weight > bin.MaxWeight) { error = "Weight limit."; return false; }
            }
            if (rules.Length == 0) return true;
            var candidate = new Dictionary<string, string>(locations, StringComparer.Ordinal) { [id] = destination };
            return RulesAccept(candidate, false, out error);
        }
        private bool RulesAccept(Dictionary<string, string> positions, bool completion, out string error)
        {
            var view = new ReadOnlyDictionary<string, string>(positions);
            foreach (var rule in rules) if (!rule.Accepts(view, itemView, completion, out error)) return false;
            error = null; return true;
        }
        public bool Solved
        {
            get
            {
                lock (stateGate) return locations.Values.All(x => x != Tray) &&
                    (requiredLocations == null || requiredLocations.All(x => locations[x.Key] == x.Value)) &&
                    RulesAccept(locations, true, out _);
            }
        }
        public void Reset()
        {
            lock (stateGate) ResetCore();
        }
        private void ResetCore()
        {
            if (Revision == long.MaxValue) throw new InvalidOperationException("Revision exhausted.");
            foreach (string id in items.Keys) locations[id] = Tray;
            foreach (string id in compartments.Keys) { occupancy[id] = 0; totalWeight[id] = 0; }
            Revision++; issued.Clear();
        }
        public bool Restore(IDictionary<string, string> saved)
        {
            lock (stateGate) return RestoreCore(saved);
        }
        private bool RestoreCore(IDictionary<string, string> saved)
        {
            if (saved == null || Revision == long.MaxValue) return false;
            var candidate = new Dictionary<string, string>(saved, StringComparer.Ordinal);
            if (!ValidateSnapshot(candidate, false, out var counts, out var weights, out _)) return false;
            // Validate a simultaneous snapshot, not a sorted sequence of intermediate moves.
            locations = candidate; occupancy = counts; totalWeight = weights;
            Revision++; issued.Clear();
            return true;
        }
        private bool ValidateSnapshot(Dictionary<string, string> candidate, bool completion,
            out Dictionary<string, int> counts, out Dictionary<string, long> weights, out string error)
        {
            counts = compartments.Keys.ToDictionary(x => x, x => 0, StringComparer.Ordinal);
            weights = compartments.Keys.ToDictionary(x => x, x => 0L, StringComparer.Ordinal);
            error = "Invalid board snapshot.";
            if (candidate.Count != items.Count) return false;
            foreach (var pair in candidate)
            {
                if (!items.TryGetValue(pair.Key, out var item) || string.IsNullOrWhiteSpace(pair.Value)) return false;
                if (pair.Value == Tray) { if (completion) return false; continue; }
                if (!compartments.TryGetValue(pair.Value, out var bin) || bin.Tag != item.Tag) return false;
                if (++counts[pair.Value] > bin.Capacity) return false;
                weights[pair.Value] += item.Weight;
                if (weights[pair.Value] > bin.MaxWeight) return false;
            }
            return RulesAccept(candidate, completion, out error);
        }
    }
}
