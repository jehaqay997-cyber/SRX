using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>Pure progression rules. No Unity, storage, or UI dependencies.</summary>
    public static class CampaignRules
    {
        public const int LevelsPerChapter = 3;
        public const int ChapterCount = 4;
        public const int LevelCount = LevelsPerChapter * ChapterCount;

        public static int ChapterOf(int level)
        {
            ValidateLevel(level);
            return level / LevelsPerChapter;
        }

        public static bool IsGate(int level)
        {
            ValidateLevel(level);
            return (level + 1) % LevelsPerChapter == 0;
        }

        public static bool CanEnter(int level, int highestUnlocked)
        {
            ValidateLevel(level);
            return highestUnlocked >= 0 && level <= Math.Min(highestUnlocked, LevelCount - 1);
        }

        public static int UnlockAfterCompletion(int completedLevel, int highestUnlocked)
        {
            ValidateLevel(completedLevel);
            if (!CanEnter(completedLevel, highestUnlocked))
                throw new InvalidOperationException("Cannot complete a locked level");
            return Math.Max(highestUnlocked, Math.Min(completedLevel + 1, LevelCount - 1));
        }

        public static void ValidateLevel(int level)
        {
            if (level < 0 || level >= LevelCount) throw new ArgumentOutOfRangeException(nameof(level));
        }
    }
}
