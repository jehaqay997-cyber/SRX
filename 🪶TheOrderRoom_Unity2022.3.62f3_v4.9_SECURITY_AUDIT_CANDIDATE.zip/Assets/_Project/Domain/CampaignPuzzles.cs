using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace TheOrderRoom.Domain
{
    public sealed class PuzzleDefinition
    {
        public int Level { get; }
        public string Title { get; }
        public string Brief { get; }
        public string Revelation { get; }
        public IReadOnlyList<Item> Items { get; }
        public IReadOnlyList<Compartment> Compartments { get; }
        public IReadOnlyList<PuzzleRule> Rules { get; }
        public IReadOnlyDictionary<string, string> Solution { get; }
        public bool ExactIdentityRequired { get; }
        public PuzzleDefinition(int level, string title, string brief, string revelation,
            IEnumerable<Item> items, IEnumerable<Compartment> bins, IEnumerable<PuzzleRule> rules,
            IReadOnlyDictionary<string, string> solution, bool exactIdentityRequired)
        {
            CampaignRules.ValidateLevel(level);
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(brief) || string.IsNullOrWhiteSpace(revelation))
                throw new ArgumentException("Puzzle narrative is incomplete.");
            if (items == null || bins == null || rules == null || solution == null) throw new ArgumentNullException();
            Level = level; Title = title; Brief = brief; Revelation = revelation;
            Items = Array.AsReadOnly(items.ToArray());
            Compartments = Array.AsReadOnly(bins.ToArray());
            Rules = Array.AsReadOnly(rules.ToArray());
            Solution = new ReadOnlyDictionary<string, string>(solution.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal));
            ExactIdentityRequired = exactIdentityRequired;
            LevelRules.Validate(Items, Compartments);
            var board = CreateBoard();
            if (!board.Restore(new Dictionary<string, string>(Solution)) || !board.Solved)
                throw new ArgumentException("Authored solution does not satisfy the puzzle.");
        }
        public OrderBoard CreateBoard() => new OrderBoard(Items, Compartments,
            ExactIdentityRequired ? Solution : null, Rules);
    }

    public static class CampaignPuzzles
    {
        public const int ContentVersion = 1;
        private static readonly string[] Tags = { "SUN", "MOON", "STAR" };
        private static readonly string[] Titles =
        {
            "The Misfiled Signal", "The Weight of a Message", "The First Seal",
            "The Witnesses Apart", "The Archive Needs a Key", "The Testimony Lock",
            "The Two Pendulums", "The Missing Seconds", "The Clock That Lied",
            "The Divided Memory", "The Price of Passage", "The Last Honest Door"
        };
        private static readonly string[] Briefs =
        {
            "Return every object to its matching symbol. The first arrangement restores a lost transmission.",
            "The SUN drawers carry weight quotas. Read each item's W value and fill both drawers exactly.",
            "For every symbol, lower item numbers fill A first; higher numbers fill B. Recover the first seal.",
            "MOON_1 and MOON_2 cannot share a drawer. Their testimonies were recorded in different rooms.",
            "Meet SUN and MOON weight quotas. Place each drawer's first key before its dependent objects.",
            "Meet the drawer weight quotas and keep the named witnesses apart. Each symbol's first item unlocks its remaining objects.",
            "Keep the SUN drawers within one object of each other after every move. Alternate the pendulums.",
            "Every pair of drawers has weight quotas. Reconstruct the clock from the totals rather than appearance.",
            "Meet every weight quota while keeping paired counts within one. Place each symbol's first key before its other objects.",
            "Balance SUN and MOON counts after every move. MOON_1 and MOON_2 must remain apart.",
            "Meet every weight quota. The first item of each symbol unlocks the remaining objects of that symbol.",
            "Combine exact weights, balanced counts, separated evidence and first-key dependencies. Any arrangement satisfying the visible rules is accepted."
        };
        private static readonly string[] Revelations =
        {
            "The signal was addressed to the curator, not the missing archivist.",
            "The message's weight changed after someone removed a page.",
            "The seal identifies a witness whose name was erased from the archive.",
            "The two witnesses never met; the curator combined their statements.",
            "Only the archivist's key could open the original testimony.",
            "The restored testimony places the curator inside the sealed room.",
            "The pendulums disagree because one was stopped deliberately.",
            "The missing seconds reveal when the archive was altered.",
            "The clock was accurate; the written timeline was the lie.",
            "One memory belongs to the witness, the other to the person who rewrote it.",
            "The passage requires evidence, not the destruction of a memory.",
            "The last door opens onto the unedited archive. The missing archivist preserved the truth."
        };
        // Lazy initialization avoids recreating a solver and definitions during every save scan.
        private static readonly Lazy<PuzzleDefinition>[] Definitions = Enumerable.Range(0, CampaignRules.LevelCount)
            .Select(level => new Lazy<PuzzleDefinition>(() => Build(level))).ToArray();
        public static PuzzleDefinition Get(int level)
        {
            CampaignRules.ValidateLevel(level);
            return Definitions[level].Value;
        }
        private static PuzzleDefinition Build(int level)
        {
            int chapter = level / 3, stage = level % 3;
            var items = new List<Item>(); var bins = new List<Compartment>();
            var rules = new List<PuzzleRule>();
            var solution = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (string tag in Tags)
            {
                int tagIndex = Array.IndexOf(Tags, tag);
                int count = 2 + chapter + (stage >= 1 && tagIndex == stage - 1 ? 1 : 0);
                var group = Enumerable.Range(0, count).Select(i =>
                    new Item(tag + "_" + (i + 1), tag, 1 + (i + chapter + tagIndex) % 3)).ToArray();
                items.AddRange(group);
                int total = group.Sum(x => x.Weight);
                bool split = stage == 2 || (stage == 1 && (chapter >= 2 || tag == "SUN" || (chapter == 1 && tag == "MOON"))) ||
                    (stage == 0 && ((chapter == 1 && tag == "MOON") || (chapter == 2 && tag == "SUN") ||
                    (chapter == 3 && (tag == "SUN" || tag == "MOON"))));
                if (!split)
                {
                    bins.Add(new Compartment(tag, tag, count, total));
                    foreach (var item in group) solution.Add(item.Id, tag);
                    continue;
                }
                int firstCount = (count + 1) / 2;
                bins.Add(new Compartment(tag + "_A", tag, firstCount, total));
                bins.Add(new Compartment(tag + "_B", tag, count - firstCount, total));
                bool alternating = stage == 0 && chapter >= 1;
                for (int i = 0; i < group.Length; i++)
                    solution.Add(group[i].Id, tag + ((alternating ? i % 2 == 0 : i < firstCount) ? "_A" : "_B"));
                if (stage == 1 || (stage == 2 && chapter >= 1))
                {
                    foreach (string binId in new[] { tag + "_A", tag + "_B" })
                        rules.Add(new WeightQuotaRule(binId, group.Where(x => solution[x.Id] == binId).Sum(x => (long)x.Weight)));
                }
                if ((stage == 0 && chapter >= 2) || (stage == 2 && chapter >= 2))
                    rules.Add(new CountBalanceRule(tag + "_A", tag + "_B"));
                if (stage == 0 && (chapter == 1 || chapter == 3) && tag == "MOON")
                    rules.Add(new SeparatedPairRule(group[0].Id, group[1].Id));
                if ((stage == 2 && chapter == 1 && tag == "MOON") || level == 11)
                    rules.Add(new SeparatedPairRule(group[0].Id, group[firstCount].Id));
                if ((stage == 1 && chapter >= 1) || (stage == 2 && chapter >= 1))
                {
                    foreach (var dependent in group.Skip(1))
                        rules.Add(new PrerequisiteRule(dependent.Id, group[0].Id));
                }
            }
            return new PuzzleDefinition(level, Titles[level], Briefs[level], Revelations[level],
                items, bins, rules, solution, level == 2);
        }
    }
}
