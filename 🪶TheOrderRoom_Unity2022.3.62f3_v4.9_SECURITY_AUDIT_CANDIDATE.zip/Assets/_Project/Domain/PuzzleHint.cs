using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public static class PuzzleHint
    {
        // Produces one legal suggestion. It does not promise a globally shortest solution.
        public static bool TrySuggest(PuzzleDefinition definition, OrderBoard current,
            out string itemId, out string destination)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (current == null) throw new ArgumentNullException(nameof(current));
            itemId = null; destination = null;
            if (current.Solved) return false;
            var snapshot = new Dictionary<string, string>(current.Snapshot(), StringComparer.Ordinal);
            var probe = definition.CreateBoard();
            if (!probe.Restore(snapshot)) return false;
            foreach (var item in definition.Items)
            {
                string target = definition.Solution[item.Id];
                if (snapshot[item.Id] != target && probe.Prepare(item.Id, target, probe.Revision, out _, out _))
                { itemId = item.Id; destination = target; return true; }
            }
            // Remove a conflicting placement before offering a less specific legal removal.
            for (int pass = 0; pass < 2; pass++)
                foreach (var item in definition.Items)
                {
                    if (snapshot[item.Id] == OrderBoard.Tray ||
                        (pass == 0 && snapshot[item.Id] == definition.Solution[item.Id])) continue;
                    if (probe.Prepare(item.Id, OrderBoard.Tray, probe.Revision, out _, out _))
                    { itemId = item.Id; destination = OrderBoard.Tray; return true; }
                }
            return false;
        }
    }
}
