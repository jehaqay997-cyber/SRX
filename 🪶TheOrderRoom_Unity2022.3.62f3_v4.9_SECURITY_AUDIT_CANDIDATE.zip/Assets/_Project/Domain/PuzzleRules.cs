using System;
using System.Collections.Generic;
using System.Linq;

namespace TheOrderRoom.Domain
{
    public abstract class PuzzleRule
    {
        public abstract string Description { get; }
        public abstract void ValidateDefinition(IReadOnlyDictionary<string, Item> items,
            IReadOnlyDictionary<string, Compartment> bins);
        public abstract bool Accepts(IReadOnlyDictionary<string, string> positions,
            IReadOnlyDictionary<string, Item> items, bool completion, out string error);
        protected static string Identifier(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Rule identifier is required.");
            return value;
        }
    }

    public sealed class WeightQuotaRule : PuzzleRule
    {
        public string BinId { get; }
        public long RequiredWeight { get; }
        public WeightQuotaRule(string binId, long requiredWeight)
        {
            BinId = Identifier(binId);
            if (requiredWeight < 1) throw new ArgumentOutOfRangeException(nameof(requiredWeight));
            RequiredWeight = requiredWeight;
        }
        public override string Description => BinId + " requires total weight " + RequiredWeight + ".";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items,
            IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!bins.TryGetValue(BinId, out var bin) || RequiredWeight > bin.MaxWeight)
                throw new ArgumentException("Invalid weight quota.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions,
            IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            long weight = 0;
            foreach (var pair in positions) if (pair.Value == BinId) weight += items[pair.Key].Weight;
            bool accepted = weight <= RequiredWeight && (!completion || weight == RequiredWeight);
            error = accepted ? null : Description;
            return accepted;
        }
    }

    public sealed class SeparatedPairRule : PuzzleRule
    {
        public string First { get; }
        public string Second { get; }
        public SeparatedPairRule(string first, string second)
        {
            First = Identifier(first); Second = Identifier(second);
            if (First == Second) throw new ArgumentException("A separated pair needs different items.");
        }
        public override string Description => First + " and " + Second + " must occupy different bins.";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items,
            IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!items.ContainsKey(First) || !items.ContainsKey(Second))
                throw new ArgumentException("Unknown separated item.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions,
            IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            bool accepted = positions[First] == OrderBoard.Tray || positions[Second] == OrderBoard.Tray ||
                positions[First] != positions[Second];
            error = accepted ? null : Description;
            return accepted;
        }
    }

    public sealed class PrerequisiteRule : PuzzleRule
    {
        public string ItemId { get; }
        public string RequiredItemId { get; }
        public PrerequisiteRule(string itemId, string requiredItemId)
        {
            ItemId = Identifier(itemId); RequiredItemId = Identifier(requiredItemId);
            if (ItemId == RequiredItemId) throw new ArgumentException("An item cannot require itself.");
        }
        public override string Description => "Place " + RequiredItemId + " before " + ItemId +
            "; remove the dependent item before removing its key.";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items,
            IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!items.ContainsKey(ItemId) || !items.ContainsKey(RequiredItemId))
                throw new ArgumentException("Unknown prerequisite item.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions,
            IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            bool accepted = positions[ItemId] == OrderBoard.Tray || positions[RequiredItemId] != OrderBoard.Tray;
            error = accepted ? null : Description;
            return accepted;
        }
    }

    public sealed class CountBalanceRule : PuzzleRule
    {
        public string FirstBin { get; }
        public string SecondBin { get; }
        public CountBalanceRule(string firstBin, string secondBin)
        {
            FirstBin = Identifier(firstBin); SecondBin = Identifier(secondBin);
            if (FirstBin == SecondBin) throw new ArgumentException("Balance requires two different bins.");
        }
        public override string Description => FirstBin + " and " + SecondBin + " must differ by at most one item after every move.";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items,
            IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!bins.ContainsKey(FirstBin) || !bins.ContainsKey(SecondBin))
                throw new ArgumentException("Unknown balance bin.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions,
            IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            int difference = 0;
            foreach (string bin in positions.Values)
            {
                if (bin == FirstBin) difference++;
                if (bin == SecondBin) difference--;
            }
            bool accepted = Math.Abs((long)difference) <= 1;
            error = accepted ? null : Description;
            return accepted;
        }
    }
}
