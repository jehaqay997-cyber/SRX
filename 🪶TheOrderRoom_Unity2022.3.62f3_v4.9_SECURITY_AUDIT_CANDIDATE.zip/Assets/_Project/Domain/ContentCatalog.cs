using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public sealed class ContentPack
    {
        public string Id { get; }
        public string DisplayName { get; }
        public bool IsFree { get; }
        public int PuzzleCount { get; }
        public ContentPack(string id, string displayName, bool isFree, int puzzleCount)
        {
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(displayName) || puzzleCount <= 0)
                throw new ArgumentException("Invalid content pack");
            Id = id; DisplayName = displayName; IsFree = isFree; PuzzleCount = puzzleCount;
        }
    }

    public static class ContentCatalog
    {
        public const string BasePack = "theorderroom.base";
        public const string MiniatureWorlds = "theorderroom.miniature_worlds";
        public const string LivingGallery = "theorderroom.living_gallery";
        public const string ForbiddenExhibition = "theorderroom.forbidden_exhibition";
        private static readonly ContentPack[] Packs =
        {
            new ContentPack(BasePack, "The Grand Opening", true, 12),
            new ContentPack(MiniatureWorlds, "The Miniature Worlds", false, 9),
            new ContentPack(LivingGallery, "The Living Gallery", false, 9),
            new ContentPack(ForbiddenExhibition, "The Forbidden Exhibition", false, 9)
        };
        public static IReadOnlyList<ContentPack> All => Array.AsReadOnly(Packs);
        public static bool TryGet(string id, out ContentPack pack)
        {
            foreach (var entry in Packs)
                if (string.Equals(entry.Id, id, StringComparison.Ordinal)) { pack = entry; return true; }
            pack = null; return false;
        }
    }

    public interface IEntitlementProvider
    {
        bool Owns(string productId);
    }

    /// <summary>Fail-closed paid access; this provider grants only bundled free content.</summary>
    public sealed class FreeContentEntitlements : IEntitlementProvider
    {
        public bool Owns(string productId) =>
            ContentCatalog.TryGet(productId, out var pack) && pack.IsFree;
    }

    public sealed class ContentAccessPolicy
    {
        private readonly IEntitlementProvider entitlements;
        public ContentAccessPolicy(IEntitlementProvider entitlements)
        {
            this.entitlements = entitlements ?? throw new ArgumentNullException(nameof(entitlements));
        }
        public bool CanOpen(string packId) =>
            ContentCatalog.TryGet(packId, out var pack) && (pack.IsFree || entitlements.Owns(pack.Id));
    }
}
