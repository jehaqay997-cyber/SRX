using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>Idempotent collection ledger. Persistence is an application concern.</summary>
    public sealed class ArtifactLedger
    {
        private readonly HashSet<string> discovered = new HashSet<string>(StringComparer.Ordinal);
        public int Count => discovered.Count;
        public bool Discover(string artifactId)
        {
            if (string.IsNullOrWhiteSpace(artifactId) || artifactId.Length > 128) throw new ArgumentException("Invalid artifact ID", nameof(artifactId));
            return discovered.Add(artifactId);
        }
        public bool Contains(string artifactId) => artifactId != null && discovered.Contains(artifactId);
        public string[] Snapshot()
        {
            var values = new string[discovered.Count];
            discovered.CopyTo(values);
            Array.Sort(values, StringComparer.Ordinal);
            return values;
        }
        public bool TryRestore(IEnumerable<string> ids)
        {
            if (ids == null) return false;
            var next = new HashSet<string>(StringComparer.Ordinal);
            foreach (var id in ids)
                if (string.IsNullOrWhiteSpace(id) || id.Length > 128 || !next.Add(id) || next.Count > 1024) return false;
            discovered.Clear();
            foreach (var id in next) discovered.Add(id);
            return true;
        }
    }
}
