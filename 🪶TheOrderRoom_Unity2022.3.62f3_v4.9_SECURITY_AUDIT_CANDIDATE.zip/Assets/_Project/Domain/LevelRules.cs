using System;
using System.Collections.Generic;
using System.Linq;

namespace TheOrderRoom.Domain
{
    /// <summary>Rejects malformed or impossible tag-constrained level definitions.</summary>
    public static class LevelRules
    {
        public static void Validate(IEnumerable<Item> items, IEnumerable<Compartment> compartments)
        {
            if (items == null || compartments == null) throw new ArgumentNullException();
            var itemList = items.ToList();
            var bins = compartments.ToList();
            if (itemList.Count == 0 || bins.Count == 0) throw new ArgumentException("Empty level");
            if (itemList.Any(x => x == null) || bins.Any(x => x == null)) throw new ArgumentException("Null definition");
            if (itemList.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != itemList.Count ||
                bins.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != bins.Count)
                throw new ArgumentException("Duplicate identifiers");
            if (itemList.Any(x => x.Id == OrderBoard.Tray) || bins.Any(x => x.Id == OrderBoard.Tray))
                throw new ArgumentException("Reserved identifier");
            foreach (var group in itemList.GroupBy(x => x.Tag, StringComparer.Ordinal))
            {
                var candidates = bins.Where(x => x.Tag == group.Key).ToList();
                if (candidates.Count == 0) throw new ArgumentException("Missing compartment for " + group.Key);
                if (candidates.Sum(x => (long)x.Capacity) < group.Count() ||
                    candidates.Sum(x => (long)x.MaxWeight) < group.Sum(x => (long)x.Weight))
                    throw new ArgumentException("Insufficient capacity for " + group.Key);
                if (group.Any(x => candidates.All(c => x.Weight > c.MaxWeight)))
                    throw new ArgumentException("Unplaceable item in " + group.Key);
            }
            // Necessary constraints only: for multiple same-tag bins, use exact solver before publishing.
        }
    }
}
