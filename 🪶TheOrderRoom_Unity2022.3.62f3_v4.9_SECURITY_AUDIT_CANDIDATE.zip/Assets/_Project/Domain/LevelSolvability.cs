using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace TheOrderRoom.Domain
{
    public enum SolvabilityStatus { Solvable, Unsolvable, BudgetExceeded }

    /// <summary>Bounded, deterministic, iterative feasibility search. No recursion or Unity dependencies.</summary>
    public static class LevelSolvability
    {
        public static bool HasSolution(IEnumerable<Item> items, IEnumerable<Compartment> compartments, int nodeLimit = 1000000)
            => TryFindSolution(items, compartments, out _, nodeLimit);

        // Preserve the legacy API contract: budget exhaustion throws rather than claiming unsolvability.
        public static bool TryFindSolution(IEnumerable<Item> items, IEnumerable<Compartment> compartments,
            out IReadOnlyDictionary<string, string> assignment, int nodeLimit = 1000000)
        {
            var status = Analyze(items, compartments, out assignment, nodeLimit);
            if (status == SolvabilityStatus.BudgetExceeded)
                throw new InvalidOperationException("Solver search budget exceeded");
            return status == SolvabilityStatus.Solvable;
        }

        /// <summary>Returns an explicit third state when the node budget is exhausted.</summary>
        public static SolvabilityStatus Analyze(IEnumerable<Item> items, IEnumerable<Compartment> compartments,
            out IReadOnlyDictionary<string, string> assignment, int nodeLimit = 1000000)
        {
            assignment = null;
            if (items == null) throw new ArgumentNullException(nameof(items));
            if (compartments == null) throw new ArgumentNullException(nameof(compartments));
            if (nodeLimit < 1) throw new ArgumentOutOfRangeException(nameof(nodeLimit));

            var objects = items.ToArray();
            var bins = compartments.ToArray();
            LevelRules.Validate(objects, bins);
            objects = objects.OrderByDescending(x => x.Weight)
                .ThenBy(x => x.Id, StringComparer.Ordinal).ToArray();

            var counts = new int[bins.Length];
            var weights = new long[bins.Length];
            var chosen = new int[objects.Length];
            var nextBin = new int[objects.Length];
            int depth = 0;
            long explored = 0;
            while (depth >= 0)
            {
                if (depth == objects.Length)
                {
                    var result = new Dictionary<string, string>(objects.Length, StringComparer.Ordinal);
                    for (int i = 0; i < objects.Length; i++) result.Add(objects[i].Id, bins[chosen[i]].Id);
                    assignment = new ReadOnlyDictionary<string, string>(result);
                    return SolvabilityStatus.Solvable;
                }

                if (nextBin[depth] == 0 && ++explored > nodeLimit)
                    return SolvabilityStatus.BudgetExceeded;

                var item = objects[depth];
                bool placed = false;
                while (nextBin[depth] < bins.Length)
                {
                    int j = nextBin[depth]++;
                    if (!StringComparer.Ordinal.Equals(item.Tag, bins[j].Tag) ||
                        counts[j] >= bins[j].Capacity || weights[j] + item.Weight > bins[j].MaxWeight)
                        continue;
                    chosen[depth] = j;
                    counts[j]++;
                    weights[j] += item.Weight;
                    depth++;
                    if (depth < objects.Length) nextBin[depth] = 0;
                    placed = true;
                    break;
                }
                if (placed) continue;
                nextBin[depth] = 0;
                depth--;
                if (depth >= 0)
                {
                    int previousBin = chosen[depth];
                    counts[previousBin]--;
                    weights[previousBin] -= objects[depth].Weight;
                }
            }
            return SolvabilityStatus.Unsolvable;
        }
    }
}
