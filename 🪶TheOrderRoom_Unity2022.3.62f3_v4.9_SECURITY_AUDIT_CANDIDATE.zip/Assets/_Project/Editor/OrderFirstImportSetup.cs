#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>Creates a scene only in a fresh project, after script compilation.</summary>
    [InitializeOnLoad]
    public static class OrderFirstImportSetup
    {
        private const string ScenePath = "Assets/_Project/Scenes/Main.unity";
        private const string OptOutMarker = "Assets/_Project/Scenes/.skip-auto-bootstrap";
        static OrderFirstImportSetup()
        {
            EditorApplication.delayCall += TryInitialize;
        }
        private static void TryInitialize()
        {
            if (File.Exists(ScenePath) || File.Exists(OptOutMarker) || Application.isBatchMode ||
                EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += TryInitialize;
                return;
            }
            // Do not replace a user's currently open modified scene.
            if (EditorSceneManager.GetActiveScene().isDirty) return;
            try { OrderProjectBootstrap.Build(); }
            catch (System.Exception e)
            {
                Debug.LogError("TheOrderRoom scene bootstrap failed; use TheOrderRoom/Create Integrated Scene manually. " + e);
            }
        }
    }
}
#endif
