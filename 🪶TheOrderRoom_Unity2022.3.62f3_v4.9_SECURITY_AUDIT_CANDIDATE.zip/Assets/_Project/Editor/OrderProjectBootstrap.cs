#if UNITY_EDITOR
using System.IO;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheOrderRoom.Editor
{
    public static class OrderProjectBootstrap
    {
        private const string ScenePath = "Assets/_Project/Scenes/Main.unity";
        // First import may call this only when the scene is absent and open scenes are clean.
        [MenuItem("TheOrderRoom/Create Integrated Scene (Non-Destructive)")]
        public static void Build()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (File.Exists(ScenePath))
            {
                EditorUtility.DisplayDialog("TheOrderRoom", "Main.unity already exists. It was not overwritten.", "OK");
                return;
            }
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            Directory.CreateDirectory("Assets/_Project/Scenes");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("TheOrderRoom");
            var game = root.AddComponent<OrderGame>();
            var pointer = root.AddComponent<OrderPointerInput>(); pointer.Game = game;
            var world = new GameObject("PuzzleWorld").transform; world.SetParent(root.transform);
            var pieces = new GameObject("Pieces").transform; pieces.SetParent(world);
            var services = new GameObject("Systems"); services.transform.SetParent(root.transform);
            var lighting = new GameObject("Lighting"); lighting.transform.SetParent(root.transform);
            var targets = new GameObject("Targets"); targets.transform.SetParent(world);
            var cameraObject = new GameObject("Main Camera"); cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(root.transform);
            var camera = cameraObject.AddComponent<Camera>(); cameraObject.AddComponent<AudioListener>();
            camera.transform.position = new Vector3(0, 9, -13); camera.transform.LookAt(Vector3.zero);
            camera.cullingMask &= ~ArtifactInspectionView.InspectionMask;
            camera.fieldOfView = 53; camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.055f, .085f, .13f);
            var light = new GameObject("Key Light").AddComponent<Light>();
            light.transform.SetParent(lighting.transform);
            light.type = LightType.Directional; light.intensity = 1.2f;
            light.color = new Color(1f, .85f, .68f); light.transform.rotation = Quaternion.Euler(45, -30, 0);
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "Antique Table"; floor.transform.SetParent(world); floor.transform.position = new Vector3(0, -.35f, 0);
            floor.transform.localScale = new Vector3(12, .4f, 7);
            floor.GetComponent<Renderer>().sharedMaterial = MakeEditorMaterial("Table", new Color(.20f, .24f, .27f));
            foreach (var tag in new[] { "SUN", "MOON", "STAR", "SUN_A", "SUN_B", "MOON_A", "MOON_B", "STAR_A", "STAR_B", "TRAY" })
            {
                var target = GameObject.CreatePrimitive(PrimitiveType.Cube);
                target.name = tag + " Target"; target.transform.SetParent(targets.transform);
                target.transform.position = new Vector3(tag.StartsWith("SUN") ? -3.4f : tag.StartsWith("MOON") ? 0 : tag.StartsWith("STAR") ? 3.4f : 0, -.05f, tag == "TRAY" ? -1.7f : tag.EndsWith("_A") ? .5f : tag.EndsWith("_B") ? 2.0f : 1.1f);
                target.transform.localScale = new Vector3(tag == "TRAY" ? 6.8f : 2.6f, .15f, tag == "TRAY" ? 2.5f : tag.Contains("_") ? 1.1f : 2.5f);
                target.GetComponent<Renderer>().sharedMaterial = MakeEditorMaterial(tag,
                    tag.StartsWith("SUN") ? new Color(.4f, .3f, .16f) : tag.StartsWith("MOON") ? new Color(.17f, .3f, .4f) : tag.StartsWith("STAR") ? new Color(.3f, .22f, .38f) : new Color(.3f, .29f, .26f));
                var targetLabel = new GameObject(tag + " Label", typeof(TextMesh));
                targetLabel.transform.SetParent(targets.transform, false);
                targetLabel.transform.position = target.transform.position + new Vector3(0f, .2f, tag.Contains("_") ? -.48f : tag == "TRAY" ? -1.1f : -.95f);
                targetLabel.transform.rotation = Quaternion.Euler(55f, 0f, 0f);
                var targetText = targetLabel.GetComponent<TextMesh>();
                targetText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                targetText.GetComponent<MeshRenderer>().sharedMaterial = targetText.font.material;
                targetText.text = tag;
                targetText.fontSize = 32;
                targetText.characterSize = .08f;
                targetText.anchor = TextAnchor.MiddleCenter;
                targetText.color = Color.white;
                targetLabel.transform.SetParent(target.transform, true);
                var destination = target.AddComponent<OrderDestination>(); destination.Game = game; destination.Destination = tag; destination.Label = targetText;
            }
            var eventSystem = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            eventSystem.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            eventSystem.AddComponent<StandaloneInputModule>();
#endif
            eventSystem.transform.SetParent(services.transform);
            var canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(root.transform);
            var canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasObject.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720); scaler.matchWidthOrHeight = .5f;
            var title = MakeText("Title", canvas.transform, "THE ORDER ROOM", new Vector2(0, 260), new Vector2(780, 70), 32);
            var status = MakeText("Status", canvas.transform, "Loading", new Vector2(0, -155), new Vector2(1100, 65), 24);
            AddButton("RESET", canvas.transform, new Vector2(-450, -320), game, "ResetBoard");
            AddButton("UNDO", canvas.transform, new Vector2(-150, -320), game, "Undo");
            AddButton("REDO", canvas.transform, new Vector2(150, -320), game, "Redo");
            AddButton("NEXT", canvas.transform, new Vector2(450, -320), game, "NextLevel");
            AddSymbol(canvas.transform, "SUN", "sun.png", new Vector2(-350, 155));
            AddSymbol(canvas.transform, "MOON", "moon.png", new Vector2(0, 155));
            AddSymbol(canvas.transform, "STAR", "star.png", new Vector2(350, 155));
            var collection = MakeText("Collection Journal", canvas.transform, "COLLECTION", new Vector2(0, 212), new Vector2(1120, 52), 17);
            var reveal = MakeText("Artifact Reveal", canvas.transform, "DISCOVERED", new Vector2(0, 0), new Vector2(1080, 180), 26);
            reveal.color = new Color(1f, .84f, .48f);
            game.Configure(title, status, pieces, camera);
            game.ConfigureCollection(collection, reveal);
            var rulesPanel = new GameObject("Puzzle Rules", typeof(RectTransform), typeof(Image));
            rulesPanel.transform.SetParent(canvas.transform, false);
            var rulesRect = (RectTransform)rulesPanel.transform;
            rulesRect.anchorMin = rulesRect.anchorMax = new Vector2(.5f, .5f);
            rulesRect.anchoredPosition = new Vector2(0, 20);
            rulesRect.sizeDelta = new Vector2(1120, 420);
            rulesPanel.GetComponent<Image>().color = new Color(.03f, .05f, .08f, .98f);
            var rulesText = MakeText("Rule Details", rulesPanel.transform, "", Vector2.zero, new Vector2(1080, 390), 18);
            rulesText.alignment = TextAnchor.UpperLeft;
            rulesText.resizeTextForBestFit = true; rulesText.resizeTextMinSize = 14; rulesText.resizeTextMaxSize = 18;
            game.ConfigureRules(rulesText, rulesPanel);
            AddButton("RULES", canvas.transform, new Vector2(-520, 285), game, "ShowRules");
            AddButton("HINT", canvas.transform, new Vector2(520, 285), game, "Hint");
            // Dedicated inspectable 3D object: created inactive and activated only after solving.
            var inspectionObject = new GameObject("Artifact Inspection");
            inspectionObject.transform.SetParent(root.transform, false);
            inspectionObject.transform.position = new Vector3(0f, 2.0f, 1.2f);
            var inspectionView = inspectionObject.AddComponent<ArtifactInspectionView>();
            var inspectionText = MakeText("Inspection Instructions", canvas.transform, "", new Vector2(0, -195), new Vector2(1050, 58), 23);
            game.ConfigureInspection(inspectionView, inspectionText);
            AddButton("INSPECT", canvas.transform, new Vector2(-390, -250), game, "InspectArtifact");
            AddButton("TURN LEFT", canvas.transform, new Vector2(-195, -250), game, "TurnArtifactLeft");
            AddButton("TURN RIGHT", canvas.transform, new Vector2(195, -250), game, "TurnArtifactRight");
            AddButton("SCAN", canvas.transform, new Vector2(0, -245), game, "ScanArtifact");
            AddButton("CLAIM", canvas.transform, new Vector2(390, -250), game, "ClaimArtifact");
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new System.IO.IOException("Failed to save generated Main scene.");
            // Explicit menu action only: do not overwrite the user's Build Settings scenes.
            if (EditorBuildSettings.scenes.Length == 0)
                EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            Debug.Log("TheOrderRoom: scene created: " + ScenePath + ". Open it and press Play.");
        }
        private static Material MakeEditorMaterial(string name, Color color)
        {
            const string directory = "Assets/_Project/Art/Materials";
            Directory.CreateDirectory(directory);
            string path = directory + "/" + name + ".mat";
            var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing != null) return existing;
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null) throw new System.InvalidOperationException("No supported Lit shader found.");
            var material = new Material(shader) { color = color };
            AssetDatabase.CreateAsset(material, path);
            return material;
        }
        private static Text MakeText(string name, Transform parent, string content, Vector2 position, Vector2 size, int fontSize)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Text)); obj.transform.SetParent(parent, false);
            var rect = (RectTransform)obj.transform; rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.sizeDelta = size; rect.anchoredPosition = position;
            var text = obj.GetComponent<Text>(); text.text = content;
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = fontSize; text.color = Color.white; text.alignment = TextAnchor.MiddleCenter;
            text.raycastTarget = false; return text;
        }
        private static void AddButton(string label, Transform parent, Vector2 position, OrderGame game, string method)
        {
            var obj = new GameObject(label, typeof(RectTransform), typeof(Image), typeof(Button)); obj.transform.SetParent(parent, false);
            var rect = (RectTransform)obj.transform; rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.sizeDelta = new Vector2(180, 62); rect.anchoredPosition = position;
            obj.GetComponent<Image>().color = new Color(.18f, .28f, .34f, .9f);
            var button = obj.GetComponent<Button>();
            // Persistent UnityEvent survives editor scene serialization (unlike runtime lambdas).
            switch (method)
            {
                case "ResetBoard": UnityEventTools.AddPersistentListener(button.onClick, game.ResetBoard); break;
                case "Undo": UnityEventTools.AddPersistentListener(button.onClick, game.Undo); break;
                case "ShowRules": UnityEventTools.AddPersistentListener(button.onClick, game.ShowRules); break;
                case "Hint": UnityEventTools.AddPersistentListener(button.onClick, game.Hint); break;
                case "Redo": UnityEventTools.AddPersistentListener(button.onClick, game.Redo); break;
                case "NextLevel": UnityEventTools.AddPersistentListener(button.onClick, game.NextLevel); break;
                case "InspectArtifact": UnityEventTools.AddPersistentListener(button.onClick, game.InspectArtifact); break;
                case "TurnArtifactLeft": UnityEventTools.AddPersistentListener(button.onClick, game.TurnArtifactLeft); break;
                case "TurnArtifactRight": UnityEventTools.AddPersistentListener(button.onClick, game.TurnArtifactRight); break;
                case "ScanArtifact": UnityEventTools.AddPersistentListener(button.onClick, game.ScanArtifact); break;
                case "ClaimArtifact": UnityEventTools.AddPersistentListener(button.onClick, game.ClaimArtifact); break;
            }
            MakeText(label + " Label", obj.transform, label, Vector2.zero, new Vector2(170, 58), 24);
        }
        private static void AddSymbol(Transform parent, string tag, string fileName, Vector2 position)
        {
            string path = "Assets/_Project/Art/PNG/" + fileName;
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null && importer.textureType != TextureImporterType.Sprite)
            { importer.textureType = TextureImporterType.Sprite; importer.SaveAndReimport(); }
            var sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
            if (sprite == null) { Debug.LogWarning("Missing symbol: " + path); return; }
            var obj = new GameObject(tag + " Symbol", typeof(RectTransform), typeof(Image)); obj.transform.SetParent(parent, false);
            var rect = (RectTransform)obj.transform; rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.sizeDelta = new Vector2(72, 72); rect.anchoredPosition = position;
            var image = obj.GetComponent<Image>(); image.sprite = sprite; image.preserveAspect = true; image.raycastTarget = false;
        }
    }
}
#endif
