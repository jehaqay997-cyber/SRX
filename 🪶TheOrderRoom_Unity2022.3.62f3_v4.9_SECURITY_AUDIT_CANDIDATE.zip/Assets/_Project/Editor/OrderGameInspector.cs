#if UNITY_EDITOR
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    [CustomEditor(typeof(OrderGame))]
    public sealed class OrderGameInspector : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            EditorGUILayout.HelpBox("Scene references are wired by the editor scene builder. Validate before running. Do not edit runtime board state here.", MessageType.Info);
            if (GUILayout.Button("Validate Project & Scene")) OrderSceneValidator.ValidateMenu();
        }
    }
}
#endif
