#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TheOrderRoom.Editor
{
    public static class OrderSceneValidator
    {
        public const string MainScene = "Assets/_Project/Scenes/Main.unity";
        [MenuItem("TheOrderRoom/Validate Project & Scene")]
        public static void ValidateMenu()
        {
            var problems = ValidateProject();
            if (problems.Count == 0) Debug.Log("TheOrderRoom: structural scene validation passed. Runtime/device verification is separate.");
            else Debug.LogError("TheOrderRoom validation failed:\n" + string.Join("\n", problems));
        }
        public static List<string> ValidateProject()
        {
            var problems = new List<string>();
            foreach (string name in new[] { "sun", "moon", "star" })
                if (AssetDatabase.LoadAssetAtPath<Sprite>("Assets/_Project/Art/PNG/" + name + ".png") == null)
                    problems.Add("Missing imported sprite: " + name);
            if (!File.Exists(MainScene)) { problems.Add("Missing generated Main scene."); return problems; }
            Scene previous = SceneManager.GetActiveScene();
            Scene scene = SceneManager.GetSceneByPath(MainScene);
            bool opened = !scene.IsValid() || !scene.isLoaded;
            try
            {
                if (opened) scene = EditorSceneManager.OpenScene(MainScene, OpenSceneMode.Additive);
                if (scene.isDirty) problems.Add("Save Main scene before validation/build.");
                ValidateScene(scene, problems);
            }
            catch (Exception error) { problems.Add("Scene validation failed: " + error.GetType().Name + ": " + error.Message); }
            finally
            {
                if (opened && scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
            }
            return problems;
        }
        private static T[] Components<T>(Scene scene) where T : Component =>
            scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<T>(true)).ToArray();
        public static void ValidateScene(Scene scene, List<string> problems)
        {
            if (!scene.IsValid() || !scene.isLoaded) { problems.Add("Scene is not loaded."); return; }
            foreach (var root in scene.GetRootGameObjects())
                foreach (var transform in root.GetComponentsInChildren<Transform>(true))
                    if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject) != 0)
                        problems.Add("Missing script: " + transform.name);
            var games = Components<OrderGame>(scene);
            if (games.Length != 1) { problems.Add("Expected exactly one OrderGame."); return; }
            var game = games[0];
            if (!game.enabled || !game.gameObject.activeInHierarchy) problems.Add("OrderGame is inactive.");
            var serialized = new SerializedObject(game);
            foreach (string name in new[] { "heading", "status", "collectionText", "revealText", "inspectionText",
                "pieces", "sceneCamera", "inspectionView", "rulesText", "rulesPanel" })
            {
                var property = serialized.FindProperty(name);
                if (property == null || property.objectReferenceValue == null) problems.Add("Unbound game reference: " + name);
                else
                {
                    var component = property.objectReferenceValue as Component;
                    var obj = property.objectReferenceValue as GameObject;
                    if ((component != null && component.gameObject.scene != scene) || (obj != null && obj.scene != scene))
                        problems.Add("Reference belongs to a different scene: " + name);
                }
            }
            var cameras = Components<Camera>(scene);
            if (cameras.Count(x => x.enabled && x.CompareTag("MainCamera")) != 1)
                problems.Add("Expected one enabled tagged main camera.");
            var systems = Components<EventSystem>(scene);
            if (systems.Length != 1 || systems[0].GetComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>() == null)
                problems.Add("Expected one EventSystem with InputSystemUIInputModule.");
            if (Components<Canvas>(scene).Length == 0) problems.Add("Missing Canvas.");
            var pointers = Components<OrderPointerInput>(scene);
            if (pointers.Length != 1 || pointers[0].Game != game) problems.Add("Expected one pointer source bound to this game.");
            var found = new HashSet<string>(StringComparer.Ordinal);
            foreach (var destination in Components<OrderDestination>(scene))
            {
                if (destination.Game != game || destination.Label == null) problems.Add("Unbound destination: " + destination.name);
                if (string.IsNullOrWhiteSpace(destination.Destination) || !found.Add(destination.Destination))
                    problems.Add("Invalid/duplicate destination: " + destination.name);
            }
            foreach (string id in new[] { "SUN", "MOON", "STAR", "SUN_A", "SUN_B", "MOON_A", "MOON_B", "STAR_A", "STAR_B", "TRAY" })
                if (!found.Contains(id)) problems.Add("Missing destination: " + id);
            var methods = new HashSet<string>(StringComparer.Ordinal);
            foreach (var button in Components<Button>(scene))
                for (int i = 0; i < button.onClick.GetPersistentEventCount(); i++)
                    if (button.onClick.GetPersistentTarget(i) == game)
                        methods.Add(button.onClick.GetPersistentMethodName(i));
            foreach (string method in new[] { "ResetBoard", "Undo", "Redo", "NextLevel", "ShowRules", "Hint",
                "InspectArtifact", "TurnArtifactLeft", "TurnArtifactRight", "ScanArtifact", "ClaimArtifact" })
                if (!methods.Contains(method)) problems.Add("Missing persistent button binding: " + method);
        }
    }
}
#endif
