#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace TheOrderRoom.Editor
{
    public static class OrderBuildPreflight
    {
        [MenuItem("TheOrderRoom/Validate Commercial Prototype")]
        public static void Validate() => OrderSceneValidator.ValidateMenu();
    }
    public sealed class OrderBuildGate : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;
        public void OnPreprocessBuild(BuildReport report)
        {
            var problems = OrderSceneValidator.ValidateProject();
            if (!EditorBuildSettings.scenes.Any(scene => scene.enabled && scene.path == OrderSceneValidator.MainScene))
                problems.Add("Main scene must be enabled in Build Settings.");
            if (problems.Count != 0) throw new BuildFailedException("TheOrderRoom build blocked:\n" + string.Join("\n", problems));
        }
    }
}
#endif
