# TheOrderRoom v3.6 — Targeted hardening and verification boundary

## Source changes
- OrderSaveStore: re-read the committed journal generation after atomic rename before reporting success. WARNING: if this verification fails, the file may already be committed; retry must not be assumed idempotent. The journal remains intact for recovery.
- OrderGame: reuse a UI raycast buffer, clear it in finally, and resolve child colliders through their parent interaction component.
- Added two EditMode regression tests for nested colliders.

## Remaining P0/P1 risks
- Crash durability of File.Move is filesystem-dependent; no device-level power-loss test.
- Cross-process read/write snapshot isolation and stale session optimistic concurrency not implemented.
- Journal quota can block saves when invalid files accumulate; requires an explicit maintenance and export workflow.
- Unity compiler, EditMode, PlayMode, and mobile profiling NOT EXECUTED.
- Do not use this overlay without a backup; import only into a copy of the Unity project.

## Verification labels
STATIC_PATCHED; ZIP_CRC_VERIFIED; UNITY_UNVERIFIED; NOT_RELEASE_READY.
