# v2.0 Persistence consistency audit

## Implemented
- Serialized TryLoad/TrySave inside the process with a shared monitor.
- Added monotonically increasing generation field to schema v1 (legacy saves default to zero).
- Recovery selects the highest-generation valid primary/backup/previous document.
- Rejects future schema from any recovery candidate without mutation.
- Save validates all existing recovery files and refuses destructive overwrite when any is unreadable.
- Stages an isolated copy of the input before setting the next generation; validates temp readback.
- Removes any non-atomic copy-based fallback.

## Limitations and open risks
- In-process monitor does not protect against separate processes or external file modification.
- If an older primary is valid but newer backup exists, next save still replaces primary; highest-generation recovery remains available through backup only until another save. A stronger journal protocol is recommended.
- File.Replace durability/atomicity is filesystem and platform dependent; Android/iOS device testing is mandatory.
- No fsync of parent directory and no cross-process lock.
- SHA-256 checksum detects accidental corruption, not adversarial modification.
- Missing or malformed schemaVersion can deserialize to default value; rejection is conservative.
- Unity compilation, NUnit execution and runtime device fault injection have not been performed.

## Status
STATIC_VERIFIED / UNITY_UNVERIFIED / NOT_RELEASE_READY
