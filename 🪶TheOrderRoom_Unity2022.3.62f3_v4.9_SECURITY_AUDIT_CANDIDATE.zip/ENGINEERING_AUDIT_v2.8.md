# TheOrderRoom v2.8 — Consistency Recovery (candidate)

## Source provenance
Based on local v2.7 CameraInputRootFix candidate. Unity project and editor execution are unavailable. This archive is an overlay, not a complete Unity project.

## Changes
- `OrderGame.Place`: stage a board copy, validate move, persist it, then publish. Failed storage leaves original board, selection, history and UI unchanged.
- `OrderGame.ResetBoard`: stage fresh board, save, then publish. No destructive reset on save failure.
- `OrderGame.Undo`: restore snapshot to candidate, save, then publish and pop history.
- `OrderGame.NextLevel`: publish the exact board used for the saved transition rather than constructing a second instance.
- `OrderGame.ClaimArtifact`: strengthen pre-commit validation and fail closed if post-save in-memory state diverges.
- `OrderSaveStore`: validate discovered artifact progression against unlocked level.

## Remaining high-risk work
- Unity compile/EditMode/PlayMode verification and simulated I/O failures are NOT EXECUTED.
- `OrderSaveStore` journal validation still does not prove semantic coherence of all historical rewards or resist deliberate tampering.
- First save with a preexisting corrupt-only journal fails closed by design.
- No cross-process lock; no full pointer ownership state machine; camera layer 30 remains a project configuration dependency.
- A post-commit view exception can leave a saved state ahead of the visible scene; recovery should reload.
- `LoadLevel` public direct calls are not persisted; should be restricted or routed through a transactional navigation API.
- Staging a new `OrderBoard` per move costs O(n + m) time and memory for n items and m compartments, with board validation potentially O(n^2) in Restore. Appropriate for small puzzle boards, not large-scale levels.

## Status
STATIC_SOURCE_PATCHED; ZIP_INTEGRITY_VERIFIED; UNITY_COMPILATION_UNVERIFIED; TESTS_NOT_EXECUTED; NOT_RELEASE_READY.
