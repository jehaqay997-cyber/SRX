# TheOrderRoom v2.1 — Append-only save journal

## Root-cause redesign
- Removed in-place replacement of primary save file for all new writes.
- New immutable generation files: `the_order_room_v1.json.g00000000000000000001.json`.
- Write to unique same-directory pending file, flush, readback-verify, then publish via `File.Move`.
- Recovery scans legacy primary/backup/previous plus journal and chooses highest valid generation.
- Future-schema saves block both loading and writing; malformed existing journal files block writes (fail closed).
- A successful publish is followed by best-effort pruning, retaining eight journal generations.
- Old legacy files are never rewritten or deleted.

## Risks / verification limits
- Same-directory rename is a visibility boundary, not proof of power-loss durability across filesystems.
- No interprocess lock: concurrent external processes may race on generation number; CreateNew/Move prevents intentional overwrite but callers must handle failures.
- A corrupted journal blocks future saves until repaired by an explicit recovery tool; this protects forensic data but affects availability.
- Journal naming and retention need actual device fault-injection tests; no Unity execution available here.
- This package is a source overlay, not a Unity build.
