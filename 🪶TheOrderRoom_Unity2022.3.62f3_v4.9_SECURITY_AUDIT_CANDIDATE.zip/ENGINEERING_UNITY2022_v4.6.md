# Unity 2022.3.62f3 - v4.6 targeted compatibility remediation

## Baseline
TheOrderRoom_v3.8_v4.5_Reconciled_CANDIDATE.zip.
Source archive SHA-256: 712e9449cf14b6cf3726afbbb842ec8f86831fd4a529347c7450f957f514313c.

## Changes
- ProjectVersion targets 2022.3.62f3.
- Pin Unity UI 1.0.0, Input System 1.7.0 and Test Framework 1.1.33 for the selected editor family. Declare required built-in engine modules.
- Add explicit Unity.ugui and Unity.InputSystem assembly references.
- Serialize all eight OrderGame scene references assigned by the editor bootstrap. Previously, private unsaved references were lost on scene reload.
- Give OrderClick, OrderDestination and OrderPointerInput separate matching script files and unique metadata. Preserve the existing OrderGame script GUID.
- First-import setup reschedules while imports are busy, avoids batch-mode automatic scene mutation and preserves user-modified scenes.
- Check SaveScene success before recording a generated build scene.
- Wire the existing Redo command to a persistent UI event. Move bottom controls to separate positions.
- Use a single Input System backend and request Android landscape / IL2CPP settings.
- Add a Unity scene save/reopen regression test for references and script identities.

## Executed checks
- All JSON manifests and assembly definitions parse.
- No duplicate metadata GUIDs.
- Every MonoBehaviour class has a matching source filename.
- Domain contains no UnityEngine / UnityEditor references and keeps noEngineReferences=true.
- Original source retained except the explicitly changed files. Save reconciliation implementation and Domain source preserved.
- Final archive CRC and SHA-256 manifest checked during packaging.

## Not executed
Unity editor is unavailable in this environment. No C# compiler is installed.
COMPILE_VERIFIED=false; TEST_VERIFIED=false; DEVICE_VERIFIED=false.
Static checks do not establish complete DESIGN_VERIFIED status for the whole game.
The scene persistence regression test must run in Unity. Android SDK/NDK and device validation remain required.

## Remaining scope
The recovered baseline uses Domain plus a combined Runtime assembly, not the requested complete AppCore / Infrastructure / Input / Presentation separation. This delivery preserves that baseline rather than claiming those layers exist. Hint is not added. This is targeted compatibility remediation, not a full line-by-line security audit or production-readiness certification.

## Complexity
Runtime input dispatch is unchanged. First-import readiness check uses O(1) time and space per callback. Scene creation remains O(T + B + A) for targets, buttons and generated assets. The regression test scans a fixed set of references and components.

## Package documentation
https://docs.unity3d.com/2022.3/Documentation/Manual/com.unity.ugui.html
https://docs.unity.cn/Documentation/Manual/com.unity.inputsystem.html
https://docs.unity.cn/Documentation/Manual/com.unity.test-framework.html
