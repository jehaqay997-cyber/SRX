"""Bounded, provenance-aware candidate path generation for SRX concept relations."""
from collections import defaultdict

class RelationPathInputError(ValueError):
    pass

def generate_candidates(system_id: str, nodes: list[dict], edges: list[dict], min_hops: int = 2, max_hops: int = 3, max_candidates: int = 1000) -> list[dict]:
    if not 2 <= min_hops <= max_hops <= 5:
        raise RelationPathInputError("require 2 <= min_hops <= max_hops <= 5")
    if len(nodes) > 500 or len(edges) > 2000:
        raise RelationPathInputError("graph exceeds bounded processing limits")
    node_map = {node["id"]: node for node in nodes}
    outgoing = defaultdict(list)
    for edge in edges:
        if edge["system_id"] != system_id or edge["from"] not in node_map or edge["to"] not in node_map:
            raise RelationPathInputError("relation graph contains an invalid system boundary or endpoint")
        outgoing[edge["from"]].append(edge)
    for key in outgoing:
        outgoing[key].sort(key=lambda e: e["id"])
    candidates = []
    def walk(start, current, path, visited):
        if len(candidates) >= max_candidates:
            return
        hops = len(path)
        if min_hops <= hops <= max_hops:
            ids = [start] + [edge["to"] for edge in path]
            candidates.append({
                "candidate_id": "HYP-" + "-".join(edge["id"] for edge in path),
                "status": "hypothesis_unvalidated", "system_id": system_id,
                "start_node": start, "end_node": current,
                "path": [{"from": edge["from"], "relation": edge["relation"], "to": edge["to"],
                          "edge_id": edge["id"], "source_id": edge["source_id"],
                          "evidence_status": edge["evidence_status"]} for edge in path],
                "node_labels": [node_map[node_id].get("label", node_id) for node_id in ids],
                "interpretation": "مسار علاقات مرشح؛ لا يثبت السببية أو القدرة التنبؤية."
            })
        if hops >= max_hops or len(candidates) >= max_candidates:
            return
        for edge in outgoing.get(current, []):
            if edge["to"] not in visited:
                walk(start, edge["to"], path + [edge], visited | {edge["to"]})
                if len(candidates) >= max_candidates:
                    return
    for node_id in sorted(node_map):
        walk(node_id, node_id, [], {node_id})
        if len(candidates) >= max_candidates:
            break
    return candidates
